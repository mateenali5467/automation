import React, { useEffect,useState } from "react";
import "./App.css";
import routes from "./components/Routes/routes";
import {BrowserRouter, Routes, Route, Navigate, useLocation,useNavigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import LoginRoutes from "./helper/LoginRoute";
import LoginPage from "./pages/Auth/Login";
import GlobalStyle from "./assets/css/GlobalStyle";
import { ThemeProvider } from "styled-components";
import { lightTheme, darkTheme } from "./theme/Theme";
import { themeToggler } from "./feature/theme/ThemeSlice";
import { useSelector, useDispatch } from "react-redux";
import { nanoid } from "@reduxjs/toolkit";
import DesktopDrawer from "./components/Layout/Drawer/DesktopDrawer";
import TiktokAuth from "pages/Auth/TiktokAuth";

import FacebookAdManager from "components/Facebook/FacebookAds";
import TiktTokAdsManager from "components/Tiktok/TikTokAds";
import GoogleAdManager from "components/Google/GoogleAds";
import Integrations from "components/Integration";

import TermsOfService from "components/Terms";
import Privacy from "components/Privacy";

import LocalStorageListener from "helper/LocalStorageListener";

import ProtectedRoute from "./helper/ProtectedRoute";

import CssBaseline from '@mui/material/CssBaseline';

function App() {

  const { theme } = useSelector((store) => store.theme);
  const dispatch = useDispatch();
  const { pathname } = useLocation();
  const token = localStorage.getItem("token");

  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);


  useEffect(() => {
    var mode = localStorage.getItem("mode");
    if (mode) {
      dispatch(themeToggler(mode));
    }
  }, []);





  return (
    <>
      <ThemeProvider theme={theme == "light" ? lightTheme : darkTheme}>
      <CssBaseline />
        <ToastContainer />
        <GlobalStyle />
        <div>

        <LocalStorageListener />
             
          <Routes>
             

           <Route path="/" element={<LoginPage />} />

            {/* <Route element={<LoginRoutes />}>
             
            </Route> */}

            {routes.map((route, index) =>
              route.protect ? (
               
                <Route element={<ProtectedRoute />} key={nanoid()}>
                
           
                <Route path="/integrations" element={<Integrations />} />
                <Route path="/new-campaign/tiktok" element={<TiktTokAdsManager />} />

                <Route path="/new-campaign/facebook" element={<FacebookAdManager />} />

                <Route path="/new-campaign/google" 
                element={<GoogleAdManager/>} />
                
               <Route path={route.path} element={<route.component />} />




                </Route>

              
           
                
              ) : (
                <Route
                  path={route.path}
                  element={<route.component />}
                  key={nanoid()}
                />
              )
            )}
  
    
            <Route path="/terms-of-service" element={<TermsOfService />} />
           <Route path="/privacy-policy" element={<Privacy />} />
          

 
            <Route
              path="*"
              element={<Navigate to={token ? "/dashboard" : "/"} />}
            />
          </Routes>
       
        </div>
      </ThemeProvider>
    </>
  );
}

export default App;
