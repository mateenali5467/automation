import React from "react";
import styled from "styled-components";
import { TextField, Autocomplete, Box, Typography } from "@mui/material";

const AutoCompleteTwo = ({
  placeholder,
  setValue,
  name,
  data,
  dataTwo,
  index,
}) => {
  
  
  const onAutoCompleteChange = (e, newValue) => {
    let data = dataTwo;
    console.log(name, "dasdadddd");
    data["set_rules"][index][name] = newValue.label;
    setValue(data);
  };
  return (
    <>
      <AutoCompleteStyled>
        <Box>
          <Autocomplete
            disablePortal
            name={name}
            // value={dataTwo && dataTwo[name]}
            fullWidth
            onChange={(e, newValue) => onAutoCompleteChange(e, newValue)}
            options={data}
            groupBy={(data) => data.group}
            
            className="primary_color "
            sx={{
              // maxWidth: "450px",
              fieldset: {
                border: "1px solid",
                borderRadius: "5px",
                borderColor: "inherit",
              },
              label: {
                color: "inherit",
                "&.Mui-focused": {
                  color: "inherit",
                },
              },
              svg: {
                color: "inherit",
              },
              "& .MuiButtonBase-root": {
                color: "inherit",
              },
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                // label={placeholder}
                placeholder={placeholder}
                className="pack_man_input "
                sx={{ label: { top: "-2px" } }}
                inputProps={{
                  className: "border ",
                  ...params.inputProps,
                }}
                InputProps={{
                  ...params.InputProps,
                  className: "text",
                  style: {
                    padding: "6px",
                  },
                }}
              />
            )}
          />
        </Box>
      </AutoCompleteStyled>
    </>
  );
};

export default AutoCompleteTwo;

const AutoCompleteStyled = styled.section`
  width: 100%;
  .pack_man_input {
    .MuiOutlinedInput-root {
      &:hover fieldset {
        border-color: inherit;
      }
      &.Mui-focused fieldset {
        border-color: inherit;
      }
    }
  }
`;
