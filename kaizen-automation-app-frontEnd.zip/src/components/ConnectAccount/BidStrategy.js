import React, { useState } from "react";
import {
  Box,
  Typography,
  Tab,
  Grid,
  Button,
  FormGroup,
  FormControlLabel,
  Switch,
  Checkbox,
  FormControl,
  TextField,
  FormLabel,
  Radio,
  RadioGroup,
  Divider,
  Autocomplete,
  Select,
  MenuItem,
} from "@mui/material";
import CustomTextField from "../common/CustomTextField";
import Heading from "../common/Heading";
import InputField from "../automation/create automation/InputField";
import DropDown from "../automation/create automation/DropDown";
const BidStrategy = ({ value }) => {
  const [targetROAS, setTargetROAS] = useState("");
  const [adLocation, setAdLocation] = useState("anywhere");
  return (
    <>
      {value === "Maximize conversion value" && (
        <Box sx={{ maxWidth: "300px" }}>
          <Heading heading="Target ROAS" />
          <Box sx={{ pb: 1 }}>
            <InputField
              placeholder="%Enter Target ROAS value"
              setValue={setTargetROAS}
            />
          </Box>
        </Box>
      )}
      {value === "Maximize clicks" && (
        <Box sx={{ maxWidth: "300px" }}>
          <Heading heading="Max CPC bid" />
          <Box sx={{ pb: 1 }}>
            <InputField placeholder="€Enter Max CPC bid value" setValue={""} />
          </Box>
        </Box>
      )}
      {value === "Manual CPC" && (
        <Box sx={{ maxWidth: "300px" }}>
          <Box sx={{ display: "flex" }}>
            <Checkbox size="small" />
            <Heading heading="Enhanced CPC" variant="h7" />
          </Box>
          {/* <Box sx={{ pb: 1 }}> 
          <InputField placeholder="€Enter Max CPC bid value"  setValue={setTargetROAS}/>
        </Box> */}
        </Box>
      )}
      { value === "Target impression share" && (
        <Box sx={{ maxWidth: "300px" }}>
          <Heading heading="Ad Location" />
          <Box sx={{ pb: 1 }}>
            <DropDown
              placeholder="Select Location"
              data={[
                {
                  label: "Anywhere on result page",
                },
              ]}
              setValue={setAdLocation}
            />
          </Box>
          <Heading heading="(%)Impression share to target" />
          <Box sx={{ pb: 1 }}>
            <InputField placeholder="%Enter Value" setValue={""} />
          </Box>
          <Heading heading="Max CPC bid" />
          <Box sx={{ pb: 1 }}>
            <InputField placeholder="€Enter Max CPC bid value" setValue={""} />
          </Box>
        </Box>
      )}
    </>
  );
};

export default BidStrategy;
