import React, { useState,useCallback } from "react";
import TabsButton from "../common/TabsButton";
import Heading from "../common/Heading";
import TiktokIcon from "../common/TiktokIcon";
import CaptionHeading from "../common/CaptionHeading";
import { Facebook, Google, AddCircle } from "@mui/icons-material";
import { TabContext, TabPanel } from "@mui/lab";
import { Box, Button } from "@mui/material";
import { tiktokAccountURL } from "../../config/endpoint";
import tiktokLogo from "../../assets/images/svgs/logo-tiktok.svg";
import fbLogo from "../../assets/images/svgs/fb-01.svg";
import googleLogo from "../../assets/images/svgs/google-01.svg";
import axios from "axios";

import { baseURL } from "../../config/endpoint";
import {INSTANCE} from "../../config/axiosInstance";

import { LoginSocialTiktok,LoginSocialFacebook,LoginSocialGoogle } from "reactjs-social-login";

const newtorkData = [
  {
    heading: "Tiktok Ads",
    icon: TiktokIcon,
    position: "start",
    state: "tiktok",
  },
  {
    heading: "Google Ads",
    icon: Google,
    position: "start",
    state: "google",
  },
  {
    heading: "Facebook Ads",
    icon: Facebook,
    position: "start",
    state: "facebook",
  },
  //   {
  //     heading: "Connect Other Ad Network",
  //     icon: AddCircle,
  //     position: "start",
  //     state: "other",
  //   },
];


const REDIRECT_URI =  "https://automation.thecbt.live/";


const clientId =
"306056037862-6oj2o3e1dg4923n454dolh8550imqll1.apps.googleusercontent.com";

const ConnectAccount = ({ icon, name }) => {


  const [network, setNetwork] = useState("tiktok");
  
  const [provider, setProvider] = useState('');
  const [profile, setProfile] = useState(null);


  const onLoginStart = useCallback((googleData) => {
    console.log(googleData);
  }, []);

  const onLogoutSuccess = useCallback(() => {
    setProfile(null);
    setProvider('');
    alert('logout success');
  }, []);


  const onLoginEnd = async () => {

    try {

      const response = await INSTANCE.get("/campaign/auth/google",{
        headers: {
            'ngrok-skip-browser-warning': 'true', // set and send an ngrok-skip-browser-warning request header
            'User-Agent': 'Your Custom User Agent', // set and send a custom/non-standard browser User-Agent request header
            token : JSON.stringify(localStorage.getItem("token"))
        }
    });
    


    const authUrl = response.data.authUrl;
    window.location.href = authUrl;

     // After Google redirects you back to your application:
     // This code won't run immediately, but after the redirect
      // const { data } = await INSTANCE.get("/oauth2callback");
      // const { user, tokens } = data;
    } 
    catch (error) {
      console.error('Login error:', error);
    }
}



  return (
    <>


      {/* <Box sx={{ borderBottom: 4 }} className="border"> */}

      <TabContext value={network}>
        <TabsButton value={network} setValue={setNetwork} data={newtorkData} />
        <TabPanel value="tiktok">
          <Box sx={{ width: "100%", textAlign: "center" }}>
            <img src={tiktokLogo} alt="" />
            <Heading heading={`Connect your ${network} profile`} />
            <CaptionHeading
              text={`connect your ${network} profile & toggle on ad account to start using`}
            />
            <Box>
              {/* <a href={tiktokAccountURL} style={{textDecoration: 'none'}}> */}

       
              <LoginSocialTiktok
            client_key="aw88u7motz49v4x7"
            redirect_uri={REDIRECT_URI}
            onLoginStart={onLoginStart}
            onResolve={({ provider, data }) => {
              setProvider(provider);
              setProfile(data);
              console.log(data)
            }}
            onReject={(err) => {
              console.log(err);
            }}
            className="pinterest-btn"
          >
            <div className="content">
              <div className="icon">
                {/* <TiktokLogo /> */}
              </div>
              {/* <Button  variant="contained">Connect with tiktok</Button> */}
               <Button className="btn">Connect profile</Button>
            </div>
          </LoginSocialTiktok>

               
              {/* </a> */}
            </Box>
          </Box>
        </TabPanel>
        <TabPanel value="google">
          <Box sx={{ width: "100%", textAlign: "center" }}>
            <img src={googleLogo} alt="" />

            <Heading heading={`Connect your ${network} profile`} />
            <CaptionHeading
              text={`connect your ${network} profile & toggle on ad account to start using`}
            />
            <Box>

   
      
         <Button onClick={onLoginEnd} className="btn">Connect profile</Button>

             
            </Box>
          </Box>
        </TabPanel>
        <TabPanel value="facebook">
          <Box sx={{ width: "100%", textAlign: "center" }}>
            <img src={fbLogo} alt="" />
            <Heading heading={`Connect your ${network} profile`} />
             <CaptionHeading
               text={`connect your ${network} profile & toggle on ad account to start using`}
             />
              <LoginSocialFacebook
            isOnlyGetToken
            appId="980256819765409"
            onLoginStart={onLoginStart}
            onResolve={({ provider, data }) => {
              setProvider(provider)
              setProfile(data)
            }}
            onReject={(err) => {
              console.log(err)
            }}
          >
             <Box>
              <Button className="btn">Connect profile</Button>
            </Box>
          </LoginSocialFacebook>

           
          </Box>
        </TabPanel>
      </TabContext>
      {/* </Box> */}
    </>
  );
};

export default ConnectAccount;
