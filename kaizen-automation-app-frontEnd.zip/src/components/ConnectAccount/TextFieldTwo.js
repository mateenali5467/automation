import React from "react";
import styled from "styled-components";
import { Box, TextField } from "@mui/material";

const TextFieldTwo = ({ placeholder, setValue, name, data, index }) => {

  console.log(data);
  const handleChange = (e) => {
    let d = data;
    d["set_rules"][index]["matric"] = e.target.value;
    setValue(data);
  };

  return (
    <>
      <CustomTextFieldStyled>
        <Box>
          <TextField
            fullWidth
            name={name}
            placeholder={placeholder}
            onChange={(e) => handleChange(e)}
            className="text_field"
            inputProps={{
              className: "primary_color  ",
            }}
            InputProps={{
              className: "primary_color ",
            }}
            sx={{
              maxWidth: "450px",
              input: {
                background: "currentColor",
                border: "1px solid",
                height: "0.8em",
                borderRadius: "5px",
              },
            }}
          />
        </Box>
      </CustomTextFieldStyled>
    </>
  );
};

export default TextFieldTwo;

const CustomTextFieldStyled = styled.section`
  .text_field {
    max-width: 100%;
    .MuiOutlinedInput-root {
      &:hover fieldset {
        border-color: inherit;
      }
      &.Mui-focused fieldset {
        border-color: inherit;
      }
    }
  }
`;
