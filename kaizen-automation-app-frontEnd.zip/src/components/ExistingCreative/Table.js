import React, { useState, useEffect } from "react";
import {
  Box,
  TableCell,
  Typography,
  TableRow,
  FormGroup,
  Switch,
  styled as muiStyled,
  Checkbox,
  Tooltip,
} from "@mui/material";
import {
  FacebookRounded,
  ContentCopy,
  Edit,
  RadioButtonChecked,
} from "@mui/icons-material";
import { useSelector } from "react-redux";
const AntSwitch = muiStyled(Switch)(({ theme, customTheme }) => ({
  width: 28,
  height: 16,
  padding: 0,
  display: "flex",
  "&:active": {
    "& .MuiSwitch-thumb": {
      width: 15,
    },
    "& .MuiSwitch-switchBase.Mui-checked": {
      transform: "translateX(9px)",
    },
  },
  "& .MuiSwitch-switchBase": {
    padding: 2,
    color: customTheme === "dark" ? "#707787" : "#fff",
    "&.Mui-checked": {
      transform: "translateX(12px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        opacity: 1,
        backgroundColor: theme.palette.mode === "dark" ? "#177ddc" : "#6259ca",
      },
    },
  },
  "& .MuiSwitch-thumb": {
    boxShadow: "0 2px 4px 0 rgb(0 35 11 / 20%)",
    width: 12,
    height: 12,
    borderRadius: 6,
    transition: theme.transitions.create(["width"], {
      duration: 200,
    }),
  },
  "& .MuiSwitch-track": {
    borderRadius: 16 / 2,
    opacity: 1,
    backgroundColor: customTheme === "dark" ? "#fff" : "#707787",
    boxSizing: "border-box",
  },
}));
const Table = ({ item, setCheckedStudents, checkedStudents }) => {
  const { theme: customTheme } = useSelector((store) => store.theme);
  const handleChange2 = (isChecked, uid) => {
    const index = checkedStudents.indexOf(uid);

    // The checked value is altered before the state changes for some reason is not a trully controlled component
    // So the next conditions are INVERTED.

    if (isChecked) return setCheckedStudents((state) => [...state, uid]);

    if (!isChecked && index > -1)
      return setCheckedStudents((state) => {
        state.splice(index, 1);
        return JSON.parse(JSON.stringify(state)); // Here's the trick => React does not update the f* state array changes even with the spread operator, the reference is still the same.
      });
  };
  return (
    <>
      <TableRow
        sx={{
          "&:last-child td, &:last-child th": {
            // borderBottom: 0,
            border: 0,
          },
          td: {
            whiteSpace: "nowrap",
          },
          //   td: {
          //     borderRight: "1px solid rgba(224, 224, 224, 1)",
          //   },
        }}
      >
        {/* <TableCell component="th" scope="row">
          <Checkbox
            className="text"
            sx={{
              "&.Mui-checked": {
                color: "var(--main-color) !important",
              },
            }}
            key={item.uid}
            checked={checkedStudents.includes(item.uid)}
            onChange={(event) => handleChange2(event.target.checked, item.uid)}
            inputProps={{ "aria-label": "controlled" }}
          />
        </TableCell> */}
        {/* <TableCell component="th" scope="row">
          <img src={item?.creative_thumbnail} alt="" />
        </TableCell> */}
        <TableCell align="center" className="text">
          {item?.creative_pack_name}
        </TableCell>
        <TableCell align="center" className="text">
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              "& svg": {
                fontSize: "21px",
              },
            }}
          >
            <FormGroup>
              <AntSwitch
                customTheme={customTheme}
                // className="text"
                inputProps={{
                  "aria-label": "ant design",
                  //   className: "aaaaaaaaaaaaaaaaaaaaaaa",
                }}
              />
            </FormGroup>
            
            <Box sx={{ ml: 2, cursor: "pointer" }}>
              <Tooltip title="copy ...." arrow>
                <ContentCopy />
              </Tooltip>
            </Box>
            <Box sx={{ ml: 2, cursor: "pointer" }}>
              <Tooltip title="Edit...." arrow>
                <Edit />
              </Tooltip>
            </Box>
          </Box>
      
        </TableCell>
        
        <TableCell align="center" className="text">
          {item?.creative_platform}
        </TableCell>

        <TableCell align="center" className="text">
          <RadioButtonChecked sx={{ color: "var(--main-color)" }} />
        </TableCell>

        {/* <TableCell align="center" className="text">
          <Box
            sx={{
              display: "flex",
              "& svg": {
                margin: "0 5px",
              },
            }}
          >
            <FacebookRounded />
            <FacebookRounded />
            <FacebookRounded />
          </Box>
        </TableCell> */}
        {/* <TableCell align="center" className="text">
          <Box
            sx={{
              display: "flex",
              "& .tag": {
                background: "#c4c4c4",
                border: "2px solid",
                margin: "0px 10px",
                padding: "8px 21px",
                color: "#6259ca !important",
                borderRadius: "10px",
                height: "32px",
                whiteSpace: "nowrap",
                display: "flex",
                alignItems: "center",
              },
            }}
          >
            {item.tag ? (
              item?.tag?.map((tag, index) => (
                <>
                  <Box className="tag" sx={{}}>
                    {tag}
                  </Box>
                </>
              ))
            ) : (
              <Typography variant="caption">No tags</Typography>
            )}
          </Box>
        </TableCell> */}
        <TableCell align="center" className="text">
          {item?.creative_audience ? "yes" : "no"}
        </TableCell>
        <TableCell align="center" className="text">
          {item?.creative_visibility
            ? item?.creative_visibility === 1
              ? "public"
              : " hidden "
            : "private"}
        </TableCell>
        <TableCell align="center" className="text">
          {item?.creative_size}
        </TableCell>
        <TableCell align="right" className="text">
          {item?.creative_type}
        </TableCell>
      </TableRow>
    </>
  );
};

export default Table;
