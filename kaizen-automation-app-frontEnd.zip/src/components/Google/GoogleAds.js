
import { useState,useEffect,useCallback } from 'react';
import { useParams } from 'react-router-dom';
import DesktopDrawer from 'components/Layout/Drawer/DesktopDrawer';
import BreadCrums from 'components/common/BreadCrums';
import SideModel from 'components/SideModel';
import { useFormik,Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

import SweetAlert from 'react-bootstrap-sweetalert';
import useSWR from 'swr';

import FileCopyIcon from '@mui/icons-material/FileCopy';

import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import MoreVertIcon from '@mui/icons-material/MoreVert';


import NewTableMockup from './NewTableMockup';

import { 
    StyledPaper, StyledTableHead, StyledTableCellWithBorder, StyledTableRow, 
    StyledTableContainer, BudgetStyledTableCell 
} from './NewTableMockup';


import {Menu,Switch,FormControlLabel,Box, TextField, MenuItem, FormControl, InputLabel, Select, Button,Grid,Container, Typography,Tooltip,Fab,Stepper, Step, StepLabel,Checkbox,FormGroup,Alert,useTheme, useMediaQuery,Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,OutlinedInput,CircularProgress,Card,CardContent,CardActions,Icon } from '@mui/material';
import { Button as MuiButton, styled } from '@mui/material';
import Snackbar from '@mui/material/Snackbar';

import { ThemeProvider, createTheme } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';

import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';


import dayjs from 'dayjs';
import DateFnsUtils from '@date-io/date-fns';
import SettingsIcon from '@material-ui/icons/Settings';
import { makeStyles } from '@mui/styles';
import Heading from 'components/common/Heading';

import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";

import DatePicker from "@mui/lab/DatePicker";

import { Toast } from 'components/common/Toast';





import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';


import { LoginSocialGoogle } from "reactjs-social-login";
import { baseURL } from "../../config/endpoint";
import {INSTANCE} from "../../config/axiosInstance";


import InsertLinkSharpIcon from '@mui/icons-material/InsertLinkSharp';
import LinkOffSharpIcon from '@mui/icons-material/LinkOffSharp';
import LoadingButton from '@mui/lab/LoadingButton';
import SaveIcon from '@mui/icons-material/Save';
import SendIcon from '@mui/icons-material/Send';


import {
  useSearchParams
} from 'react-router-dom';


import TaskCondition from "../../pages/Campaign Center/TaskCondition";

import AddAccount from 'pages/Campaign Center/AdAccount';

import TimeSchedule from 'pages/Campaign Center/TimeSchedule';

const GoogleAdManager = () => {

  const [isSidebarOpen, setSidebarOpen] = useState(false);

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };
    

 
  return (
    <>

    
           {/* <BreadCrums heading="Campaign Center" /> */}


         <AddAccount />

         <TaskCondition />

         <TimeSchedule/>

{/*            
           <Box
  sx={{
    display: 'flex',
    alignItems: 'center', // centers items vertically
    justifyContent: 'space-between' // spaces items as far apart as possible
  }}
>
  <Heading heading="Google Ad Manager" />

  {  
  (updatedDataConnectionAccount) ?  <Box
         sx={{
                mt: 1,
                width: "250px",
                padding: 2,
                borderRadius: 3,
                backgroundColor: isConnected ? 'white' : 'rgba(255, 255, 255, 0.6)', // Adjust opacity for disconnected state
                color: 'black',
                transition: 'box-shadow 0.3s, background-color 0.3s', // Added transition for background-color
                boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.2)', // Default box shadow
                '&:hover': {
                    boxShadow: isConnected ? '0px 6px 12px rgba(0, 0, 0, 0.3)' : '0px 4px 8px rgba(0, 0, 0, 0.2)'
                },
                position: 'relative', // Required for absolute positioning of the child element (NotInterestedIcon)
                cursor: isConnected ? 'pointer' : 'not-allowed'  // Shows a "not allowed" cursor when the box is not clickable
            }}
       >
        <Box sx={{display:'flex',justifyContent: 'space-between',alignItems:'center'}}>
            <img  width={45} height={45} src="/images/google_ad.svg" />
          
    
        <Box >
          <Box sx={{display:'flex',gap:1}}>
           <h4 style={{color:'#0F9D58'}}>Connected</h4> 
           <InsertLinkSharpIcon style={{ color: '#4285F4', fontSize: '24px' }} />
          </Box>
           
        </Box>
  
             
        </Box>
      </Box> :    
      <Box
        onClick={handleOAuthGoogle}
          sx={{
          mt: 1,
          width:"250px",
          cursor : "hover",
          padding: 2,
          borderRadius: 3,
          backgroundColor: 'white',
          color: 'black',
          transition: 'box-shadow 0.3s',
          '&:hover': isConnected ? {} : { boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.2)' }, // Only show shadow if not connected
      }}
       >
        <Box sx={{display:'flex',justifyContent: 'space-between',alignItems:'center'}}>
        <img width={45} height={45} src="/images/google_ad.svg" />
          
    
        <Box >
        <Box sx={{display:'flex',gap:1}}> 
            
            {
                authLoader ? <CircularProgress size={20} />  : <>
                <h4 style={{ cursor: 'default' }}> Connect Account</h4> 
            <LinkOffSharpIcon style={{  fontSize: '24px' }} />
                </>
            }
          </Box>
           
        </Box>
  
             
        </Box>
      </Box>

}
</Box> */}


           {/* <Box className={classes.container}>
      {
        [0, 4].map(startIndex => (
        <Box key={startIndex} className={classes.row}>
          {divData.slice(startIndex, startIndex + 4).map(data => (
            <Box 
              key={data} 
              className={classes.box}
              onClick={() => handleClick(data)}
            >
              {data}
            </Box>
          ))}
        </Box>
      ))
      }
    </Box> */}


  
        
    </>
  )

  // Rest of your component code
};

export default GoogleAdManager;



const useStyles = makeStyles({
  container: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
  },
  row: {
    display: 'flex',
    flexDirection: { xs: 'column', md: 'row' },
    justifyContent: 'space-between',
    gap: '20px',
  },
  box: {
    flex: 1,
    padding: '16px',
    border: '1px solid black',
    transition: 'transform 0.3s',
    '&:hover': {
      transform: 'scale(1.1)',
      cursor: 'pointer',
    },
  },
});

