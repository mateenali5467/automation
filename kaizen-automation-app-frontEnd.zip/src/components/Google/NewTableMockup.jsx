import { useState } from 'react';

import {Menu,Switch,FormControlLabel,Box, TextField, MenuItem, FormControl, InputLabel, Select,Grid,Container, Typography,Tooltip,Fab,Stepper, Step, StepLabel,Checkbox,FormGroup,Alert,useTheme, useMediaQuery,OutlinedInput,CircularProgress,Card,CardContent,CardActions,Icon, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Button, Paper, Table, TableContainer, TableHead, TableRow, TableCell, TableBody  } from '@mui/material';

import FileCopyIcon from '@mui/icons-material/FileCopy';

import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@material-ui/icons/Edit';
import { Button as MuiButton, styled } from '@mui/material';



  const dataMock = [
    { 
      id: 1, name: "Campaign 1", action: "Action 1", isActive: true, status: "Active", budget: "100", tags: "Sales, Shop",
      impression: "1000", totalCost: "50", cpc: "$0.5", cpm: "$0.05",budgetType:"monthly"
    },
    { 
        id: 2, name: "Campaign 2", action: "Action 1", isActive: false, status: "Active", budget: "1400", tags: "Tag1, Tag2",
        impression: "1000", totalCost: "50", cpc: "$0.5", cpm: "$0.05",budgetType:"annualy"
      },
      { 
        id: 3, name: "Campaign 5", action: "Action 1", isActive: true, status: "Active", budget: "456", tags: "ds, rew",
        impression: "1000", totalCost: "50", cpc: "$0.5", cpm: "$0.05",budgetType:"annualy"
      }
  ];
  


  export const StyledPaper = styled(Paper)({
    borderRadius: '10px',
    boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
    overflow: 'hidden',
  });
  
  export const StyledTableHead = styled(TableHead)({
    backgroundColor: '#FFFFFF', // This sets the background to white.
  });
  
  export const StyledTableCell = styled(TableCell)({
    fontWeight: 'bold',
    color: '#8A8A8A', // Adjusted to be a bit lighter than before but darker than light black
    padding: '15px 20px',
    
});

export const StyledTableCellWithBorder = styled(TableCell)({
    borderBottom: '2px solid #E1E1E1',
    borderRight: '2px solid #E1E1E1',
    padding: '15px 20px',
    color: '#8A8A8A', // Added the desired color here
});
  
export const StyledTableRow = styled(TableRow)({
    '&:hover': {
      backgroundColor: '#F6F6F6',
      borderWidth: '2px',   // Add this
      borderColor: '#E1E1E1', // Adjust this color if needed
      borderStyle: 'solid',  // Add this
    },
  });
  
  export const StyledTableContainer = styled(TableContainer)({
    maxWidth: '100%',
    overflowX: 'auto',

    '&::-webkit-scrollbar': {
        height: '8px',
    },
    '&::-webkit-scrollbar-track': {
        boxShadow: 'inset 0 0 5px grey',
        borderRadius: '4px',
    },
    '&::-webkit-scrollbar-thumb': {
        backgroundColor: 'rgba(0, 0, 0, .5)',
        borderRadius: '4px',
    },
    '&::-webkit-scrollbar-thumb:hover': {
        backgroundColor: 'rgba(0, 0, 0, .7)',
    }
});

export const BudgetStyledTableCell = styled(StyledTableCell)({
    width: '140px', 
    textAlign: 'center', // Adjust this value as per your requirements
});
  


const NewTableMockup  = ({data})=>{

    console.log("MOCKUO",data);


    const [tooltipOpen, setTooltipOpen] = useState(false);
    const [tooltipRowId, setTooltipRowId] = useState(null);
    const [dataTable, setDataTable] = useState(dataMock);
    const [loadingId, setLoadingId] = useState(null); 

    const [selectedRows, setSelectedRows] = useState([]);
    const [showDeleteDialog, setShowDeleteDialog] = useState(false);

    const theme = useTheme();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));

    const StyledPaper = styled(Paper)({
        borderRadius: '10px',
        boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
        overflow: 'hidden',
      });
      
      const StyledTableHead = styled(TableHead)({
        backgroundColor: '#FFFFFF', // This sets the background to white.
      });
      
      const StyledTableCell = styled(TableCell)({
        fontWeight: 'bold',
        color: '#8A8A8A', // Adjusted to be a bit lighter than before but darker than light black
        padding: '15px 20px',
        
    });

    const StyledTableCellWithBorder = styled(TableCell)({
        borderBottom: '2px solid #E1E1E1',
        borderRight: '2px solid #E1E1E1',
        padding: '15px 20px',
        color: '#8A8A8A', // Added the desired color here
    });
      
      const StyledTableRow = styled(TableRow)({
        '&:hover': {
          backgroundColor: '#F6F6F6',
          borderWidth: '2px',   // Add this
          borderColor: '#E1E1E1', // Adjust this color if needed
          borderStyle: 'solid',  // Add this
        },
      });
      
      const StyledTableContainer = styled(TableContainer)({
        maxWidth: '100%',
        overflowX: 'auto',
    
        '&::-webkit-scrollbar': {
            height: '8px',
        },
        '&::-webkit-scrollbar-track': {
            boxShadow: 'inset 0 0 5px grey',
            borderRadius: '4px',
        },
        '&::-webkit-scrollbar-thumb': {
            backgroundColor: 'rgba(0, 0, 0, .5)',
            borderRadius: '4px',
        },
        '&::-webkit-scrollbar-thumb:hover': {
            backgroundColor: 'rgba(0, 0, 0, .7)',
        }
    });
  
    const BudgetStyledTableCell = styled(StyledTableCell)({
        width: '140px', 
        textAlign: 'center', // Adjust this value as per your requirements
    });
      

    const handleCopy = (rowData, id) => {

        console.log(id)
        // Copy the row data to clipboard
        navigator.clipboard.writeText(JSON.stringify(rowData))
        .then(() => {
            // Show the tooltip for the clicked row
            setTooltipRowId(id);
            
            // Hide the tooltip after 2 seconds
            setTimeout(() => {
                setTooltipRowId(null);
            }, 2000);
        })
        .catch(err => {
            console.error('Failed to copy text: ', err);
        });
    };

    const handleToggle = (id) => {
        setLoadingId(id);  // Start loading for this specific row's switch

        // Delay of 3 seconds
        setTimeout(() => {
            // Simulate an API hit here
            const updatedData = dataTable.map(row => {
                if (row.id === id) {
                    return { ...row, isActive: !row.isActive };
                }
                return row;
            });

            setDataTable(updatedData);
            setLoadingId(null);  // Stop loading for this specific row's switch
        }, 3000);
    };
    
    const handleSelectRow = (id) => {
        const currentIndex = selectedRows.indexOf(id);
        const newSelectedRows = [...selectedRows];
    
        if (currentIndex === -1) {
            newSelectedRows.push(id);
        } else {
            newSelectedRows.splice(currentIndex, 1);
        }
    
        setSelectedRows(newSelectedRows);
    };
    
    const deleteSelectedRows = () => {
        setDataTable((prevData) => prevData.filter(row => !selectedRows.includes(row.id)));
        setShowDeleteDialog(false);
        setSelectedRows([]);
    };
    

    if (selectedRows.length > 0 && !showDeleteDialog) {
        setShowDeleteDialog(true);
    }
    
    const deleteConfirmationDialog = (
        <Dialog
            open={showDeleteDialog}
            onClose={() => setShowDeleteDialog(false)}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
        >
            <DialogTitle id="alert-dialog-title">{"Delete Selected Campaigns?"}</DialogTitle>
            <DialogContent>
                <DialogContentText id="alert-dialog-description">
                    Are you sure you want to delete the selected campaigns? This action cannot be undone.
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={() => setShowDeleteDialog(false)} color="primary">
                    Cancel
                </Button>
                <Button onClick={deleteSelectedRows} color="primary" autoFocus>
                    Confirm
                </Button>
            </DialogActions>
        </Dialog>
    );


    const dummyDataTabel = [
        {
            name : 'revealBot',
            desc : 'Running Ads'
        },
        {
          name : 'google ads',
          desc : 'automated rules'
        },
        {
           name : "maten",
           desc : 'runnfin ads '
        }
    ]
 

    return (
        <>
           <StyledPaper>
     <StyledTableContainer style={{maxWidth: 'calc(100vw - 40px)', overflowX: 'auto'}}>
        <Table>
            <StyledTableHead>
            <TableRow>
                       
                  <StyledTableCell>Name</StyledTableCell>
             
                <StyledTableCell>Action</StyledTableCell>
                <StyledTableCell>Status</StyledTableCell>
                
                <BudgetStyledTableCell>Budget</BudgetStyledTableCell>
                
                <StyledTableCell>Tags</StyledTableCell>
                <StyledTableCell>Impression</StyledTableCell>
                <StyledTableCell>Total Cost</StyledTableCell>
                <StyledTableCell>CPC</StyledTableCell>
                <StyledTableCell>CPM</StyledTableCell>
            </TableRow>
            </StyledTableHead>
            <TableBody>
            {dataTable.map((row) => (
                <StyledTableRow key={row.id}>
             
                <StyledTableCellWithBorder>{row.name}</StyledTableCellWithBorder>
            

     <StyledTableCellWithBorder>
            {loadingId === row.id ? (
                                <CircularProgress size={20} />
                            ) : (
                                <Switch
                                    checked={row.isActive}
                                    onChange={() => handleToggle(row.id)}
                                    inputProps={{ 'aria-label': 'Toggle isActive' }}
                                />
                            )}
  
    <Tooltip title="Data Copied" open={tooltipRowId === row.id} placement="top">
    <button
        onClick={() => handleCopy(row,row.id)}
        style={{
        backgroundColor: '#E0E0E0', // Light grey background
        border: 'none',
        borderRadius: '50%',
        marginRight: '5px',
        padding: '5px',
        cursor: 'pointer',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center'
    }}
    >
        <FileCopyIcon style={{ color: 'white', fontSize: 'small' }} />
    </button>
</Tooltip>
    <button
    onClick={() => {
        // Handle the edit action here
    }}
    style={{
        backgroundColor: '#E0E0E0',  // Light grey background
        border: 'none',
        borderRadius: '50%',
        padding: '5px',
        cursor: 'pointer',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center'
    }}
    >
    <EditIcon style={{ color: 'white', fontSize: 'small' }} />
    </button>

    </StyledTableCellWithBorder>
                <StyledTableCellWithBorder>
                <FiberManualRecordIcon 
                    style={{ 
                        color: row.isActive ? '#90EE90' : '#FFB6C1', // LightGreen and LightRed respectively
                        fontSize: '15px', 
                        marginRight: '5px' 
                    }} 
                    />
                                
                </StyledTableCellWithBorder>
                <StyledTableCellWithBorder style={{ textAlign: 'center', verticalAlign: 'middle', position: 'relative' }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', color: '#5A5A5A' }}>
        <div style={{ fontSize: '1rem', lineHeight: '1.2' }}>  {/* Adjusted fontSize from 1.2rem to 1rem */}
        <span style={{ fontSize: '0.9rem' }}>$</span>{row.budget}
        </div>
        <span style={{ fontSize: '0.5rem' }}>   {/* Adjusted fontSize from 0.5rem to 0.4rem */}
            {row.budgetType}
        </span>
    </div>
    </StyledTableCellWithBorder>




                {/* Display tags as small contained buttons */}
                <StyledTableCell>
    {row.tags.split(',').map((tag, index) => (
        <Button 
        key={index} 
        variant="outlined" 
        color="primary" 
        size="small" 
        style={{ 
            marginRight: '5px', 
            marginBottom: '5px', 
            backgroundColor: 'rgba(63, 81, 181, 0.1)' // This is a light shade of MUI's default primary color
        }}
        >
        {tag.trim()}
        </Button>
    ))}
    </StyledTableCell>
                <StyledTableCell>{row.impression}</StyledTableCell>
                <StyledTableCell>{row.totalCost}</StyledTableCell>
                <StyledTableCell>{row.cpc}</StyledTableCell>
                <StyledTableCell>{row.cpm}</StyledTableCell>
                </StyledTableRow>
            ))}
            </TableBody>
        </Table>
      </StyledTableContainer>
           </StyledPaper>

        </>
    )
}

export default NewTableMockup;
