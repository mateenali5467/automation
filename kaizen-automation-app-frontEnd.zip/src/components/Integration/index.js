import DesktopDrawer from "components/Layout/Drawer/DesktopDrawer";
import BreadCrums from "components/common/BreadCrums";


const Integrations = ()=>{
    return (
        <>
           <DesktopDrawer>
                <BreadCrums heading="Campaign Center" />
                <h1>Integration</h1>
                <h1>BreadCrums</h1>
           </DesktopDrawer>
        </>
    )
}

export default Integrations;