
import { Typography, Box, Container, Grid } from '@material-ui/core';



const TermsOfService = ()=>{
    return (
        <>
    <Container>
      <Box     display="flex" 
        flexDirection="column" 
        alignItems="center"
        height="100vh"  // making the container take the full viewport height
        overflowY="auto"  // enabling scroll when the content overflows
        width='50%'
        mx="auto"
        overflowX="hidden"
        pt={2} >
        <Typography variant="h2" gutterBottom>
          Privacy Policy
        </Typography>

        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Typography variant="body1" gutterBottom>
              <strong>1. Personal Identification Information</strong>
              <br />
              We may collect personal identification information from Users in a variety of ways, including, but not limited to, when Users visit our site, register on the site, and in connection with other activities, services, features or resources we make available on our Site.
              <br />
              
              <strong>2. Non-Personal Identification Information</strong>
              <br />
              We may collect non-personal identification information about Users whenever they interact with our Site. Non-personal identification information may include the browser name, the type of computer and technical information about Users means of connection to our Site, such as the operating system and the Internet service providers utilized and other similar information.
              <br />

              <strong>3. Web Browser Cookies</strong>
              <br />
              Our Site may use "cookies" to enhance User experience. User's web browser places cookies on their hard drive for record-keeping purposes and sometimes to track information about them. User may choose to set their web browser to refuse cookies, or to alert you when cookies are being sent.
              <br />

              <strong>4. How We Use Collected Information</strong>
              <br />
              Automation App may collect and use Users personal information for the following purposes:
              <ul>
                <li>To run and operate our Site</li>
                <li>To personalize user experience</li>
                <li>To improve our Site</li>
                <li>To send periodic emails</li>
              </ul>
              <br />

              <strong>5. How We Protect Your Information</strong>
              <br />
              We adopt appropriate data collection, storage and processing practices and security measures to protect against unauthorized access, alteration, disclosure or destruction of your personal information and data stored on our Site.
              <br />

              <strong>6. Sharing Your Personal Information</strong>
              <br />
              We do not sell, trade, or rent Users personal identification information to others. We may share generic aggregated demographic information not linked to any personal identification information regarding visitors and users with our business partners, trusted affiliates and advertisers for the purposes outlined above. 
              <br />
            </Typography>
          </Grid>
        </Grid>
      </Box>
    </Container>
        </>
    )
}

export default TermsOfService;