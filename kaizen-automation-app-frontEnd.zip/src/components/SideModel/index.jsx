import {useState,useEffect} from 'react';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { Button } from '@mui/material';

import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';

import InsertLinkSharpIcon from '@mui/icons-material/InsertLinkSharp';


import AccountShow from 'pages/Campaign Center/AccountShow';


import { baseURL } from "config/endpoint";
import { INSTANCE } from "../../config/axiosInstance";


const SideModel = ({ isOpen, toggleSidebar })=>{

    const [isModalOpen, setModalOpen] = useState(false);

    const handleButtonClick = () => {
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setModalOpen(false);
    };

    const getDetails = localStorage.getItem("detials");
    const parseDetails = JSON.parse(getDetails);

   const userName = parseDetails.data.user.name;
   const userEmail = parseDetails.data.user.user_email;
        

    const statusGoogleAccountFetch = parseDetails.data.user.google_connected

   let statusGoogleAccount = false;
    if(statusGoogleAccountFetch === 1){
        statusGoogleAccount = true
      }
      else{
        statusGoogleAccount = false
      }

      let isLoading = false;

      const accountDeLink = async () => {
        try {
            isLoading = true
          const res = await INSTANCE.get("/campaign/auth/revoke/access");
          console.log(res);
          isLoading = false
          setModalOpen(false);
          window.location.href = 'http://localhost:3000/new-campaign';
          // toggles sidebar after 1 second
        } catch (error) {
          // if there's an error, also hide the loader
          console.error("Error unlinking account:", error);
        }
      };

      const CustomModal = ({ isOpen, onClose }) => {
        return (
            <div >
                <Dialog  open={isOpen} onClose={onClose} fullWidth maxWidth="md">
                <DialogTitle sx={{gap: 2,  display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant='h6'>Profile</Typography>
                    <IconButton edge="end" color="inherit" onClick={onClose} aria-label="close">
                        <CloseIcon />
                    </IconButton>
                </DialogTitle>
                
                <hr />

                <DialogContent>
                    <Typography variant="h6" align="left" gutterBottom>
                        Connected
                    </Typography>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                <img 
                    width={35} 
                    height={35} 
                    src="/images/google_ad.svg" 
                    alt="Logo" 
                    style={{ borderRadius: '50%',backgroundColor:'lightgrey',padding:'5px' }}  // Makes the logo circular
                />
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                <Typography variant="body2" sx={{ fontWeight: 'bold', textTransform: 'capitalize' }}>
            {userName}
        </Typography>
        <Typography variant="body1" sx={{ fontSize:'16px'}}>
            {userEmail}
        </Typography>
                </Box>
            </Box>
           
        <Button 
          onClick={accountDeLink}
          variant="contained" 
          sx={{
            color: 'black',
            textTransform: 'none',  // keeps the text in its original case
            background:"lightgrey"
          }}
        >
         {
            isLoading ? "...." : 'UnLink'
         }
        </Button>
   


</Box>

                    
                </DialogContent>
            </Dialog>
            </div>
        );
      };


    return (
        <>
         <Drawer
            anchor="right"
            open={isOpen}
            onClose={toggleSidebar}
            variant="temporary"
            PaperProps={{
                style: {
                    width: '75%',
                },
            }}
        >
            <Box 
                sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    px: 4,
                    mt:12
                }}
            >
            
        <Button  onClick={toggleSidebar} variant='outlined'>Close</Button>
                
            </Box>

    {/*CONNECTED BUTTON */}
            <Box px={4}>
            <Box
             onClick={handleButtonClick}
            sx={{
                mt: 1,
                width: "250px",
                padding: 2,
                borderRadius: 3,
                backgroundColor: statusGoogleAccount ? 'white' : 'rgba(255, 255, 255, 0.6)', // Adjust opacity for disconnected state
                color: 'black',
                transition: 'box-shadow 0.3s, background-color 0.3s', // Added transition for background-color
                boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.2)', // Default box shadow
                '&:hover': {
                    boxShadow: statusGoogleAccount ? '0px 6px 12px rgba(0, 0, 0, 0.3)' : '0px 4px 8px rgba(0, 0, 0, 0.2)'
                },
                position: 'relative', // Required for absolute positioning of the child element (NotInterestedIcon)
                cursor: statusGoogleAccount ? 'pointer' : 'not-allowed'  // Shows a "not allowed" cursor when the box is not clickable
            }}
       >
        <Box sx={{display:'flex',justifyContent: 'space-between',alignItems:'center'}}>
            <img  width={45} height={45} src="/images/google_ad.svg" />
          
    
        <Box >
          <Box sx={{display:'flex',gap:1}}>
           <h4 style={{color:'#0F9D58'}}>Connected</h4> 
           <InsertLinkSharpIcon style={{ color: '#4285F4', fontSize: '24px' }} />
          </Box>
           
        </Box>
  
             
        </Box>
           </Box> 


           <CustomModal isOpen={isModalOpen} onClose={handleCloseModal} />

            </Box>

    {/*Account Show */}
            <Box px={2}>
                <AccountShow />
            </Box>

        </Drawer>
        </>
    )
}

export default SideModel;