
import { Typography, Box, Container, Grid } from '@material-ui/core';

const TermsOfService = ()=>{
    return (
        <>
   <Container>
      <Box  
        display="flex" 
        flexDirection="column" 
        alignItems="center"
        height="100vh"  // making the container take the full viewport height
        overflowY="auto"  // enabling scroll when the content overflows
        width='50%'
        mx="auto"
        overflowX="hidden"
        pt={2}  >
        <Typography variant="h2" gutterBottom>
          Terms of Service
        </Typography>

        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Typography variant="body1" gutterBottom>
              <strong>1. Acceptance of Terms</strong>
              <br />
              By accessing and using Automation App, you accept and agree to be bound by the terms and provision of this agreement.
              <br />
              
              <strong>2. Modification of Terms</strong>
              <br />
             Automation App reserves the right to change these conditions from time to time as it sees fit and your continued use of the site will signify your acceptance of any adjustment to these terms.
              <br />

              <strong>3. Intellectual Property Rights</strong>
              <br />
              Other than the content you own, under these Terms, Automation App and/or its licensors own all the intellectual property rights and materials contained in this Website.
              <br />

              <strong>4. Privacy Policy</strong>
              <br />
              Before you continue using our website we advise you to read our privacy policy regarding our user data collection. It will help you better understand our practices.
              <br />
            </Typography>


         <Typography variant="body1" gutterBottom>
              <strong>5. Services Description</strong>
              <br />
              Automation App is an automation tool for managing ads on TikTok. It allows you to automate various aspects of ad management such as 
              <br />
              
              <strong>6. User Responsibilities</strong>
              <br />
              As a user of Automation App, you agree to 
              <br />

              <strong>7. Data Usage & Privacy</strong>
              <br />
              Automation App collects and uses data in accordance with our Privacy Policy, which can be found at [link to Privacy Policy]. This data may include 
              <br />

              <strong>8. TikTok Ad Manager Interactions</strong>
              <br />
              Automation Appinteracts with TikTok's Ad Manager to By using our service, you also agree to TikTok's Terms of Service.
              <br />

              <strong>9. Automated Actions</strong>
              <br />
              Automation App performs automated actions including. You understand and agree that 
              <br />
       </Typography>



          </Grid>
        </Grid>
      </Box>
    </Container>
        </>
    )
}

export default TermsOfService;