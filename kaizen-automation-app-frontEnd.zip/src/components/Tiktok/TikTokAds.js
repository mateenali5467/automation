import { useParams } from 'react-router-dom';
import DesktopDrawer from 'components/Layout/Drawer/DesktopDrawer';
import BreadCrums from 'components/common/BreadCrums';


const TiktTokAdsManager = () => {
  const { token } = useParams();

  // Now you can use the 'token' value in your component
  console.log(token);

  return (
    <>
    <DesktopDrawer>

     <BreadCrums heading="Campaign Center" />
       <h1>{token} Tiktok Ads Manager</h1>
     </DesktopDrawer>
        
    </>
  )

  // Rest of your component code
};

export default TiktTokAdsManager;