import React, {useState} from "react";
import {
  Box,
  Typography,
  Tab,
  Grid,
  Button,
  FormGroup,
  FormControlLabel,
  Switch,
  Checkbox,
  FormControl,
  TextField,
  Divider,
  Autocomplete,
} from "@mui/material";
import { TabContext, TabList, TabPanel } from "@mui/lab";

import {
  Facebook,
  Google,
  Email,
  ArrowOutward,
  CallReceived,
  VerticalAlignBottom,
  VerticalAlignTop,
  AddCircle,
  TextFields,
  PlayArrow,
  Pause,
} from "@mui/icons-material";
import {
  bidStrategy,
  timeSpan,
} from "../../../helper/Data";
import DropDown from "./DropDown";
import SelectMenu from "../../common/SelectMenu";
import CustomTextField from "../../common/CustomTextField";
import BidStrategy from "../../ConnectAccount/BidStrategy";
import Heading from "../../common/Heading";


const AutomationTabsOptions = () => {


  const [automation, setautomation] = useState("status");
  const [bidMenu, setBidMenu] = useState("");
  const [bid, setBid] = useState("increase");
  const [status, setStatus] = useState("activate");
  const [names, setNames] = useState("add");
  const [budget, setBudget] = useState("increase");
  const [insideCurrentTab,setInsideCurrentTab] = useState("");


   let currentBid =  "status";
   let statusChangeValue = "pause";


  const bidChange = (event, newValue) => {
    setBid(newValue);
    setInsideCurrentTab(newValue);  
  };
  const statusChange = (event, newValue) => {
    setStatus(newValue);
    statusChangeValue = newValue;
  };
  const budgetChange = (event, newValue) => {
    setBudget(newValue);
    setInsideCurrentTab(newValue);
  };
  const nameChange = (event, newValue) => {
    setNames(newValue);
  };
  const automationChange = (event, newValue) => {
      setautomation(newValue);
      setInsideCurrentTab("increase")
  };

  const doThisTabData = {
    status : status,
    names : names,
    insideCurrentTab,
    bidMenu : bidMenu,
    automation : automation
   }

  sessionStorage.setItem("doThisTabData",JSON.stringify(doThisTabData));

  return (
    <>
    
      <Box sx={{ py: 2 }}>
        <Heading heading="Do This" />
        <TabContext value={automation}>

          <TabList
            onChange={automationChange}
            aria-label="lab API tabs example"
            sx={{
              "& 	.Mui-selected": {
                background: "var(--main-color) !important",
                color: "white",
              },
              "& 	.MuiTabs-indicator": {
                background: "none",
              },
              "& 	.tab_btn": {
                width: { xs: "100% !important", sm: "auto !important" },
                height: "37px",
                minHeight: "37px",
                borderRadius: "5px",
                minWidth: "120px",
                border: "1px solid var(--light-grey-color)",
                background: "var(--light-grey-color)",
                color: "#fff",
                margin: "10px 0",
                marginRight: "15px",
              },
              "& svg": {
                height: "100%",
              },
              "& .MuiTabs-flexContainer": {
                flexWrap: "wrap",
              },
            }}
          >
            <Tab label="Status" value="status" className="tab_btn" />
            <Tab label="Bids" value="bids" className="tab_btn" />
            <Tab label="Budgets" value="budgets" className="tab_btn" />
            <Tab label="Names" value="names" className="tab_btn" />
          </TabList>
          <TabPanel value="status" sx={{ p: 0 }}>
            <Box
              className="primary_color"
              sx={{
                flexGrow: 1,
                display: "flex",
                flexWrap: { xs: "wrap", sm: "nowrap" },
                padding: "10px 30px",
                borderRadius: "10px",
              }}
            >
              <TabContext value={status}>
                <TabList
                  orientation="vertical"
                  // variant="scrollable"
                  onChange={statusChange}
                  aria-label="lab API tabs example"
                  sx={{
                    width: "100%",
                    maxWidth: "17rem",
                    "& 	.Mui-selected": {
                      background: "var(--main-color) !important",
                      color: "#fff !important",
                    },
                    "& 	.MuiTabs-indicator": {
                      background: "none",
                    },
                    "& 	.tab_btn": {
                      height: "37px",
                      minHeight: "37px",
                      borderRadius: "5px",
                      minWidth: "120px",
                      background: "transparent",
                      display: "flex",
                      justifyContent: "flex-start",
                      color: "var(--grey-color)",
                      margin: "10px 0",
                      marginRight: "15px",
                      whiteSpace: "nowrap",
                    },
                    "& svg": {
                      height: "100%",
                    },
                    "& .MuiTabs-flexContainer": {
                      flexWrap: "wrap",
                    },
                  }}
                >
                  <Tab
                    label="Activate"
                    value="activate"
                    className="tab_btn"
                    icon={<PlayArrow />}
                    iconPosition="start"
                  />
                  <Tab
                    label="Pause"
                    value="pause"
                    className="tab_btn"
                    icon={<Pause />}
                    iconPosition="start"
                  /> 
                </TabList>
                <TabPanel value="activate" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <PlayArrow className="text" sx={{ opacity: "0.7" }} />
                    <Heading heading="Activate" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Activate your campaign.
                  </Typography>
                  <Box></Box>
                </TabPanel>
                <TabPanel value="pause" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Pause className="text" sx={{ opacity: "0.7" }} />
                    <Heading heading="Pause" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Pause your campaign.
                  </Typography>
                  <Box></Box>
                </TabPanel>
              </TabContext>
            </Box>
          </TabPanel>

           {/* BIDS */}

          <TabPanel value="bids" sx={{ p: 0 }}>
            <Box
              className="primary_color"
              sx={{
                flexGrow: 1,
                display: "flex",
                flexWrap: { xs: "wrap", sm: "nowrap" },
                padding: "10px 30px",
                borderRadius: "10px",
              }}
            >
              <TabContext value={bid}>
                <TabList
                  orientation="vertical"
                  // variant="scrollable"
                  onChange={bidChange}
                  aria-label="lab API tabs example"
                  sx={{
                    width: "100%",
                    maxWidth: "17rem",
                    "& 	.Mui-selected": {
                      background: "var(--main-color) !important",
                      color: "#fff !important",
                    },
                    "& 	.MuiTabs-indicator": {
                      background: "none",
                    },
                    "& 	.tab_btn": {
                      height: "37px",
                      minHeight: "37px",
                      borderRadius: "5px",
                      minWidth: "120px",
                      background: "transparent",
                      display: "flex",
                      justifyContent: "flex-start",
                      color: "var(--grey-color)",
                      margin: "10px 0",
                      marginRight: "15px",
                      whiteSpace: "nowrap",
                    },
                    "& svg": {
                      height: "100%",
                    },
                    "& .MuiTabs-flexContainer": {
                      flexWrap: "wrap",
                    },
                  }}
                >
                  <Tab
                    label="Increase bid"
                    value="increase"
                    className="tab_btn"
                    icon={<ArrowOutward />}
                    iconPosition="start"
                  />
                  <Tab
                    label="Decrease bid"
                    value="decrease"
                    className="tab_btn"
                    icon={<CallReceived />}
                    iconPosition="start"
                  />
                  <Tab
                    label="Set bid"
                    value="set"
                    className="tab_btn"
                    icon={<VerticalAlignTop />}
                    iconPosition="start"
                  />
                  <Tab
                    label="Adjust target ROAS "
                    value="roas"
                    className="tab_btn"
                    icon={<VerticalAlignBottom />}
                    iconPosition="start"
                  />
                </TabList>
                <TabPanel value="increase" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <ArrowOutward className="text" sx={{ opacity: "0.7" }} />
                    <Heading heading="Increase bid" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Increase bid of campaign when conditions performed.
                  </Typography>
                  <Box
                    sx={{
                      width: "100%",
                      maxWidth: "180px",
                      borderRadius: "30px",
                    }}
                  >
                    <SelectMenu
                      placeholder="Action Frequency"
                      data={timeSpan}
                    />
                  </Box>
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Increase by" />
                    <Box sx={{ pb: 1, display: "flex", width: "100%" }}>
                      <Box sx={{ width: "100%", minWidth: "272px" }}>
                        <CustomTextField placeholder="Increase by" />
                      </Box>
                      <Box sx={{ width: "100%" }}>
                        <SelectMenu
                          placeholder="Select"
                          data={[
                            {
                              value: "%",
                              name: "%",
                            },
                            {
                              value: "€",
                              name: "€",
                            },
                          ]}
                        />
                      </Box>
                    </Box>
                  </Box>
                  <Box>
                    <FormControl component="fieldset">
                      <FormGroup aria-label="position" row>
                        <FormControlLabel
                          value="end"
                          className="text_initial"
                          control={
                            <Checkbox
                              sx={{
                                "&.Mui-checked	": {
                                  color: "var(--main-color)",
                                },
                              }}
                            />
                          }
                          label="For active Campaigns only"
                          labelPlacement="end"
                        />
                      </FormGroup>
                    </FormControl>
                  </Box>
                </TabPanel>
                <TabPanel value="decrease" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <CallReceived className="text" sx={{ opacity: "0.7" }} />

                    <Heading heading="Decrease bid" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Decrease bid of campaign when conditions performed.
                  </Typography>
                  {/* <Box>
              <Button className="btn" startIcon={<Bolt />}>
                Once a day
              </Button>
            </Box> */}
                  <Box
                    sx={{
                      width: "100%",
                      maxWidth: "180px",
                      borderRadius: "30px",
                    }}
                  >
                    <SelectMenu
                      placeholder="Action Frequency"
                      data={timeSpan}
                    />
                  </Box>
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Decrease by" />
                    <Box sx={{ pb: 1, display: "flex", width: "100%" }}>
                      <Box sx={{ width: "100%", minWidth: "272px" }}>
                        <CustomTextField placeholder="Decrease by" />
                      </Box>
                      <Box sx={{ width: "100%" }}>
                        <SelectMenu
                          placeholder="Select"
                          data={[
                            {
                              value: "percentage",
                              name: "%",
                            },
                            {
                              value: "€",
                              name: "€",
                            },
                          ]}
                        />
                      </Box>
                    </Box>
                  </Box>
                  <Box>
                    <FormControl component="fieldset">
                      <FormGroup aria-label="position" row>
                        <FormControlLabel
                          value="end"
                          className="text_initial"
                          control={
                            <Checkbox
                              sx={{
                                "&.Mui-checked	": {
                                  color: "var(--main-color)",
                                },
                              }}
                            />
                          }
                          label="For active Campaigns only"
                          labelPlacement="end"
                        />
                      </FormGroup>
                    </FormControl>
                  </Box>
                </TabPanel>

                <TabPanel value="set" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <VerticalAlignTop
                      className="text"
                      sx={{ opacity: "0.7" }}
                    />
                    <Heading heading="Set bid" />
                  </Box>
                  <Typography
                    variant="caption"
                    className="text text_initial"
                    component="div"
                    sx={{ py: 1 }}
                  >
                    Control your bid in each auction. Set bid caps for all of
                    the Campaigns (published and inactive) in the campaign
                  </Typography>
                  <Divider />
                  {/* <Box sx={{ maxWidth: "300px" }}>
              <Heading heading="Frequency" />
              <Box sx={{ pb: 1 }}>
                <SelectMenu placeholder="Select Frequency" />
              </Box>
            </Box> */}
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Bid Strategy" />
                    <Box sx={{ pb: 1 }}>
                      <DropDown
                        placeholder="Select Bid Strategy"
                        data={bidStrategy}
                        setValue={setBidMenu}
                      />
                    </Box>
                  </Box>
                  <BidStrategy value={bidMenu} />
                </TabPanel>

                <TabPanel value="roas" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <VerticalAlignBottom
                      className="text"
                      sx={{ opacity: "0.7" }}
                    />
                    <Heading heading="Adjust target ROAS " />
                  </Box>
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Target ROAS" />
                    <Box sx={{ pb: 1 }}>
                      <CustomTextField placeholder="%Enter Target ROAS value" />
                    </Box>
                  </Box>
                </TabPanel>
              </TabContext>
            </Box>
          </TabPanel>
          <TabPanel value="budgets" sx={{ p: 0 }}>
            <Box
              className="primary_color"
              sx={{
                flexGrow: 1,
                display: "flex",
                flexWrap: { xs: "wrap", sm: "nowrap" },
                padding: "10px 30px",
                borderRadius: "10px",
              }}
            >
              <TabContext value={budget}>
                <TabList
                  orientation="vertical"
                  // variant="scrollable"
                  onChange={budgetChange}
                  aria-label="lab API tabs example"
                  sx={{
                    width: "100%",
                    maxWidth: "17rem",
                    "& 	.Mui-selected": {
                      background: "var(--main-color) !important",
                      color: "#fff !important",
                    },
                    "& 	.MuiTabs-indicator": {
                      background: "none",
                    },
                    "& 	.tab_btn": {
                      height: "37px",
                      minHeight: "37px",
                      borderRadius: "5px",
                      minWidth: "120px",
                      background: "transparent",
                      display: "flex",
                      justifyContent: "flex-start",
                      color: "var(--grey-color)",
                      margin: "10px 0",
                      marginRight: "15px",
                      whiteSpace: "nowrap",
                    },
                    "& svg": {
                      height: "100%",
                    },
                    "& .MuiTabs-flexContainer": {
                      flexWrap: "wrap",
                    },
                  }}
                >
                  <Tab
                    label="Increase budget"
                    value="increase"
                    className="tab_btn"
                    icon={<ArrowOutward />}
                    iconPosition="start"
                  />
                  <Tab
                    label="Decrease budget"
                    value="decrease"
                    className="tab_btn"
                    icon={<CallReceived />}
                    iconPosition="start"
                  />
                  <Tab
                    label="Set budget"
                    value="set"
                    className="tab_btn"
                    icon={<VerticalAlignTop />}
                    iconPosition="start"
                  />
                  {/* <Tab
              label="Adjust target ROAS"
              value="roas"
              className="tab_btn"
              icon={<VerticalAlignBottom />}
              iconPosition="start"
            /> */}
                </TabList>
                <TabPanel value="increase" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <ArrowOutward className="text" sx={{ opacity: "0.7" }} />
                    <Heading heading="Increase budget" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Increase budget of campaign when conditions performed.
                  </Typography>
                  <Box
                    sx={{
                      width: "100%",
                      maxWidth: "180px",
                      borderRadius: "30px",
                    }}
                  >
                    <SelectMenu
                      placeholder="Action Frequency"
                      data={timeSpan}
                    />
                  </Box>
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Increase by" />
                    <Box sx={{ pb: 1, display: "flex", width: "100%" }}>
                      <Box sx={{ width: "100%", minWidth: "272px" }}>
                        <CustomTextField placeholder="Increase by" />
                      </Box>
                      <Box sx={{ width: "100%" }}>
                        <SelectMenu
                          placeholder="Select"
                          data={[
                            {
                              value: "%",
                              name: "%",
                            },
                            {
                              value: "€",
                              name: "€",
                            },
                          ]}
                        />
                      </Box>
                    </Box>
                  </Box>
                  <Box>
                    <FormControl component="fieldset">
                      <FormGroup aria-label="position" row>
                        <FormControlLabel
                          value="end"
                          className="text_initial"
                          control={
                            <Checkbox
                              sx={{
                                "&.Mui-checked	": {
                                  color: "var(--main-color)",
                                },
                              }}
                            />
                          }
                          label="For active Campaigns only"
                          labelPlacement="end"
                        />
                      </FormGroup>
                    </FormControl>
                  </Box>
                </TabPanel>
                <TabPanel value="decrease" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <CallReceived className="text" sx={{ opacity: "0.7" }} />
                    <Heading heading="Decrease budget" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Decrease budget of campaign when conditions performed.
                  </Typography>
                  <Box
                    sx={{
                      width: "100%",
                      maxWidth: "180px",
                      borderRadius: "30px",
                    }}
                  >
                    <SelectMenu
                      placeholder="Action Frequency"
                      data={timeSpan}
                    />
                  </Box>
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Decrease by" />
                    <Box sx={{ pb: 1, display: "flex", width: "100%" }}>
                      <Box sx={{ width: "100%", minWidth: "272px" }}>
                        <CustomTextField placeholder="Decrease by" />
                      </Box>
                      <Box sx={{ width: "100%" }}>
                        <SelectMenu
                          placeholder="Select"
                          data={[
                            {
                              value: "%",
                              name: "%",
                            },
                            {
                              value: "€",
                              name: "€",
                            },
                          ]}
                        />
                      </Box>
                    </Box>
                  </Box>
                  <Box>
                    <FormControl component="fieldset">
                      <FormGroup aria-label="position" row>
                        <FormControlLabel
                          value="end"
                          control={
                            <Checkbox
                              sx={{
                                "&.Mui-checked	": {
                                  color: "var(--main-color)",
                                },
                              }}
                            />
                          }
                          label="For active Campaigns only"
                          labelPlacement="end"
                        />
                      </FormGroup>
                    </FormControl>
                  </Box>
                </TabPanel>
                <TabPanel value="set" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <VerticalAlignTop
                      className="text"
                      sx={{ opacity: "0.7" }}
                    />
                    <Heading heading="Set budget" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Set budget of campaign when conditions performed.
                  </Typography>
                  <Box
                    sx={{
                      width: "100%",
                      maxWidth: "180px",
                      borderRadius: "30px",
                    }}
                  >
                    <SelectMenu
                      placeholder="Action Frequency"
                      data={timeSpan}
                    />
                  </Box>
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Set to value" />
                    <Box sx={{ pb: 1, display: "flex", width: "100%" }}>
                      <Box sx={{ width: "100%", minWidth: "272px" }}>
                        <CustomTextField placeholder="Set to value" />
                      </Box>
                    </Box>
                  </Box>
                  <Box>
                    <FormControl component="fieldset">
                      <FormGroup aria-label="position" row>
                        <FormControlLabel
                          value="end"
                          className="text_initial"
                          control={
                            <Checkbox
                              sx={{
                                "&.Mui-checked	": {
                                  color: "var(--main-color)",
                                },
                              }}
                            />
                          }
                          label="For active Campaigns only"
                          labelPlacement="end"
                        />
                      </FormGroup>
                    </FormControl>
                  </Box>
                </TabPanel>
              </TabContext>
            </Box>
          </TabPanel>
          <TabPanel value="names" sx={{ p: 0 }}>
            <Box
              className="primary_color"
              sx={{
                flexGrow: 1,
                display: "flex",
                flexWrap: { xs: "wrap", sm: "nowrap" },
                padding: "10px 30px",
                borderRadius: "10px",
              }}
            >
              <TabContext value={names}>
                <TabList
                  orientation="vertical"
                  // variant="scrollable"
                  onChange={nameChange}
                  aria-label="lab API tabs example"
                  sx={{
                    width: "100%",
                    maxWidth: "17rem",
                    "& 	.Mui-selected": {
                      background: "var(--main-color) !important",
                      color: "#fff !important",
                    },
                    "& 	.MuiTabs-indicator": {
                      background: "none",
                    },
                    "& 	.tab_btn": {
                      height: "37px",
                      minHeight: "37px",
                      borderRadius: "5px",
                      minWidth: "120px",
                      background: "transparent",
                      display: "flex",
                      justifyContent: "flex-start",
                      color: "var(--grey-color)",
                      margin: "10px 0",
                      marginRight: "15px",
                      whiteSpace: "nowrap",
                    },
                    "& svg": {
                      height: "100%",
                    },
                    "& .MuiTabs-flexContainer": {
                      flexWrap: "wrap",
                    },
                  }}
                >
                  <Tab
                    label="Add to  name"
                    value="add"
                    className="tab_btn"
                    icon={<TextFields />}
                    iconPosition="start"
                  />
                  <Tab
                    label="Remove from name"
                    value="remove"
                    className="tab_btn"
                    icon={<TextFields />}
                    iconPosition="start"
                  />
                  <Tab
                    label="Replace text in name"
                    value="replace"
                    className="tab_btn"
                    icon={<TextFields />}
                    iconPosition="start"
                  />
                </TabList>
                <TabPanel value="add" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Box sx={{ pr: 1 }}>
                      <TextFields
                        sx={{
                          opacity: "0.7",
                          color: "var(--main-color)",
                        }}
                      />
                    </Box>

                    <Heading heading="Add to name" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Add a text or expression to the end of Campaign name.
                  </Typography>
                  <Divider />
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Text" />
                    <Box sx={{ pb: 1 }}>
                      <CustomTextField placeholder="Add to name" />
                    </Box>
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Text will not be added if selected items already contain it
                  </Typography>
                </TabPanel>
                <TabPanel value="remove" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Box sx={{ pr: 1 }}>
                      <TextFields
                        sx={{
                          opacity: "0.7",
                          color: "var(--main-color)",
                        }}
                      />
                    </Box>

                    <Heading heading="Remove from name" />
                  </Box>
                  {/* <Typography variant="caption" className="text">
              Add a text or expression to the end of Campaign name.
            </Typography> */}
                  <Divider />
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Text" />
                    <Box sx={{ pb: 1 }}>
                      <CustomTextField placeholder="Remove from name" />
                    </Box>
                  </Box>
                  {/* <Typography variant="caption" className="text">
              Text will not be added if selected items already contain
              it
            </Typography> */}
                </TabPanel>
                <TabPanel value="replace" sx={{ pt: 0, pb: 8, width: "100%" }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Box sx={{ pr: 1 }}>
                      <TextFields
                        sx={{
                          opacity: "0.7",
                          color: "var(--main-color)",
                        }}
                      />
                    </Box>

                    <Heading heading="Replace text in name" />
                  </Box>
                  <Typography variant="caption" className="text text_initial">
                    Replace a text from campaign name if conditions performed.
                    Text will not be added to the end of the name if the result
                    would produce duplication.
                  </Typography>
                  <Divider />
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Find" />
                    <Box sx={{ pb: 1 }}>
                      <CustomTextField placeholder="Find  name" />
                    </Box>
                  </Box>
                  <Box sx={{ maxWidth: "300px" }}>
                    <Heading heading="Replace with" />
                    <Box sx={{ pb: 1 }}>
                      <CustomTextField placeholder="Replace  name" />
                    </Box>
                  </Box>
                  {/* <Typography variant="caption" className="text">
              Text will not be added if selected items already contain
              it
            </Typography> */}
                </TabPanel>
              </TabContext>
            </Box>
          </TabPanel>
        </TabContext>
      </Box>
    </>
  );
};

export default AutomationTabsOptions;
