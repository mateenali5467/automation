import React from "react";
import styled from "styled-components";
import { TextField, Autocomplete, Box } from "@mui/material";
const DropDown = ({ placeholder, setValue, name, data, dataTwo }) => {
    const onAutoCompleteChange = (e, newValue) => {
        setValue(newValue.label)
    };
  return (
    <>
    
    <AutoCompleteStyled>
        <Box>
          <Autocomplete
            disablePortal
            fullWidth
            onChange={(e, newValue) => onAutoCompleteChange(e, newValue)}
            options={data}
            className="primary_color "
            sx={{
              fieldset: {
                border: "1px solid",
                borderRadius: "5px",
                borderColor: "inherit",
              },
              label: {
                color: "inherit",
                "&.Mui-focused": {
                  color: "inherit",
                },
              },
              svg: {
                color: "inherit",
              },
              "& .MuiButtonBase-root": {
                color: "inherit",
              },
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                placeholder={placeholder}
                className="pack_man_input "
                sx={{ label: { top: "-2px" } }}
                inputProps={{
                  className: "border ",
                  ...params.inputProps,
                }}
                InputProps={{
                  ...params.InputProps,
                  className: "text",
                  style: {
                    padding: "6px",
                  },
                }}
              />
            )}
          />
        </Box>
      </AutoCompleteStyled>
    
    </>
  )
}

export default DropDown





const AutoCompleteStyled = styled.section`
  width: 100%;
  .pack_man_input {
    .MuiOutlinedInput-root {
      &:hover fieldset {
        border-color: inherit;
      }
      &.Mui-focused fieldset {
        border-color: inherit;
      }
    }
  }
`;
