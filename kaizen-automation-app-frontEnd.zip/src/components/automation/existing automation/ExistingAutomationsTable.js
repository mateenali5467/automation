import React from "react";
import {
  Box,
  Typography,
  Tab,
  Grid,
  TextField,
  TableContainer,
  Table,
  TableBody,
  TableCell,
  TableRow,
  TableHead,
  Checkbox,
  Tooltip,
  FormGroup,
  Switch,
  styled as muiStyled,
  Button,
} from "@mui/material";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import {
  Facebook,
  Google,
  ContentCopy,
  Edit,
  RadioButtonChecked,
  Delete,
} from "@mui/icons-material";

const AntSwitch = muiStyled(Switch)(({ theme, customTheme }) => ({
    width: 28,
    height: 16,
    padding: 0,
    display: "flex",
    "&:active": {
      "& .MuiSwitch-thumb": {
        width: 15,
      },
      "& .MuiSwitch-switchBase.Mui-checked": {
        transform: "translateX(9px)",
      },
    },
    "& .MuiSwitch-switchBase": {
      padding: 2,
      color: customTheme === "dark" ? "#707787" : "#fff",
      "&.Mui-checked": {
        transform: "translateX(12px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          opacity: 1,
          backgroundColor: theme.palette.mode === "dark" ? "#177ddc" : "#6259ca",
        },
      },
    },
    "& .MuiSwitch-thumb": {
      boxShadow: "0 2px 4px 0 rgb(0 35 11 / 20%)",
      width: 12,
      height: 12,
      borderRadius: 6,
      transition: theme.transitions.create(["width"], {
        duration: 200,
      }),
    },
    "& .MuiSwitch-track": {
      borderRadius: 16 / 2,
      opacity: 1,
      backgroundColor: customTheme === "dark" ? "#fff" : "#707787",
      boxSizing: "border-box",
    },
  }));

const ExistingAutomationsTable = ({ automationData }) => {
  const navigate = useNavigate();
  const { theme: customTheme } = useSelector((store) => store.theme);
  const EditData = (id) => {
    localStorage.setItem("edit_id", id);
    navigate("/create-automation");
  };
  return (
    <>
      {automationData && automationData.length > 0 ? (
        automationData.map((item, index) => (
          
          <>
                <TableRow
              sx={{
                "&:last-child td, &:last-child th": {
                  border: 0,
                },
                td: {
                  whiteSpace: "nowrap",
                },
              }}
            >
              {/* <TableCell component="th" scope="row">
        <Checkbox
          className="text"
          sx={{
            "&.Mui-checked": {
              color: "var(--main-color) !important",
            },
          }}
          key={item.uid}
          checked={checkedStudents.includes(item.uid)}
          onChange={(event) =>
            handleChange2(event.target.checked, item.uid)
          }
          inputProps={{ "aria-label": "controlled" }}
        />
      </TableCell> */}
              <TableCell align="center" className="text">
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    "& svg": {
                      fontSize: "21px",
                    },
                  }}
                >
                  <FormGroup>
                    <AntSwitch
                      customTheme={customTheme}
                      // className="text"
                      inputProps={{
                        "aria-label": "ant design",
                        //   className: "aaaaaaaaaaaaaaaaaaaaaaa",
                      }}
                    />
                  </FormGroup>
                  <Box sx={{ ml: 2, cursor: "pointer" }}>
                    <Tooltip title="copy ...." arrow>
                      <ContentCopy />
                    </Tooltip>
                  </Box>
                  <Box
                    sx={{ ml: 2, cursor: "pointer" }}
                    onClick={(e) => EditData(item.id)}
                  >
                    <Tooltip title="Edit...." arrow>
                      <Edit />
                    </Tooltip>
                  </Box>
                  <Box sx={{ ml: 2, cursor: "pointer" }}>
                    <Tooltip title="Delete" arrow>
                      <Delete />
                    </Tooltip>
                  </Box>
                </Box>
              </TableCell>

              <TableCell align="center" className="text">
                {item?.name}
              </TableCell>
              <TableCell align="center" className="text">
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <RadioButtonChecked sx={{ color: "var(--main-color)" }} />
                  <Typography varient="body" sx={{ pl: 1 }}>
                    Running
                  </Typography>
                </Box>
              </TableCell>
              <TableCell align="center" className="text">
                {item?.scope}
              </TableCell>
              <TableCell align="center" className="text">
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <Facebook className="text" />
                  <Typography varient="body" sx={{ pl: 1 }}>
                    Facebook Ads
                  </Typography>
                </Box>
              </TableCell>
              <TableCell align="center" className="text">
                <Typography
                  varient="body"
                  sx={{
                    color: "#fff",
                    background: "var(--light-grey-color)",
                    borderRadius: "5px ",
                    padding: "4px 6px",
                  }}
                >
                  {`${item?.kpi} > $${item?.matric}`}
                  {item?.set_rules.map((data) => (
                    <div>{`${data?.kpi} ${data.comparison} $${data?.matric} ${data?.condition}`}</div>
                  ))}
                  {/* {"Traffic Source Spent > $ 1000"} */}
                </Typography>
              </TableCell>
            </TableRow>
          </>
        ))
      ) : (
        <></>
      )}
    </>
  );
};

export default ExistingAutomationsTable;
