import React from "react";
import {
  Box,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
} from "@mui/material";

const CampaignsTab = ({ existingCampaigns }) => {
  return (
    <Box>
      <TableContainer className="primary_color">
        <Table
          sx={{
            minWidth: 650,
            "& th": {
              whiteSpace: "nowrap",
            },
            "& .table_th": {
              // border: "1px solid #fff",
              padding: "6px 15px",
            },
          }}
          aria-label="simple table"
        >
          <TableHead>
            <TableRow sx={{ background: "var(--main-color)" }}>
              <TableCell
                className="table_th"
                align="left"
                sx={{ color: "#fff" }}
              >
                {/* <Checkbox
              checked={
                checkedStudents.length === estudiantes.length
              }
              indeterminate={
                checkedStudents.length !== estudiantes.length &&
                checkedStudents.length > 0
              }
              onChange={(event) =>
                handleChange1(event.target.checked)
              }
              sx={{
                color: "#fff",
                "&.Mui-checked , &.MuiCheckbox-indeterminate": {
                  color: "#fff",
                },
              }}
            /> */}
                Campaign Name
              </TableCell>
              <TableCell
                align="center"
                sx={{ color: "#fff" }}
                className="table_th"
              >
                Campaign Type
              </TableCell>
              <TableCell
                align="center"
                sx={{ color: "#fff" }}
                className="table_th"
              >
                Campaign ID
              </TableCell>
              <TableCell
                align="center"
                sx={{ color: "#fff" }}
                className="table_th"
              >
                Budget
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {existingCampaigns?.map((item) => (
              <TableRow
                sx={{
                  "&:last-child td, &:last-child th": {
                    // borderBottom: 0,
                    border: 0,
                  },
                  td: {
                    whiteSpace: "nowrap",
                  },
                  //   td: {
                  //     borderRight: "1px solid rgba(224, 224, 224, 1)",
                  //   },
                }}
              >
                <TableCell align="left" className="text">
                  {item.campaign_name}
                </TableCell>
                <TableCell align="center" className="text">
                  {item.campaign_type}
                </TableCell>
                <TableCell align="center" className="text">
                  {item.campaign_id}
                </TableCell>
                <TableCell align="center" className="text">
                  {item.budget}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default CampaignsTab;
