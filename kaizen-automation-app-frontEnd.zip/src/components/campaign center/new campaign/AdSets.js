import "./Adset.css";

import React from "react";
import styled from "styled-components";
import Heading from "../../common/Heading";

import { baseURL } from "config/endpoint";
import { INSTANCE } from "../../../config/axiosInstance";


import { useTheme } from "@mui/material/styles";

import {
  Box,
  Typography,
  Button,
  FormLabel,
  FormHelperText,
  FormControl,
  RadioGroup,
  Radio,
  FormControlLabel,
  Grid,
  TextField,
  Link,
  Checkbox,
  FormGroup,
  Alert,
  AlertTitle,
} from "@mui/material";

import dayjs, { Dayjs } from "dayjs";

import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import Tabs from "@mui/material/Tabs";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";

import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";

import TreeView from "@mui/lab/TreeView";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import TreeItem from "@mui/lab/TreeItem";

import RadioButon from "../../common/RadioButon";

import { useFormik } from "formik";
import { getAdSetApi } from "slices/adSetSlices";
import * as yup from "yup";
import ValidationTextField from "../../common/ValidationTextField";
import SelectMenu from "../../common/SelectMenu";
import SwitchButton from "../../common/SwitchButton";
import { Info, Launch, AttachMoney, Add, BugReport } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { getCurrentTab } from "slices/currentTabSlices";

import { useState, useEffect } from "react";
import { TreeSelect } from "antd";

import OutlinedInput from "@mui/material/OutlinedInput";
import Chip from "@mui/material/Chip";

import FullScreenLoader from "../../../components/common/FullScreenLoader";

import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";

import DatePicker from "@mui/lab/DatePicker";

import TimePicker from "@mui/lab/TimePicker";

import DateTimePicker from "@mui/lab/DateTimePicker";

import {
  fetchTreeDataAPI,
  fetchLanguageListAPI,
  fetchOSDataAPI,
  fetchCarriersDataAPI,
} from "slices/appSlice";

const schedule = [
  {
    value: "auto",
    label: "Run ads continuosly starting right now",
  },
  {
    value: "man",
    label: "Set start and end dates",
  },
];

const placement = [
  {
    value: "PLACEMENT_TYPE_AUTOMATIC",
    label: "Automatic",
    caption:
      "Maximize your budget and help show your ads to more people, Facebook's delivery system will allocate your ad set's budger across multiple placements based on where they re likely to perform best",
  },
  {
    value: "PLACEMENT_TYPE_NORMAL",
    label: "Manual",
    caption:
      "Manually choose the places to show your ad. The more placements you select the more opportunites you'll have to reach your target audience and achieve your business goals ",
  },
];

const optimizationLocationData = [
  {
    value: "website",
    label: "Website",
  },
  {
    value: "App",
    label: "App",
  },
];

const { SHOW_PARENT } = TreeSelect;

const dataSend = {
  advertiser_id: "7067431159843569665",
  campaign_id: "1766213674007554",
  adgroup_name: "ELECTRONICS",
  operation_status: "ENABLE",
  bid_type: "BID_TYPE_CUSTOM",
  budget_mode: "BUDGET_MODE_DAY",
  //  budget: 100,
  schedule_type: "SCHEDULE_FROM_NOW",
  optimization_goal: "",
  //promotion_type: "WEBSITE",
  // billing_event: "CPC",
  // bid_price: 20,
  location_ids: [],
  //placement_type: "PLACEMENT_TYPE_AUTOMATIC",
  // promotion_type: "WEBSITE",
};

const AdSets = () => {

  const dispatch = useDispatch();

  const currentDate = new Date();
  currentDate.setDate(currentDate.getDate() + 5);

  const currentDateT = new Date();
  currentDateT.setDate(currentDateT.getDate() + 1);

  const [startDate, setStartDate] = useState(currentDateT);
  const [endDate, setEndDate] = useState(currentDate);

  const [startDateAuto, setStartDateAuto] = useState(currentDateT);

  const [scheduleValue, setScheduleValue] = useState("Auto");

  const { campaignSlices, adSetGroup } = useSelector((res) => res);

  const [Formvalue, setFormValue] = useState("customTarget");
  const [valueMultiSelect, setValueMultiSelect] = useState();
  const [demographicsAge, setDemographicsAge] = useState({
    all: true,
    AGE_18_24: false,
    AGE_25_34: false,
    AGE_35_44: false,
    AGE_45_54: false,
    AGE_55_100: false,
  });


  const [osVersion, setOsVersion] = useState("");
  const [countryList, setCountryList] = useState([]);
  const [personName, setPersonName] = useState([]);
  const [appName, setAppName] = useState([]);
  const [languageName, setLanguageName] = useState([]);
  const [languageList, setLanguageList] = useState([]);
  const [appData, setAppData] = useState(["Bulter App Norway"]);
  const [setBudget, setBudgetValue] = useState("");

  const [locationData, setLocationData] = useState(["2659994"]);

  const [languageData, setLanguageData] = useState(["en"]);

  const [treeData, setTreeData] = useState([]);

  const [OsData, setOsData] = useState([]);
  const [currentOs, setCurrentOs] = useState("ALL");

  const [carriesData, setCarriesData] = useState([]);
  const [currentCarrier, setCurrentCarrier] = useState("ALL");

  const [age, setAge] = useState("");
  const [open, setOpen] = useState(false);

  const [genderState, setGenderState] = useState("GENDER_UNLIMITED");
  const [budgetMode, setBudgetMode] = useState("BUDGET_MODE_DAY");

  const [checkRadioDisable, setcheckRadioDisable] = useState(false);

  const [valueDate, setValueDate] = React.useState(new Date());

  const [placementData, showSelectPlacement] = useState(false);

  const [placementCurrent, setPlacementCurrent] = useState({
    tiktok: true,
    pangle: true,
  });

  const [currentPlacement, setCurrentPlacement] = useState(
    "AUTOMATIC_PLACEMENT"
  );

  const [optimizationLocationCurrent, setOptimizationLocation] =
    useState("WEBSITE");

  const [goal, setGoal] = React.useState("");

  const [locationError, setLocationError] = useState(false);

  const [optimizationError, setOptimizationError] = useState(false);

  const [inputValueBid, setInputValueBid] = useState("");

  const [bidStrategy, setBidStrategy] = useState("BID_TYPE_NO_BID");

  const [budgetError, setBudgetError] = useState(false);
  const [bidPriceError, setBidPriceError] = useState(false);
  
  const [strategyError, setStrategyErro] = useState(false);

  const [inputValueBidOptional, setInputValueBidOptional] = useState("");

  const [capValue, setCapValue] = useState("threeSeven"); // State for the selected radio button value

  const [currentOsIos, setCurrentOsIos] = useState('All');


  const [OsDataIos,setOsDataIos] = useState('');

  const [errorSubmit,setErrorSubmitState] = useState(false)

  const automationTargeting = false;
   // GET VALUES FROM CAMPAIGN SLICES
   const {
    customTarget,
    autoTarget,
    app: appUiRender,
    isPlacementDouble: isPlacement,
    optimization_location: optimizationLocation
  } = campaignSlices.data[0].data.customObj;


  //OTHER FUNCTIONS 


    // handle change function for the select input
    const handleChangeOSIos = (event) => {
      setCurrentOsIos(event.target.value);
    };



  const handleChangeCap = (event) => {
    setCapValue(event.target.value); // Update the state with the selected radio button value
  };

  const handleInputChangeBidOptional = (event) => {
    setInputValueBidOptional(event.target.value);
  };

  const getBidStrategy = (event) => {
    setBidStrategy(event.target.value);
    console.log(event.target.value);
  };

  const handleInputChangeBid = (event) => {
    const { value } = event.target;
    // Remove non-numeric characters using regular expression
    const numericValue = value.replace(/[^0-9]/g, "");
    setInputValueBid(numericValue);
  };

  const handleChangePlacement = (event) => {
    setPlacementCurrent({
      ...placementCurrent,
      [event.target.name]: event.target.checked,
    });
  };

  const hanldeOptimizationLocation = (e) => {
    setOptimizationLocation(e.target.value);
  };

  const handleChangeAge = (event) => {
    setAge(event.target.value);
  };

  const handleCloseAge = () => {
    setOpen(false);
  };

  const handleOpenAge = () => {
    setOpen(true);
  };

  const validationSchema = yup.object({
    adset_name: yup.string().required("Required"),
  });

  const handleChangeBudget = (event) => {
    setBudgetValue(event.target.value);
  };

  const handleChangeBudgetMode = (event) => {
    setBudgetMode(event.target.value);

    if (event.target.value === "BUDGET_MODE_TOTAL") {
      setScheduleValue('manual')
      setcheckRadioDisable(true);
    } else {
      setScheduleValue('Auto')
      setcheckRadioDisable(false);
    }
    
  };

  const formik = useFormik({
    initialValues: {
      adset_name: "",
      placement: "PLACEMENT_TYPE_AUTOMATIC",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      const trueKeys = Object.entries(demographicsAge)
        .filter(([key, value]) => value === true)
        .map(([key]) => key);
 
   //ASSIGN OBJECT VALUES
      Object.assign(dataSend, {
        campaign_id: campaignSlices.data[0].data.campaign_id,
        adgroup_name: values.adset_name,
        placements: values.placement,
        location_ids: locationData,
        language: languageData,
        gender: genderState,
        age: trueKeys,
        budget_mode: budgetMode,
        targeting: Formvalue,
        bid_type: "BID_TYPE_CUSTOM",
        delivery_modes: "STANDARD",
      });

      //  // console.log(trueKeys);
      //  console.log("locationData",locationData);

      //  console.log("languageData",languageData);

      // console.log("carriesData",currentCarrier);
      //  console.log("age",age);

      // let startDatestr = new Date(startDate.toString());
      // let endDatestr = new Date(endDate.toString());
      // let startDateAutoStr = new Date(startDateAuto.toString());

      // let monthStart = startDatestr.getMonth() + 1;
      // let yearStart = startDatestr.getFullYear();
      // let dayStart = startDatestr.getDate();
      // let timeHours = startDatestr.getHours();
      // let timeMinute = startDatestr.getMinutes();
      // let getSecond = startDatestr.getSeconds();

      // let monthEnd = endDatestr.getMonth() + 1;
      // let yearEnd = endDatestr.getFullYear();
      // let dayEnd = endDatestr.getDate();
      // let timeHoursEnd = endDatestr.getHours();
      // let timeMinuteEnd = endDatestr.getMinutes();
      // let getSecondEnd = endDatestr.getSeconds();

      // let monthStartAuto = startDateAutoStr.getMonth() + 1;
      // let yearStartAuto = startDateAutoStr.getFullYear();
      // let dayStartAuto = startDateAutoStr.getDate();
      // let timeHoursAuto = startDateAutoStr.getHours();
      // let timeMinuteAuto = startDateAutoStr.getMinutes();
      // let getSecondAuto = startDateAutoStr.getSeconds();

      // if (scheduleValue === "manual") {
      //   dataSend.schedule_start_time = `${yearStart}-${monthStart}-${dayStart} ${timeHours}:${timeMinute}:${getSecond}`;

      //   dataSend.schedule_end_time = `${yearEnd}-${monthEnd}-${dayEnd} ${timeHoursEnd}:${timeMinuteEnd}:${getSecondEnd}`;
      // }


      // if (scheduleValue === "Auto") {
      //   dataSend.schedule_start_time = `${yearStartAuto}-${monthStartAuto}-${dayStartAuto} ${timeHoursAuto}:${timeMinuteAuto}:${getSecondAuto}`;
      // }



      //DATE AND TIME HANDLE HOC FUNCTION
      const formatDateStr = (dateStr) => {
        let date = new Date(dateStr);
        let month = date.getMonth() + 1;
        let year = date.getFullYear();
        let day = date.getDate();
        let hours = date.getHours();
        let minutes = date.getMinutes();
        let seconds = date.getSeconds();
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
      }
       // DATE FUNCTIONS
      if (scheduleValue === "manual") {
        dataSend.schedule_start_time = formatDateStr(startDate.toString());
        dataSend.schedule_end_time = formatDateStr(endDate.toString());
      } 
      else if (scheduleValue === "Auto") {
        dataSend.schedule_start_time = formatDateStr(startDateAuto.toString());
        dataSend.schedule_end_time = formatDateStr(endDate.toString());
      }


      if (dataSend.optimization_goal === "CONVERSION") {
        dataSend.billing_event = "OCPM";
        dataSend.bid_display_mode = "OCPM";
      } else if (dataSend.optimization_goal === "FOLLOW") {
        dataSend.billing_event = "OCPM";
        dataSend.bid_display_mode = "OCPM";
      } else if (dataSend.optimization_goal === "PROFILE_VISIT") {
        dataSend.billing_event = "CPV";
        dataSend.bid_display_mode = "CPV";
      } else {
        dataSend.billing_event =
          campaignSlices.data[0].data.customObj.billing_event;
      }


      if (campaignSlices.data[0].data.customObj.isPlacementDouble) {
        if (currentPlacement === "AUTOMATIC_PLACEMENT") {
          dataSend.placement_type = "PLACEMENT_TYPE_AUTOMATIC";
          delete dataSend.placements;
        } else {
          dataSend.placement_type = "PLACEMENT_TYPE_AUTOMATIC";
          let placementTypes = [];
          if (placementCurrent.tiktok) {
            placementTypes.push("PLACEMENT_TIKTOK");
          }
          if (placementCurrent.pangle) {
            placementTypes.push("PLACEMENT_PANGLE");
          }
          dataSend.placements = placementTypes;
        }
      } else {
        dataSend.placement_type = "PLACEMENT_TYPE_NORMAL";
        dataSend.placements = ["PLACEMENT_TIKTOK"];
      }

      if (
        campaignSlices.data[0].data.customObj.objective_type ===
          "LEAD_GENERATION" ||
        campaignSlices.data[0].data.customObj.objective_type === "TRAFFIC"
      ) {
        dataSend.promotion_type = optimizationLocationCurrent;
      } else {
        delete dataSend.promotion_type;
      }

      // Optimization Error Handling
      // if (dataSend.location_ids.length === 0) {
      //   setLocationError(true);
      //   setTimeout(() => {
      //     setLocationError(false);
      //   }, 5000);
      // } else if (dataSend.optimization_goal === "") {
      //   setOptimizationError(true);
      //   setTimeout(() => {
      //     setOptimizationError(false);
      //   }, 5000);
      // } else {
      //   if (campaignSlices.data[0].data.customObj.budget_optimize_on) {
      //     dataSend.budget = campaignSlices.data[0].data.customObj.budget;
      //     if (bidStrategy === "BID_TYPE_CUSTOM") {
      //       if (inputValueBid !== "" && Number(inputValueBid) < 20) {
      //         dataSend.bid_price = inputValueBid;
      //         console.log(dataSend);
      //         //  dispatch(getAdSetApi(dataSend))
      //       } else {
      //         alert("error");
      //         setStrategyErro(true);
      //       }
      //     } else {
      //       if (campaignSlices.data[0].data.customObj.bid_control) {
      //         if (Number(inputValueBidOptional) >= 2) {
      //           dataSend.bid_price = inputValueBidOptional;
      //           //   dispatch(getAdSetApi(dataSend))
      //           console.log(dataSend);
      //         } else {
      //           alert("Bid error");
      //         }
      //       } else {
      //         delete dataSend.bid_price;
      //         console.log(dataSend);
      //         // dispatch(getAdSetApi(dataSend))
      //       }
      //     }

      //     //    dispatch(getAdSetApi(dataSend))
      //   } else {
      //     if (Number(setBudget) < 20) {
      //       setBudgetError(true);
      //       alert("Budget  error");
      //     } else {
      //       dataSend.budget = setBudget;

      //       if (bidStrategy === "BID_TYPE_CUSTOM") {
      //         if (inputValueBid !== "" && Number(inputValueBid) < 20) {
      //           dataSend.bid_price = inputValueBid;
      //           //  console.log(dataSend);
      //           // dispatch(getAdSetApi(dataSend))
      //         } else {
      //           alert("error");
      //           setStrategyErro(true);
      //         }
      //       } else {
      //         if (campaignSlices.data[0].data.customObj.bid_control) {
      //           if (Number(inputValueBidOptional) >= 2) {
      //             dataSend.bid_price = inputValueBidOptional;
      //             //  dispatch(getAdSetApi(dataSend))
      //             //  console.log(dataSend)
      //           } else {
      //             alert("Bid error");
      //             //console.log(dataSend)
      //           }
      //         } else {
      //           delete dataSend.bid_price;
      //           //  console.log(dataSend);
      //           //  dispatch(getAdSetApi(dataSend))
      //         }
      //       }
      //     }
      //   }
      // }

      // Update assignBidPrice to return a boolean indicating success or failure
      // const assignBidPrice = (inputValue, bidOptional) => {
      //   if (bidStrategy === "BID_TYPE_CUSTOM") {
      //     if (inputValue !== "" && Number(inputValue) < 20) {
      //       dataSend.bid_price = inputValue;
      //       return true;
      //     } else {
      //       alert("error");
      //       setStrategyErro(true);
      //       return false;
      //     }
      //   } else {
      //     if (campaignSlices.data[0].data.customObj.bid_control) {
      //       if (Number(bidOptional) >= 2) {
      //         dataSend.bid_price = bidOptional;
      //         return true;
      //       } else {
      //         alert("Bid error");
      //         return false;
      //       }
      //     }
      //   }
      // };

      // // Update processDataSend to check the success of assignBidPrice
      // const processDataSend = (budgetValue, inputValue, bidOptional) => {
      //   if (Number(budgetValue) >= 20) {
      //     dataSend.budget = budgetValue;
      //     return assignBidPrice(inputValue, bidOptional); // Return the success of assignBidPrice
      //   } else {
      //     alert("Budget  error");
      //     setBudgetError(true);
      //     return false;
      //   }
      // };

      // Your existing functions

      const assignBidPrice = (inputValue, bidOptional) => {
        if (bidStrategy === "BID_TYPE_CUSTOM") {
          if (inputValue !== "" && Number(inputValue) < 20) {
            dataSend.bid_price = inputValue;
            return true;
          } else {
           // setBidPriceError(true);
            // alert("error");
            setStrategyErro(true);
            return false;
          }
        } else {
          if (campaignSlices.data[0].data.customObj.bid_control) {
            if (Number(bidOptional) >= 2) {
              dataSend.bid_price = bidOptional;
              return true;
            } else {
            //  alert("Bid error");
            setBidPriceError(true);
              return false;
            }
          }
        }
      };

      const processDataSend = (budgetValue, inputValue, bidOptional) => {
        if (Number(budgetValue) >= 20) {
          dataSend.budget = budgetValue;
          setBudgetError(false);
          return assignBidPrice(inputValue, bidOptional); // Return the success of assignBidPrice
        } else {
          // alert("Budget  error");
          setBudgetError(true);
          return false;
        }
      };

      // New refactored functions

      const setErrorMessage = (setErrorFunction, timeout = 5000) => {
        setErrorFunction(true);
        setTimeout(() => setErrorFunction(false), timeout);
      };

      const processSendData = (inputValueBid, inputValueBidOptional) => {
        let budgetValue = campaignSlices.data[0].data.customObj
          .budget_optimize_on
          ? campaignSlices.data[0].data.customObj.budget
          : setBudget;
        return processDataSend(
          budgetValue,
          inputValueBid,
          inputValueBidOptional
        );
      };

      const checkForErrorsAndDispatch = (
        inputValueBid,
        inputValueBidOptional
      ) => {
        if (dataSend.location_ids.length === 0) {
          setErrorMessage(setLocationError);
        } else if (dataSend.optimization_goal === "") {
          setErrorMessage(setOptimizationError);
        } else if (processSendData(inputValueBid, inputValueBidOptional)) {
          dispatch(getAdSetApi(dataSend));
          console.log(dataSend)
        }
      };

      //// Main code Objectives Conditions

      if (campaignSlices.data[0].data.customObj.objective_type === "REACH") {
        const {
          data: {
            customObj: { frequency },
            campaign_id,
          },
        } = campaignSlices.data[0];

        const frequencyMap = { threeSeven: [2, 3], noOnceDay: [1, 1] };

        Object.assign(dataSend, {
          campaign_id,
          adgroup_name: values.adset_name,
          location_ids: locationData,
          language: languageData,
          gender: genderState,
          age: trueKeys,
          budget_mode: budgetMode,
          targeting: Formvalue,
          delivery_modes: "OPTIMIZE",
        });

        if (frequency) {
          [dataSend.frequency, dataSend.frequency_schedule] =
            frequencyMap[capValue] || [];
          delete dataSend.bid_type;
        } else {
          delete dataSend.frequency;
          delete dataSend.frequency_schedule;
        }

       checkForErrorsAndDispatch(inputValueBid, inputValueBidOptional);

        //dispatch(getAdSetApi(dataSend));

      

      // if (
      //   dataSend.budget === "" ||
      //   Number(dataSend.budget) < 20
      // ) {
      //   setBudgetError(true);
      //   return false;
      // } else {
      //   setBudgetError(false);
      // }
      
      // if (
      //   dataSend.bid_price === "" ||
      //   Number(dataSend.bid_price) >= 30
      // ) {
      //   setBidPriceError(true);
      //   return false;
      // } else {
      //   setBidPriceError(false);
      // }
      
      // if (
      //   (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price < dataSend.budget) ||
      //   (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_NO_BID" && dataSend.budget !== "") ||
      //   (!isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price < dataSend.budget)
      // ) {
      //   dataSend.conversion_bid_price = dataSend.bid_price;
      //   console.log("Video_Views", dataSend);
      //   dispatch(getAdSetApi(dataSend));
      // } else {
      //   setErrorSubmitState(true);
      //   return false;
      // }


      // console.log("Video_Views", dataSend);


      } else if (
        campaignSlices.data[0].data.customObj.objective_type === "VIDEO_VIEWS"
      ) {
        // if (dataSend.bid_price === "") {
        //   alert("Bid Value Not Empty");
        // } else {
        //   dataSend.bid_price = inputValueBidOptional;

        dataSend.bid_display_mode = "CPV";

        checkForErrorsAndDispatch(inputValueBid, inputValueBidOptional);



      } else if (
        campaignSlices.data[0].data.customObj.objective_type === "TRAFFIC"
      ) {

        //TRAFFIC OBJECT //
        const billingEventMap = {
          CLICK: "CPC",
          TRAFFIC_LANDING_PAGE_VIEW: "OCPM",
        };

        dataSend.billing_event = billingEventMap[dataSend.optimization_goal];
        delete dataSend.bid_display_mode;

        const isBudgetOptimized =
          campaignSlices.data[0].data.customObj.budget_optimize_on;

        //  dataSend.bid_type = isBudgetOptimized
        //   ? "BID_TYPE_NO_BID"
        //   : "BID_TYPE_CUSTOM";

        if (isBudgetOptimized) {
          dataSend.bid_type = bidStrategy;
          dataSend.budget = campaignSlices.data[0].data.customObj.budget;
          delete dataSend.conversion_bid_price;

          if (bidStrategy === "BID_TYPE_CUSTOM") {
             dataSend.bid_price = inputValueBid;
          }
           else {
            delete dataSend.bid_price;
          }

        } else {
          dataSend.budget = setBudget;
          dataSend.bid_type = "BID_TYPE_CUSTOM";
          dataSend.bid_price = inputValueBid;
        }


    

        if (
          dataSend.budget === "" ||
          Number(dataSend.budget) < 20
        ) {
          setBudgetError(true);
          return false;
        } else {
          setBudgetError(false);
        }
        
        if (
          dataSend.bid_price === "" ||
          Number(dataSend.bid_price) >= 30
        ) {
          setBidPriceError(true);
          return false;
        } else {
          setBidPriceError(false);
        }
        
        if (
          (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price < dataSend.budget) ||
          (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_NO_BID" && dataSend.budget !== "") ||
          (!isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price < dataSend.budget)
        ) {
          dataSend.conversion_bid_price = dataSend.bid_price;
          console.log("Video_Views", dataSend);
          dispatch(getAdSetApi(dataSend));
        } else {
          setErrorSubmitState(true);
          return false;
        }


        console.log("Video_Views", dataSend);
    
        // TRAFFIC OBJECT //
      } else if (
        campaignSlices.data[0].data.customObj.objective_type ===
        "LEAD_GENERATION"
      ) {
        // if(bid){

        // }

        //  if(bidStrategy === "BID_TYPE_NO_BID"){
        //         delete dataSend.conversion_bid_price;
        //         delete dataSend.bid_price;
        //         dataSend.bid_type = "BID_TYPE_NO_BID"
        //  }
        //  if(bidStrategy === "BID_TYPE_CUSTOM"){
        //      dataSend.conversion_bid_price = inputValueBid
        //      dataSend.bid_price = inputValueBid
        //      dataSend.bid_type = "BID_TYPE_CUSTOM"
        //  }

        dataSend.promotion_type = "LEAD_GENERATION";
        dataSend.promotion_target_type = "INSTANT_PAGE";
        // dataSend.bid_price = inputValueBid;
        // dataSend.conversion_bid_price = inputValueBid;

      
        const isBudgetOptimized =
        campaignSlices.data[0].data.customObj.budget_optimize_on;

      //  dataSend.bid_type = isBudgetOptimized
      //   ? "BID_TYPE_NO_BID"
      //   : "BID_TYPE_CUSTOM";


      if (isBudgetOptimized) {
        dataSend.bid_type = bidStrategy;
        dataSend.budget = campaignSlices.data[0].data.customObj.budget;
        delete dataSend.conversion_bid_price;

        if (bidStrategy === "BID_TYPE_CUSTOM") {
           dataSend.bid_price = inputValueBid;
        }
         else {
          delete dataSend.bid_price;
        }

      } else {
        dataSend.budget = setBudget;
        dataSend.bid_type = "BID_TYPE_CUSTOM";
        dataSend.bid_price = inputValueBid;
      }


      if (
        dataSend.budget === "" ||
        Number(dataSend.budget) < 20
      ) {
        setBudgetError(true);
        return false;
      } else {
        setBudgetError(false);
      }
      
      if (
        dataSend.bid_price === "" ||
        Number(dataSend.bid_price) >= 30
      ) {
        setBidPriceError(true);
        return false;
      } else {
        setBidPriceError(false);
      }
      
      if (
        (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price < dataSend.budget) ||
        (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_NO_BID" && dataSend.budget !== "") ||
        (!isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price < dataSend.budget)
      ) {
        dataSend.conversion_bid_price = dataSend.bid_price;
        console.log("Video_Views", dataSend);
        dispatch(getAdSetApi(dataSend));
      } else {
        setErrorSubmitState(true);
        
      }
        


      } else if (
        campaignSlices.data[0].data.customObj.objective_type === "ENGAGEMENT"
      ) {
        
        const isBudgetOptimized =
        campaignSlices.data[0].data.customObj.budget_optimize_on;

      //  dataSend.bid_type = isBudgetOptimized
      //   ? "BID_TYPE_NO_BID"
      //   : "BID_TYPE_CUSTOM";


      if (isBudgetOptimized) {
        dataSend.bid_type = bidStrategy;
        dataSend.budget = campaignSlices.data[0].data.customObj.budget;
        delete dataSend.conversion_bid_price;

        if (bidStrategy === "BID_TYPE_CUSTOM") {
           dataSend.bid_price = inputValueBid;
        }
         else {
          delete dataSend.bid_price;
        }

      } else {
        dataSend.budget = setBudget;
        dataSend.bid_type = "BID_TYPE_CUSTOM";
        dataSend.bid_price = inputValueBid;
      }


      if (
        dataSend.budget === "" ||
        Number(dataSend.budget) < 20
      ) {
        setBudgetError(true);
        return false;
      } else {
        setBudgetError(false);
      }
      
      if (
        dataSend.bid_price === "" ||
        Number(dataSend.bid_price) >= 30
      ) {
        setBidPriceError(true);
        return false;
      } else {
        setBidPriceError(false);
      }
      
      if (
        (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price < dataSend.budget) ||
        (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_NO_BID" && dataSend.budget !== "") ||
        (!isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price < dataSend.budget)
      ) {
        dataSend.conversion_bid_price = dataSend.bid_price;
        console.log("Video_Views", dataSend);
        dispatch(getAdSetApi(dataSend));
      } else {
        setErrorSubmitState(true);
        
      }
        

      


      } else if (
        campaignSlices.data[0].data.customObj.objective_type === "APP_PROMOTION"
      ) {

  
        dataSend.bid_price = inputValueBid;
        dataSend.conversion_bid_price = inputValueBid;

        dataSend.app_id = "7067436742374162433";
        dataSend.operating_systems = ["ANDROID"];
        dataSend.promotion_type = "WEBSITE";

        const isBudgetOptimized =
        campaignSlices.data[0].data.customObj.budget_optimize_on;

      //  dataSend.bid_type = isBudgetOptimized
      //   ? "BID_TYPE_NO_BID"
      //   : "BID_TYPE_CUSTOM";


      if (isBudgetOptimized) {
        dataSend.bid_type = bidStrategy;
        dataSend.budget = campaignSlices.data[0].data.customObj.budget;

        if (bidStrategy === "BID_TYPE_CUSTOM") {
          dataSend.bid_price = inputValueBid;
        } else {
          delete dataSend.bid_price;
        }
      
      } 
      else {
        dataSend.budget = setBudget;
        dataSend.bid_type = "BID_TYPE_CUSTOM";
        dataSend.bid_price = inputValueBid;
      }

      
      if (
        ((isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price !== "" && Number(dataSend.budget) < 20 && dataSend.bid_price < dataSend.budget) ||
        (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_NO_BID" && dataSend.budget !== "") ||
        (!isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price !== "" && dataSend.bid_price < dataSend.budget)) &&
        dataSend.budget !== "" && Number(dataSend.budget) >= 20
      ) {
        dataSend.conversion_bid_price = dataSend.bid_price;
        console.log("Video_Views", dataSend);
        dispatch(getAdSetApi(dataSend));
      } else {
        alert("Budget is required and should be greater than or equal to 20. and Bid is smaller then Budget");
        return false;
      }

      console.log("Video_Views", dataSend);

      

      } 
      else if (
        campaignSlices.data[0].data.customObj.objective_type === "WEB_CONVERSIONS"
      ) {

        const isBudgetOptimized =
        campaignSlices.data[0].data.customObj.budget_optimize_on;

      //  dataSend.bid_type = isBudgetOptimized
      //   ? "BID_TYPE_NO_BID"
      //   : "BID_TYPE_CUSTOM";


      if (isBudgetOptimized) {
        dataSend.bid_type = bidStrategy;
        dataSend.budget = campaignSlices.data[0].data.customObj.budget;

        if (bidStrategy === "BID_TYPE_CUSTOM") {
          dataSend.bid_price = inputValueBid;
        } else {
          delete dataSend.bid_price;
        }
      
      } 
      else {
        dataSend.budget = setBudget;
        dataSend.bid_type = "BID_TYPE_CUSTOM";
        dataSend.bid_price = inputValueBid;
      }

      
      if (
        ((isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price !== "" && Number(dataSend.budget) < 20 && dataSend.bid_price < dataSend.budget) ||
        (isBudgetOptimized && dataSend.bid_type === "BID_TYPE_NO_BID" && dataSend.budget !== "") ||
        (!isBudgetOptimized && dataSend.bid_type === "BID_TYPE_CUSTOM" && dataSend.bid_price !== "" && dataSend.bid_price < dataSend.budget)) &&
        dataSend.budget !== "" && Number(dataSend.budget) >= 20
      ) {
        dataSend.conversion_bid_price = dataSend.bid_price;
        console.log("Video_Views", dataSend);
        dispatch(getAdSetApi(dataSend));
      } else {
        alert("Budget is required and should be greater than or equal to 20. and Bid is smaller then Budget");
        return false;
      }

      console.log("Video_Views", dataSend);

      

      } 
      
      
      else {
        console.log("not select");
      }

      // dispatch(getAdSetApi(dataSend));
    },
  });

  const handleChange = (event, newValue) => {
    setFormValue(newValue);
  };

  const onChange = (newValue) => {
    setValueMultiSelect(newValue);
  };

  const osVersionGet = (event) => {
    setOsVersion(event.target.value);
  };

  const getGender = (e) => {
    setGenderState(e.target.value);
  };

  const getOS = async (e) => {
    setCurrentOs(e.target.value);

    const { data } = await INSTANCE.get("/campaign/get_OSVersion", {
      params: {
        os_type: e.target.value,
      },
    });

    const updatedArr = data.data.data.os_versions.map(
      ({ os_id, version, ...rest }) => ({
        ...rest,
        value: os_id,
      })
    );

    setOsData(updatedArr);
  };

  const getOSRender = async (e) => {
    const { data } = await INSTANCE.get("/campaign/get_OSVersion", {
      params: {
        os_type: "ALL",
      },
    });

    return data.data.data.os_versions;
    //setOsData(data.data.data.os_versions);
  };

  const getCarriers = async (e) => {
    const { data } = await INSTANCE.get("/campaign/get_device_models_DB");

    const models = data.data.data.device_models;

    function findChildren(arr, id) {
      let children = [];
      for (let device of arr) {
        if (device.device_model_id === id) {
          children.push({
            title: device.device_model_name,
            value: device.device_model_id,
          });
        }
      }
      return children;
    }

    let brands = models.filter((device) => device.level === "BRAND");
    let newBrandsArray = brands.map((brand) => {
      let children = [];
      for (let childId of brand.child_device_ids) {
        let series = findChildren(models, childId);
        children = [...children, ...series];
      }
      return {
        title: brand.device_model_name,
        value: brand.device_model_id,
        children: children,
      };
    });

    return newBrandsArray;
  };

  const ageChange = (event) => {
    setDemographicsAge({
      ...demographicsAge,
      [event.target.name]: event.target.checked,
    });
  };

  //DEMOGRAPHICS LOCATION
  const locationChange = (event) => {
    setLocationData(event);
  };

  //DEMOGRAPHICS LANGAUGE
  const languageChange = (event) => {
    setLanguageData(event);
  };

  const tProps = {
    treeData,
    valueMultiSelect,
    onChange,
    treeCheckable: true,
    showCheckedStrategy: SHOW_PARENT,
    placeholder: "Please select",

    style: {
      width: "100%",
      overFlow: "scroll",
    },
  };

  const carriesChange = (event) => {
    setCurrentCarrier(event);
  };

  const carriesProps = {
    treeData: carriesData,
    currentCarrier,
    onChange: carriesChange,
    treeCheckable: true,
    showCheckedStrategy: SHOW_PARENT,
    placeholder: "Please select",

    style: {
      width: "100%",
      overFlow: "scroll",
    },
  };

  const countryRes = async () => {
    const { data } = await INSTANCE.get(
      "/campaign/location-from-DB"
      //   // {
      //   //   params: {
      //   //       objective_type: campaignSlices.data[0].data.customObj.objective_type

      //   //   }
      // }
    );

    const getRegion = data.data.data.region_info;

    const generateNewArray = (locations) => {
      const newArray = [];

      const generateHierarchy = (location) => {
        const { location_id, name, next_level_ids, level } = location;

        const children = [];

        if (next_level_ids && next_level_ids.length > 0) {
          for (const childId of next_level_ids) {
            const child = locations.find((obj) => obj.location_id === childId);
            if (child) {
              const childHierarchy = generateHierarchy(child);
              children.push(childHierarchy);
            }
          }
        }

        return {
          name,
          level,
          location_id,
          children,
        };
      };

      for (const location of locations) {
        if (location.level === "COUNTRY") {
          const countryHierarchy = generateHierarchy(location);
          newArray.push(countryHierarchy);
        }
      }

      return newArray;
    };

    const hierarchicalArray = generateNewArray(getRegion);

    function updateProperties(obj) {
      obj.title = obj.name;
      obj.label = obj.name;
      delete obj.name;

      obj.value = obj.location_id;
      delete obj.location_id;

      if (obj.children && obj.children.length > 0) {
        obj.children.forEach((child) => {
          updateProperties(child);
        });
      }
    }

    const updatedArray = hierarchicalArray.map((obj) => {
      const updatedObj = { ...obj };
      updateProperties(updatedObj);
      return updatedObj;
    });

    return updatedArray;
  };

  const langaugeRes = async () => {
    const { data } = await INSTANCE.get("/campaign/language");

    const locationArray = data.data.data.languages;

    let languageObjects = locationArray.map((language) => {
      return { value: language.code, title: language.name };
    });

    return languageObjects;
    // setLanguageList(languageObjects)
  };

  const fetchAllData = async () => {
    try {
      const [treeData, languageList, osData, carriesData] = await Promise.all([
        countryRes(),
        langaugeRes(),
        getOSRender(),
        getCarriers(),
      ]);

      setTreeData(treeData);
      setLanguageList(languageList); // Ensure that setLanguageList is declared
      setOsData(osData);
      setOsDataIos(osData)
      setCarriesData(carriesData);

      // Ensure that setCarriesData is declared;
    } catch (error) {
      console.error(error);
    }
  };


  const getMinimumBid = async ()=>{
    const data = {
      "objective_type": campaignSlices.data[0].data.customObj.objective_type,
      "location_ids": locationData
    }
   try{
    const res = await INSTANCE.post("/campaign/get-recommended-bid",{data:data});
    console.log(res)
    console.log("recommendedBid",res.data.bid)
  
   }
   catch(error){

   }
  }

 

  useEffect(() => {
    fetchAllData();
    getMinimumBid();
  }, [locationData]);



  const LocationProps = {
    treeData,
    locationData,
    onChange: locationChange,
    treeCheckable: true,
    showCheckedStrategy: SHOW_PARENT,
    placeholder: "Please select",
    style: {
      width: "100%",
      overFlow: "scroll",
    },
  };

  const LanguageProps = {
    treeData: languageList,
    languageData,
    onChange: languageChange,
    treeCheckable: true,
    showCheckedStrategy: SHOW_PARENT,
    placeholder: "Please select",
    style: {
      width: "100%",
      overFlow: "scroll",
    },
  };

  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const handleChangeLoca = (event) => {
    const {
      target: { value },
    } = event;
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const handleChangeLanguage = (event) => {
    const {
      target: { value },
    } = event;
    setLanguageName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const scheduleHandleChange = (event) => {
    setScheduleValue(event.target.value);
  };

  const handleChangeOS = (event) => {
     setCurrentOs(event.target.value);
  };

 

  const showAlert = ({ type, message }) => {
    if (type === "success") {
      setTimeout(() => {
        dispatch(getCurrentTab(3));
      }, 0);
      return false;
    }

    return (
      <Alert variant="filled" severity={type}>
        <AlertTitle>{message}</AlertTitle>
      </Alert>
    );
  };

  const getPlacement = (e) => {
    setCurrentPlacement(e.target.value);
    if (e.target.value === "SELECT_PLACEMENT") {
      showSelectPlacement(true);
    } else {
      showSelectPlacement(false);
    }
  };

  function formatKey(key) {
    return key
      .toLowerCase()
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  }

  const trueGoals =
    campaignSlices.data[0].data.customObj.optimization_goal.filter(
      (item) => item.goal
    );

  let vvv = "";

  if (trueGoals.length === 1) {
    // Return both name and value for the single goal item
    //setGoal(trueGoals[0].value); // Set the state here
    dataSend.optimization_goal = trueGoals[0].value.trim();

    vvv = (
      <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Goal</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={trueGoals[0].value} // Set the value to the first item's value
          defaultValue={trueGoals[0].value}
          label="Goal"
          onChange={(e) => {
            setGoal(e.target.value); // Set the state here
            dataSend.optimization_goal = e.target.value.trim();
          }}
        >
          {trueGoals.map((item) => (
            <MenuItem value={item.value}>{item.name}</MenuItem>
          ))}
        </Select>
      </FormControl>
    );
  } else if (trueGoals.length > 1) {
    vvv = (
      <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Optimization Goal</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={goal}
          defaultValue={goal}
          label="Goal"
          onChange={(e) => {
            setGoal(e.target.value); // Set the state here
            dataSend.optimization_goal = e.target.value.trim();
          }}
        >
          {trueGoals.map((item) => (
            <MenuItem value={item.value}>{item.name}</MenuItem>
          ))}
        </Select>
      </FormControl>
    );
  }

  function getStyles(name, personName, theme) {
    return {
      fontWeight:
        personName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }

  function getStylesLanguage(name, languageName, theme) {
    return {
      fontWeight:
        languageName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }

  const theme = useTheme();

  return (
    <>
      <AdSetsStyled>
        <form onSubmit={formik.handleSubmit}>
          <Box>
            <Heading heading="Ad set name" />
            <ValidationTextField
              formik={formik}
              name="adset_name"
              placeholder="Please Enter Ad set name"
            />
          </Box>
          {appUiRender && (
            <Box>
              <Heading heading="App" />
              <FormControl sx={{ m: 1, width: 300 }}>
                <InputLabel id="demo-controlled-open-select-label">
                  App
                </InputLabel>
                <Select
                  labelId="demo-controlled-open-select-label"
                  id="demo-controlled-open-select"
                  open={open}
                  onClose={handleCloseAge}
                  onOpen={handleOpenAge}
                  value={age}
                  label="App"
                  onChange={handleChangeAge}
                >
                  <MenuItem value={10}>Bullet NorwaY aPP</MenuItem>
                </Select>
              </FormControl>
            </Box>
          )}

          {/* <Box>

            <Heading heading="Audiences" />
            <Button variant="contained" className="btn">
              Select Audience
            </Button>
            <Button
              variant="contained"
              className="btn"
              startIcon={<Add sx={{ color: "#fff" }} />}
              sx={{ ml: 2 }}
            >
              New Audience
            </Button>
          </Box> */}

          {optimizationLocation && (
            <Box>
              <Heading heading="Optimization Location" variant="h6" />

              <FormControl>
                <RadioGroup
                  column
                  size="small"
                  defaultValue="WEBSITE"
                  aria-labelledby="demo-row-radio-buttons-group-label"
                  name="row-radio-buttons-group"
                  onChange={hanldeOptimizationLocation}
                >
                  <FormControlLabel
                    value="WEBSITE"
                    control={<Radio size="small" />}
                    label="Website"
                  />
                  <FormControlLabel
                    value="APP"
                    control={<Radio size="small" />}
                    label="App"
                  />
                </RadioGroup>
              </FormControl>

              {/* <RadioButon
                data={optimizationLocationData}
                formik={formik}
                name="optimizationLocationData"
                error
              /> */}
            </Box>
          )}

          <Box>
            <Heading heading="Targeting" variant="h6" />

            <TabContext value={Formvalue}>
              {/* TAB LIST */}
              <Tabs
                value={Formvalue}
                onChange={handleChange}
                aria-label="icon label tabs example"
              >
                {customTarget && (
                  <Tab label="Custom Targeting" value="customTarget"></Tab>
                )}

                {autoTarget && (
                  <Tab
                    label="Automatic Targeting"
                    value="automationTargeting"
                  ></Tab>
                )}
              </Tabs>
              {/* TAB LIST */}

              {/* TAB PABNEL 1 */}
              <TabPanel value="customTarget">
                <TreeView
                  aria-label="file system navigator"
                  defaultCollapseIcon={<ExpandMoreIcon />}
                  defaultExpandIcon={<ChevronRightIcon />}
                  sx={{ flexGrow: 1, maxWidth: 400, overflowY: "auto" }}
                >
                  {/* Demographics */}
                  <TreeItem sx={{ mb: 2 }} nodeId="1" label="Demographics">
                    <Box>
                      <Box sx={{ my: 1 }}>
                        <Heading heading="Location" variant="p" />

                        {/* <Select
                          sx={{ m: 1, width: 300 }}
                          labelId="demo-multiple-chip-label"
                          id="demo-multiple-chip"
                          multiple
                          value={locationData}
                          displayEmpty
                          onChange={locationChange}
                          input={<OutlinedInput />}
                          renderValue={(selected) => {
                            if (selected.length === 0) {
                              return <em>Location</em>;
                            }
                            return (
                              <Box
                                sx={{
                                  display: "flex",
                                  flexWrap: "wrap",
                                  gap: 0.5,
                                }}
                              >
                                {selected.map((value) => (
                                  <Chip key={value} label={value} />
                                ))}
                              </Box>
                            );
                          }}
                          MenuProps={MenuProps}
                        >
                          {countryList.map((data) => (
                            <MenuItem
                              key={data.name}
                              value={data.name}
                              style={getStyles(data.name, personName, theme)}
                            >
                              <Checkbox
                                checked={personName.indexOf(data.name) > -1}
                              />
                              {data.name}
                            </MenuItem>
                          ))}
                        </Select> */}

                        <TreeSelect
                          defaultValue={["2750405"]}
                          {...LocationProps}
                        />

                        {locationError && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            Select Location
                          </p>
                        )}
                      </Box>
                      <Box sx={{ my: 1 }}>
                        <Heading
                          sx={{ mb: 1 }}
                          heading="Language"
                          variant="p"
                        />

                        <TreeSelect
                          style={{ width: "30px", height: "50px" }}
                          {...LanguageProps}
                        />
                      </Box>

                      <Box sx={{ my: 1 }}>
                        <Heading sx={{ mb: 1 }} heading="Gender" variant="p" />
                        <FormControl>
                          <RadioGroup
                            row
                            size="small"
                            defaultValue="GENDER_UNLIMITED"
                            aria-labelledby="demo-row-radio-buttons-group-label"
                            name="row-radio-buttons-group"
                            onChange={getGender}
                          >
                            <FormControlLabel
                              value="GENDER_UNLIMITED"
                              control={<Radio size="small" />}
                              label="All"
                            />
                            <FormControlLabel
                              value="GENDER_FEMALE"
                              control={<Radio size="small" />}
                              label="Female"
                            />
                            <FormControlLabel
                              value="GENDER_MALE"
                              control={<Radio size="small" />}
                              label="Male"
                            />
                          </RadioGroup>
                        </FormControl>
                      </Box>

                      <Box sx={{ my: 1 }}>
                        <Heading heading="Age" variant="p" />

                        <FormGroup
                          sx={{ display: "flex", flexDirection: "row" }}
                        >
                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.all}
                                onChange={ageChange}
                                name="all"
                                defaultChecked
                              />
                            }
                            label="All"
                          />
                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_13_17}
                                onChange={ageChange}
                                name="AGE_13_17"
                              />
                            }
                            label="13-17"
                          />
                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_18_24}
                                onChange={ageChange}
                                name="AGE_18_24"
                              />
                            }
                            label="18-24"
                          />
                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_25_34}
                                onChange={ageChange}
                                name="AGE_25_34"
                              />
                            }
                            label="25-34"
                          />

                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_45_54}
                                onChange={ageChange}
                                name="AGE_45_54"
                              />
                            }
                            label="45-54"
                          />

                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_55_100}
                                onChange={ageChange}
                                name="AGE_55_100"
                              />
                            }
                            label="55+"
                          />
                        </FormGroup>
                      </Box>
                    </Box>
                  </TreeItem>
                  {/* Demographics */}

                  {/* Audience Start  */}
                  {/* <TreeItem sx={{ mb: 2 }} nodeId="4" label="Audience">
                    <Box>
                      <Heading heading="Includes" />
                      <TreeSelect />
                    </Box>
                    <Box sx={{ mt: 2 }}>
                      <Heading heading="Exclude" />
                      <TreeSelect />
                    </Box>
                  </TreeItem> */}
                  {/* Audiesnce ENd */}

                  {/* Devices Start */}
                  <TreeItem sx={{ mb: 2 }} nodeId="2" label="Device">
                    <Box>
                      <Heading heading="Operating System" variant="p" />
                      {/* <FormControl>
                        <RadioGroup
                          row
                          size="small"
                          aria-labelledby="demo-row-radio-buttons-group-label"
                          name="row-radio-buttons-group"
                          value={currentOs}
                          onChange={getOS}
                        >
                          <FormControlLabel
                            value="ALL"
                            control={<Radio size="small" />}
                            label="All"
                          />
                          <FormControlLabel
                            value="ANDROID"
                            control={<Radio size="small" />}
                            label="Android"
                          />
                          <FormControlLabel
                            value="IOS"
                            control={<Radio size="small" />}
                            label="Ios"
                          />
                        </RadioGroup>
                      </FormControl> */}
                    </Box>

                    <Box sx={{ pl: 1 }}>
                      <Box sx={{  }}>
  
                        <Box>
                          {/* <SelectMenu
                            placeholder="All"
                            disabled={false}
                            paddingProps={true}
                            sx={{ height: "250" }}
                            data={OsData}
                           // value={currentOs}
                            onChange={handleChangeOS}
                          /> */}

                          <Heading heading="Android" variant="p" />
                          <FormControl fullWidth >
    
      <Select
      
        id="os-select"
        value={currentOs}
        onChange={handleChangeOS}
       // set this to control the Select's height
      >

      {OsData.filter(item => item.name.includes('Android')).map((item, index) => (
          <MenuItem key={index} value={item.os_id}>
            {item.name}
          </MenuItem>
        ))}

      </Select>
    </FormControl>

    <Heading heading="iOS" variant="p" />
                          <FormControl fullWidth >
    
                          <Select
      id="os-select"
      value={currentOsIos}
      onChange={handleChangeOSIos}
    >
    
      { OsDataIos &&  OsDataIos.filter(item => item.name.includes('iOS')).map((item, index) => (
        <>
      
        <MenuItem key={index} value={item.os_id}>
          {item.name}
        </MenuItem>
        </>
       ))
    
      }
        
      
    </Select>

    
    </FormControl>


                          
                        </Box>
                      </Box>

                      <Box sx={{ }}>
                        <Heading heading="Device Model" variant="p" />

                        {/* <SelectMenu
                            placeholder="All"
                            disabled={false}
                            paddingProps={true}
                            sx={{height:"250"}}
                            data={carriesData}
                          /> */}

                        <TreeSelect {...carriesProps}   />

                      </Box>

                      <Box sx={{ my: 1 }}>
                        <Heading heading="Connection Type" variant="p" />

                        <FormGroup
                          sx={{ display: "flex", flexDirection: "row" }}
                        >
                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.all}
                                onChange={ageChange}
                                name="all"
                              />
                            }
                            label="All"
                          />
                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_13_17}
                                onChange={ageChange}
                                name="AGE_13_17"
                                disabled={demographicsAge.all}
                              />
                            }
                            label="WIFI"
                          />
                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_18_24}
                                onChange={ageChange}
                                name="AGE_18_24"
                                disabled={demographicsAge.all}
                              />
                            }
                            label="2G"
                          />
                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_25_34}
                                onChange={ageChange}
                                name="AGE_25_34"
                                disabled={demographicsAge.all}
                              />
                            }
                            label="3G"
                          />

                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_45_54}
                                onChange={ageChange}
                                name="AGE_45_54"
                                disabled={demographicsAge.all}
                              />
                            }
                            label="4G"
                          />

                          <FormControlLabel
                            control={
                              <Checkbox
                                size="small"
                                checked={demographicsAge.AGE_55_100}
                                onChange={ageChange}
                                name="AGE_55_100"
                                disabled={demographicsAge.all}
                              />
                            }
                            label="5G"
                          />
                        </FormGroup>
                      </Box>

                      {/* <Box sx={{ my: 1 }}>
                        <Heading heading="Carriers" variant="p" />

                        <TreeSelect
                          style={{ padding: "10px" }}
                          {...carriesProps}
                        />
                      </Box> */}

                      {/* <Box sx={{ my: 1 }}>
                        <Heading
                          heading="Internet service provider"
                          variant="p"
                        />
                        <TreeSelect style={{ padding: "10px" }} {...tProps} />
                      </Box> */}

                      {/* <Box sx={{ my: 1 }}>
                        <Heading heading="Device Price" variant="p" />
                      </Box> */}
                      
                    </Box>
                  </TreeItem>
                  {/* Devises End */}

                  {/* Interests & Behaviours */}
                  {/* <TreeItem
                    sx={{ mb: 2 }}
                    nodeId="5"
                    label="Interests & Behaviours"
                  >
                    cccccccccdsadsdsdad
                  </TreeItem> */}

                  {/* Interests & Behaviours */}

                  {/* Targeting expansion */}
                  {/* <TreeItem nodeId="3" label="Targeting expansion">
                    <Box sx={{ ml: 4 }}>
                      <Heading heading="Targeting Expansion" variant="p" />
                    </Box>
                  </TreeItem> */}
                  {/* Targeting expansion  */}
                </TreeView>
              </TabPanel>
              {/* TAB PABNEL 1 */}

              {/* TAB PABNEL 2 */}
              <TabPanel value="automationTargeting">
                <Box>
                  <Heading heading="Locations" variant="p" />
                  <TreeSelect defaultValue={["2750405"]} {...LocationProps} />
                </Box>
                <Box sx={{ mt: 2 }}>
                  <Heading heading="Languages" variant="p" />
                  <TreeSelect {...tProps} />
                </Box>
              </TabPanel>
              {/* TAB PABNEL 2 */}
            </TabContext>
          </Box>

          <Box sx={{ mb: 2 }}>
            <Heading heading="Placements" />

            {campaignSlices.data[0].data.customObj.isPlacementDouble ? (
              <FormControl>
                <RadioGroup
                  column
                  size="small"
                  defaultValue="AUTOMATIC_PLACEMENT"
                  aria-labelledby="demo-row-radio-buttons-group-label"
                  name="row-radio-buttons-group"
                  onChange={getPlacement}
                >
                  <FormControlLabel
                    value="AUTOMATIC_PLACEMENT"
                    control={<Radio size="small" />}
                    label="Automatic Placement"
                  />
                  <p style={{ fontSize: "13px", color: "#ccc" }}>
                    Automatic Show your app across supported placement
                  </p>
                  <FormControlLabel
                    value="SELECT_PLACEMENT"
                    control={<Radio size="small" />}
                    label="Select Placement"
                  />
                  <p style={{ fontSize: "13px", color: "#ccc" }}>
                    Manually Choose your targeting
                  </p>
                </RadioGroup>
              </FormControl>
            ) : (
              <Box sx={{}}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    Placement
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value="tiktok" // Set the value to the first item's value
                    defaultValue="tiktok"
                    label="Placement"
                    onChange={getPlacement}
                  >
                    <MenuItem value="tiktok">TikTok</MenuItem>
                  </Select>
                </FormControl>
              </Box>
            )}

            {placementData && (
              <Box sx={{ ml: 2 }}>
                <FormGroup>
                  <FormControlLabel
                    control={
                      <Checkbox
                        size="small"
                        checked={placementCurrent.tiktok}
                        onChange={handleChangePlacement}
                        name="tiktok"
                      />
                    }
                    label="TikTok"
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        size="small"
                        checked={placementCurrent.pangle}
                        onChange={handleChangePlacement}
                        name="pangle"
                      />
                    }
                    label="Pangle"
                  />
                </FormGroup>
              </Box>
            )}

            {/* 
            <RadioButon
              data={placement}
              formik={formik}
              name="placement"
              error
            /> */}
          </Box>

          <Box>
            <Heading heading="Budget" />
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              {!campaignSlices.data[0].data.customObj.budget_optimize_on && (
                <Box sx={{ display: "flex", flexDirection: "row" }}>
                  <FormControl
                    sx={{ ml: 1, minWidth: 80 }}
                    size="large"
                    required
                    variant="outlined"
                  >
                    {/* <InputLabel id="demo-simple-select-autowidth-label">
                  Budget
                </InputLabel> */}



                {
  campaignSlices.data[0].data.customObj.budget_mode === "Daily"  &&    <Select
                      labelId="demo-simple-select-autowidth-label"
                      id="demo-simple-select-autowidth"
                      value={budgetMode}
                      onChange={handleChangeBudgetMode}
                      autoWidth
                      inputProps={{ "aria-label": "Without label" }}
                    >

<MenuItem value="BUDGET_MODE_DAY">Daily</MenuItem>

                    </Select>
}


{
  campaignSlices.data[0].data.customObj.budget_mode === "Lifetime"  &&    <Select
                      labelId="demo-simple-select-autowidth-label"
                      id="demo-simple-select-autowidth"
                      value={budgetMode}
                      onChange={handleChangeBudgetMode}
                      autoWidth
                      inputProps={{ "aria-label": "Without label" }}
                    >

          <MenuItem value="BUDGET_MODE_DAY">Daily</MenuItem>
           <MenuItem value="BUDGET_MODE_TOTAL">Lifetime</MenuItem>

                    </Select>
}


                 
                    {/* //  <FormHelperText>Required</FormHelperText> */}
                  </FormControl>

                  <Box sx={{ display: "flex", flexDirection: "column" }}>
                    <TextField
                      sx={{ ml: 2 }}
                      error={setBudget < 20}
                      onChange={handleChangeBudget}
                      value={setBudget}
                      label="Budget"
                      variant="outlined"
                      inputProps={{
                        pattern: "[0-9]*",
                        inputMode: "numeric",
                        style: { textAlign: "right" },
                        startAdornment: <></>, // Empty element to position cursor on the left
                      }}
                      onKeyPress={(event) => {
                        const regex = /[0-9]|\./;
                        const key = String.fromCharCode(event.charCode);
                        if (!regex.test(key)) {
                          event.preventDefault();
                        }
                      }}
                    />

                    <Typography
                      sx={{
                        ml: 2,
                        mt: 1,
                      }}
                      style={{
                        color: "red !important",
                      }}
                      variant="caption"
                      className="text"
                    >
                      Select Budget Must be larger then 20
                    </Typography>
                  </Box>
                </Box>
              )}
              {campaignSlices.data[0].data.customObj.budget_optimize_on && (
                <Box>
                  <p>
                    User Campaign Budget{" "}
                    {campaignSlices.data[0].data.customObj.budget_mode ===
                    "Daily"
                      ? "Daily"
                      : "LifeTime"}{" "}
                    : EUR {campaignSlices.data[0].data.customObj.budget}:00{" "}
                  </p>
                </Box>
              )}
            </Box>
          </Box>

          <Box>
            <Heading heading="Schedule" />

            {/* <RadioButon data={schedule} formik={formik} name="schedule" error />
             */}

            <FormControl sx={{ mb: 1 }}>
              <RadioGroup
                small
                aria-labelledby="demo-radio-buttons-group-label"
                defaultValue={'Auto'}
                name="radio-buttons-group"
                value={scheduleValue}
                onChange={scheduleHandleChange}
              >
  <FormControlLabel
                  disabled={checkRadioDisable}
                  value="Auto"
                  control={<Radio />}
                  label={
                    <Typography
                      style={{
                        color: "red",
                      }}
                      variant="Heading"
                      className="text"
                    >
                      Run ads continuosly starting right now
                    </Typography>
                  }
                />
              

         <Box sx={{ mt: 1 }}>
                  {scheduleValue === "Auto" && !checkRadioDisable && (
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                      {/* <DatePicker
                  label="Start Date"
                  value={startDateAuto}
                  minDate={new Date()}
                  onChange={(newValue) => {
                    setStartDateAuto(newValue);
                  }}
                  renderInput={(params) => <TextField {...params} />}
                /> */}

                      <DateTimePicker
                        label="Date and time picker"
                        value={startDateAuto}
                        variant="inline"
                        views={["year", "month", "day", "hours", "minutes"]}
                        minDateTime={
                          new Date(
                            new Date().setDate(new Date().getDate() + 1), // Increment the day by one
                            new Date().setHours(new Date().getHours() + 1) // Increment the hour by one
                          )
                        }
                        onChange={(newValue) => {
                          setStartDateAuto(newValue);
                        }}
                        renderInput={(params) => <TextField {...params} />}
                      />
                    </LocalizationProvider>
                  )}
                </Box>

              
                

                 <FormControlLabel
                  disabled={checkRadioDisable}
                  value="manual"
                  control={<Radio />}
                  label={
                    <Typography
                      style={{
                        color: "red",
                      }}
                      variant="Heading"
                      className="text"
                    >
                      Set Start and End Date
                    </Typography>
                  }
                />
              


             

           


              </RadioGroup>
            </FormControl>

            {/* DATE PICKER */}

            {scheduleValue === "manual" &&  (
              <Box sx={{ display: "flex", gap: 2, flexDirection: "column" }}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  {/* <DatePicker
        label="Start Date"
        minDate={new Date()}
        value={startDate}
        onChange={(newValue) => {
          setStartDate(newValue);
        }}
        renderInput={(params) => <TextField {...params} />}
      /> */}

                  <DateTimePicker
                    label="Start Date and Time"
                    value={startDate}
                    variant="inline"
                    views={["year", "month", "day", "hours", "minutes"]}
                    minDateTime={
                      new Date(
                        new Date().setDate(new Date().getDate() + 1), // Increment the day by one
                        new Date().setHours(new Date().getHours() + 1) // Increment the hour by one
                      )
                    }
                    onChange={(newValue) => {
                      setStartDate(newValue);
                    }}
                    renderInput={(params) => <TextField {...params} />}
                  />
                </LocalizationProvider>

                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  {/* <DatePicker
        label="End  Date"
        value={endDate}
        minDate={new Date()}
        onChange={(newValue) => {
          if (newValue) { // newValue might be null, so check for truthy value
            setEndDate(newValue);
          }
          
        }}
        renderInput={(params) => <TextField {...params} />}
      /> */}

                  <DateTimePicker
                    label="End Date and time"
                    value={endDate}
                    variant="inline"
                    views={["year", "month", "day", "hours", "minutes"]}
                    minDateTime={
                      new Date(new Date().setDate(new Date().getDate() + 1))
                    }
                    onChange={(newValue) => {
                      setEndDate(newValue);
                    }}
                    renderInput={(params) => <TextField {...params} />}
                  />
                </LocalizationProvider>
              </Box>
            )}

            

            {/* DATE PICKER END */}
          </Box>

          <Box sx={{ mt: 1 }}>
            <Heading heading="Optimzation and delivery" />
            <Box>{vvv !== "" ? <Heading heading={vvv} /> : <Box>vvv</Box>}</Box>

            {optimizationError && (
              <p style={{ color: "red", fontSize: "12px" }}>Select Goal</p>
            )}

            {/* <Heading heading="Optimzation and delivery" />
             */}
          </Box>

          <Box>
            {campaignSlices.data[0].data.customObj.bid_control && (
              <Heading heading="Bid Type Strategy" />
            )}

            {campaignSlices.data[0].data.customObj.bid_control ? (
              <Box>
                <TextField
                  label="Bid"
                  error={inputValueBidOptional < 2}
                  value={inputValueBidOptional}
                  onChange={handleInputChangeBidOptional}
                  size="small"
                  inputProps={{
                    pattern: "[0-9]*",
                    inputMode: "numeric",
                    style: { textAlign: "right" },
                    startAdornment: <></>, // Empty element to position cursor on the left
                  }}
                />
              </Box>
            ) : (
              <Box>
                <Box sx={{ ml: 2 }}>
                  <FormControl>
                    <RadioGroup
                      column
                      size="small"
                      defaultValue={
                        campaignSlices.data[0].data.customObj.budget_optimize_on
                          ? "BID_TYPE_NO_BID"
                          : "BID_TYPE_CUSTOM"
                      }
                      aria-labelledby="demo-row-radio-buttons-group-label"
                      name="row-radio-buttons-group"
                      onChange={getBidStrategy}
                    >
                      {campaignSlices.data[0].data.customObj
                        .budget_optimize_on && (
                        <Box>
                          <FormControlLabel
                            value="BID_TYPE_NO_BID"
                            control={<Radio size="small" />}
                            label="Lowest Cost"
                          />

                          <p style={{ fontSize: "13px", color: "#ccc" }}>
                            Minimize Your Number Of Result
                          </p>

                          <FormControlLabel
                            value="BID_TYPE_CUSTOM"
                            control={<Radio size="small" />}
                            label="Bid Cap"
                          />
                          <p style={{ fontSize: "13px", color: "#ccc" }}>
                            Keep Your average cost per result lower than your
                            bid
                          </p>
                        </Box>
                      )}
                    </RadioGroup>
                  </FormControl>

                  {bidStrategy === "BID_TYPE_CUSTOM" && (
                    <Box sx={{ mt: 1 }}>
                      <TextField
                        label="Bid"
                        error={inputValueBid > 30 && inputValueBid < setBudget}
                        value={inputValueBid}
                        onChange={handleInputChangeBid}
                        size="small"
                        inputProps={{
                          pattern: "[0-9]*",
                          inputMode: "numeric",
                          style: { textAlign: "right" },
                          startAdornment: <></>, // Empty element to position cursor on the left
                        }}
                      />
                      <Typography>Bid for click cannot exceed 30</Typography>
                    </Box>
                  )}
                </Box>

                <Box>
                  {!campaignSlices.data[0].data.customObj
                    .budget_optimize_on && (
                    <Box>
                      <Heading heading="Bid Type Strategy" />
                      <TextField
                        label="Bid"
                        
                        value={inputValueBid}
                        onChange={handleInputChangeBid}
                        size="small"
                        inputProps={{
                          pattern: "[0-9]*",
                          inputMode: "numeric",
                          style: { textAlign: "right" },
                          startAdornment: <></>, // Empty element to position cursor on the left
                        }}
                      />
                     
                    </Box>
                  )}
                </Box>
              </Box>
            )}
          </Box>

          {campaignSlices.data[0].data.customObj.objective_type === "REACH" && (
            <Box>
              <Box sx={{ mt: 2 }}>
                <Heading heading="Frequency Cap" />
                <FormControl sx={{ mb: 1 }}>
                  <RadioGroup
                    small
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="threeSeven"
                    name="radio-buttons-group"
                    value={capValue}
                    onChange={handleChangeCap}
                  >
                    <FormControlLabel
                      value="threeSeven"
                      control={<Radio />}
                      label={
                        <Typography
                          style={{
                            color: "red",
                          }}
                          variant="Heading"
                          className="text"
                        >
                          Show Ads no more than 3 Times very 7 Days
                        </Typography>
                      }
                    />

                    <FormControlLabel
                     
                      value="noOnceDay"
                      control={<Radio />}
                      label={
                        <Typography
                          style={{
                            color: "red",
                          }}
                          variant="Heading"
                          className="text"
                        >
                          Show ad no more than once a day
                        </Typography>
                      }
                    />
                  </RadioGroup>
                </FormControl>
              </Box>
            </Box>
          )}

         

          <Button className="btn" type="submit" sx={{ my: 2 }}>
            Next
          </Button>


          {
            errorSubmit &&  <Alert severity="error">Budget is required and should be greater than or equal to 20, 
            and bid price should be less than 30.</Alert>
          }

          {
            budgetError &&  <Alert severity="error">Budget is required and should be greater than or equal to 20.</Alert>
          }
         
{
  bidPriceError &&  <Alert severity="error"> Bid price is required and should be less than 30.</Alert>
}


          
          {adSetGroup.loader && <FullScreenLoader />}

          {adSetGroup.data.length
            ? showAlert({ type: "success", message: "Created successfully" })
            : null}

          {adSetGroup.error.length
            ? showAlert({
                type: "error",
                message: adSetGroup.error[0].data.message,
              })
            : null}
        </form>
      </AdSetsStyled>
    </>
  );
};

export default AdSets;

const AdSetsStyled = styled.section`
  max-width: 27rem;
`;
