import React, { useState, useEffect } from "react";
import styled from "styled-components";
import Heading from "../../common/Heading";
import {
  Box,
  Typography,
  Button,
  FormLabel,
  FormHelperText,
  FormControl,
  RadioGroup,
  Radio,
  FormControlLabel,
  Grid,
  TextField,
  Link,
  Select,
  MenuItem,
  InputLabel,
  LinearProgress,
} from "@mui/material";

import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';


import RadioButon from "../../common/RadioButon";
import { useFormik } from "formik";
import * as yup from "yup";
import ValidationTextField from "../../common/ValidationTextField";
import SelectMenu from "../../common/SelectMenu";
import SwitchButton from "../../common/SwitchButton";
import { Info, Launch, AttachMoney, Add } from "@mui/icons-material";
import CustomAutoComplete from "../../common/AutoComplete";
import NewCreative from "pages/Creative Center/NewCreative";
import { INSTANCE } from "../../../config/axiosInstance";
import SweetAlert from 'react-bootstrap-sweetalert';

import { getVideoApi } from "slices/videoSlice";

import { getCurrentSplitStatus } from "slices/splitTest.splice";
import FileUploadIcon from "@mui/icons-material/FileUpload";

import { useDispatch, useSelector } from "react-redux";
import FullScreenLoader from "../../../components/common/FullScreenLoader";

import { getCurrentTab } from "slices/currentTabSlices"
;
const adObj = {
  advertiser_id: "7067431159843569665",
  adgroup_id: "1766235184897057",
  creatives: [
    {
      call_to_action_id: 7095893329245670402,
      ad_name: "",
      ad_text: "some txt",
      ad_format: "SINGLE_VIDEO",
      identity_id: "7067431159843569665",
      identity_type: "CUSTOMIZED_USER",
    },
  ],
};

const creativesObj = {
  advertiser_id: "7067431159843569665",
  adgroup_id: "",
  creatives: [
    {
      ad_name: "latest",
      ad_text: "sddd txt",
      ad_format: "SINGLE_VIDEO",
      app_name: "TikTok",
      call_to_action: "DOWNLOAD_NOW",
      video_id: "",
      image_ids: [],
      landing_page_url: "https://apps.apple.com/us/app/id1500855883",
      display_name: "TikTok Landing Page",
      identity_id: "7190670787934388226",
      identity_type: "CUSTOMIZED_USER",
    },
  ],
};

const Ads = () => {
  const dispatch = useDispatch();

  const { adSetGroup, videoSlice,splitTestSplice } = useSelector((res) => res);

  const [selectedFile, setSelectedFile] = useState({});

  const [key, setKey] = useState(Math.random());

  const [actions, setActions] = useState();

  const [videoLoader, setVideoLoader] = useState(false);

  const [videoId, setVideoId] = useState("");
  const [videoThumbnail, setVideoThumbnail] = useState("");

  const [loader, setLoader] = useState(false);

  const [showNameAndSize, setShowNameAndSize] = useState(false);

  const[showSweetAlert,setShowSweetAlert] = useState(false)

  const handleFileChange = (event) => {
    console.log(event.target.files[0].size);

    if (
      event.target.files[0].type === "video/mp4" &&
      event.target.files[0].size < 5242880
    ) {
      const file = event.target.files[0];
      setSelectedFile(file);
      setKey(Math.random());

      setShowNameAndSize(true);
    } else {
      alert("The file Not a video or large video");
    }
  };

  let filenameWithoutExtension;
  let finalSize;

  if (selectedFile.name) {
    let filename = selectedFile.name;
    let sizeSplit = filename.split(".").slice(0, -1).join(".");
    filenameWithoutExtension = sizeSplit.substring(0, 29);

    const sizeInKB = selectedFile.size;
    const sizeInMB = sizeInKB / 1024 / 1024;
    finalSize = parseFloat(sizeInMB.toFixed(2));
  }

  const uploadVideo = async () => {
    if (
      selectedFile.name != null &&
      selectedFile.name != {} &&
      selectedFile.name != ""
    ) {
      const formData = new FormData();
      formData.append("creative_file", selectedFile);

      const config = {
        headers: {
          "Content-Type": "multipart/form-data",
        },
        onUploadProgress: function (progressEvent) {
          var percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
        },
      };

      try {
        setVideoLoader(true);
        const res = await INSTANCE.post(
          "/creative/upload-video",
          formData,
          config
        );

        setVideoId(res.data.videoId);
        setVideoThumbnail(res.data.videoThumbnail);
        setVideoLoader(false);
      } catch (error) {
        console.log(error);
      }
    } else {
      alert("Please Select File");
    }
  };


  const showAlert = () => {
    return (
      <SweetAlert
        success
        title="Success!"
      >
        Ads Create Successfully
      </SweetAlert>
    );
  };


  const validationSchema = yup.object({
    adset_name: yup.string().required("Required"),
    app_name: yup.string().required("Required"),
    ad_text: yup.string().required("Required"),
    ad_name: yup.string().required("Required"),
  });

  const formik = useFormik({
    initialValues: {
      adset_name: "",
      ad_text: "",
      ad_name: "",
      app_name: ""
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      console.log(values);

      creativesObj.adgroup_id = adSetGroup.data[0].data.adgroup_id;
      creativesObj.creatives[0].video_id = videoId;
      creativesObj.creatives[0].image_ids.push(videoThumbnail);

  
      if(videoId != ""){

        try{
          setLoader(true);
          const res = await INSTANCE.post("/campaign/tiktok/ad/create",  creativesObj);
          setLoader(false);
          setShowSweetAlert(true)
         
         if(splitTestSplice.split){
             setTimeout(()=>{
              setShowSweetAlert(false)
              dispatch(getCurrentTab(4))
             },2000)
         }
         else{
          setTimeout(()=>{
            setShowSweetAlert(false)
            window.location.reload();
           },2000);

          
         }
         
        
        }
        catch(error){
            console.log(error)
        }
      }
      else{
        alert("Please Select Video First")
      }


    },
  });

  const handleConfirmAlert = () => {
    setShowSweetAlert(false);
  };


  const handleChangeActions = (e) => {
    console.log(e.target.value);
  };

  const dataActions = [
    {
      name: "Apply Now",
      value: "APPLY_NOW",
    },
    {
      name: "Book Now",
      value: "BOOK_NOW",
    },
    {
      name: "Contacts Us",
      value: "CONTACT_US",
    },
  ];

  return (
    <AdsStyled>
                  



      {videoId === "" && (
        <Box>

        
        <showAlert />

          <Heading heading="Creatives" />

          <Box>
            <Box sx={{boxShadow:"0 4px 6px rgba(0, 0, 0, 0.1)",p:3}}>
              <Grid container spacing={5} >
                <Grid item xs={12} md={12} sx={{ display: "flex", }}>
                  <Box sx={{ width: "100%" }}>
                  {/* <Heading heading="Video " /> */}

                    <div
                      style={{
                        position: "relative",
                        width: "100%",
                        height: "50px",
                        border: "2px solid #ccc",

                      }}
                    >
                      {videoLoader && <LinearProgress />}

                      <input
                        style={{
                          position: "absolute",
                          top: 0,
                          left: 0,
                          width: "100%",
                          height: "100%",
                          opacity: 0,
                        }}
                        type="file"
                        accept="video/mp4"
                        onChange={handleFileChange}
                      />

                      <div
                        style={{
                          height: "100%",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          backgroundColor: "lightgrey",
                        }}
                      >
                        <FileUploadIcon />
                        Upload Video File
                      </div>
                    </div>
                    {showNameAndSize && (
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          border: "2px dotted #ccc",
                        }}
                      >
                        <div>
                          <p>{filenameWithoutExtension}...</p>
                        </div>
                        <div>
                          <p>{finalSize} MB</p>
                        </div>
                      </div>
                    )}

                    <Button
                      sx={{ mt: 2 }}
                      disabled={videoLoader}
                      variant="contained"
                      onClick={uploadVideo}
                    >
                      Upload
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Box>
      )}

      {videoId != "" && (
        <form onSubmit={formik.handleSubmit}>
          <Box>
          {
            showSweetAlert && <Box>
            <SweetAlert
                success
                showConfirm={false}
                title="Success!"
              >
               
                <div>Ads Create Successfully</div>
                <Button sx={{mt:3}} variant='contained' color="success" onClick={handleConfirmAlert}>OK</Button>
              </SweetAlert>
            </Box>
          }

          

           <Grid container>
              <Grid item xs={12} md={12}>
                <Box sx={{ width: "100%" }}>
                  <Heading heading="Ad Name" />

                  <ValidationTextField
                    formik={formik}
                    name="ad_name"
                    placeholder="Please Enter Ad name"
                  />
                </Box>
              </Grid>

              <Grid item xs={12} md={12}>
                <Box
                  sx={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    flexWrap: "wrap",
                  }}
                >
                  <Box sx={{ width: "100%" }}>
                    <Heading heading="Ad Text" />

                    <ValidationTextField
                      formik={formik}
                      name="ad_text"
                      placeholder="Please Text"
                    />
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>

          <Box>
            <Box>
              <Grid container>
                <Grid item xs={12} md={12}>
                  <Box sx={{ width: "100%" }}>
                    <Heading heading="App Name" />

                    <ValidationTextField
                      formik={formik}
                      name="app_name"
                      placeholder="Enter App "
                    />
                  </Box>
                </Grid>

                <Grid item xs={12} md={12}>
                  <Box
                    sx={{
                      width: "100%",
                      display: "flex",
                      alignItems: "center",
                      flexWrap: "wrap",
                    }}
                  >
                    <Box sx={{ width: "100%" }}>
                      <Heading heading="Call To Actions" />
                      <FormControl fullWidth>
                        <InputLabel id="demo-simple-select-label">
                          Action
                        </InputLabel>
                        <Select
                          labelId="demo-simple-select-label"
                          id="demo-simple-select"
                          value={actions}
                          label="Actions"
                          onChange={handleChangeActions}
                        >
                          <MenuItem value="BOOK_NOW">Book Now</MenuItem>
                          <MenuItem value="APPLY_NOW">Apply Now</MenuItem>
                          <MenuItem value="CONTACT_US">Contact Us</MenuItem>
                        </Select>
                      </FormControl>
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Box>

          <Box sx={{ mt: 2 }}>
            <Heading heading="Ad set name" />
            <ValidationTextField
              formik={formik}
              name="adset_name"
              placeholder="Please Enter Ad set name"
            />
          </Box>

          {/* <Box>

<input type="file" accept="video/*" onChange={handleFileChange} />
<video width="420" height="340" controls key={key}>
{
(selectedFile != null) &&  <source src={URL.createObjectURL(selectedFile)} type="video/ogg"></source>
}
</video>


</Box> */}

          {/* <Box>
  <Heading heading="Identity" />
  <Box>
    <Heading heading="Facebook" />
    <CustomAutoComplete placeholder="Select Facebook Account" />
  </Box>
  <Box>
    <Heading heading="Instagram" />
    <CustomAutoComplete placeholder="Select Instagram Account" />
  </Box>
</Box> */}

          <Button sx={{ mt: 3 }} className="btn" type="submit">
            Create Ad
          </Button>
        </form>

       
      )}
       {
         loader && <FullScreenLoader />
        }
    </AdsStyled>
  );
};

export default Ads;
const AdsStyled = styled.section`
  max-width: 27rem;
`;
