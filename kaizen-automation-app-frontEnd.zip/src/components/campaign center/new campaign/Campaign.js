import React, { useState } from "react";
import styled from "styled-components";
import Heading from "../../common/Heading";

import { makeStyles } from '@mui/styles';

import {
  Box,
  Typography,
  Button,
  FormLabel,
  FormHelperText,
  FormControl,
  RadioGroup,
  Radio,
  FormControlLabel,
  Grid,
  TextField,
  Link,
  Stepper,
  Step,
  StepLabel,
  Checkbox,
  InputLabel,
  MenuItem,
  ListItemText,
  OutlinedInput,
  Switch

} from "@mui/material";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import EmojiObjectsIcon from '@mui/icons-material/EmojiObjects';


import Select, { SelectChangeEvent } from '@mui/material/Select';

import CampaignIcon from '@mui/icons-material/Campaign';

import RadioButon from "../../common/RadioButon";
import { useFormik } from "formik";
import * as yup from "yup";
import ValidationTextField from "../../common/ValidationTextField";
import SelectMenu from "../../common/SelectMenu";
import SwitchButton from "../../common/SwitchButton";
import { Info, Launch, AttachMoney } from "@mui/icons-material";
import { useDispatch,useSelector } from "react-redux";
import { getCurrentTab } from "slices/currentTabSlices";
import fbCurrentTabSlices, { fbGetCurrentTab } from "slices/fbCurrentTabSlices";

const awareness = [
  {
    value: "Brand Awareness",
    label: "Brand Awareness",
  },
  {
    value: "Reach",
    label: "RF_REACH",
  },
];
const consideration = [
  {
    value: "Traffic",
    label: "RF_TRAFFIC",
  },
  {
    value: "Engagement",
    label: "ENGAGEMENT",
  },
  {
    value: "App installs",
    label: "APP_INSTALL",
  },
  {
    value: "Video Views",
    label: "RF_VIDEO_VIEW",
  },
  {
    value: "Lead Generation",
    label: "LEAD_GENERATION",
  },
];

const conversions = [
  {
    value: "conversions",
    label: "Conversions",
  },
];

const campaignBudget = [
  {
    value: "daily",
    name: "Daily",
  },
  {
    value: "monthly",
    name: "Monthly",
  },
];


//Stepper Data
const steps = [
  'Campaign',
  'Ad sets',
  'Ads',
  //'Split Test'
];

const label = { inputProps: { 'aria-label': 'Size switch demo' } };

const useStyles = makeStyles({
  selected: {
    backgroundColor: "#3f51b5",
    color: "#fff",
    '&:hover': {
      backgroundColor: "#303f9f",
    },
  },
});



const names = [  
  { name: 'Credit', value: 'CREDIT' },  
  { name: 'Employment', value: 'EMPLOYMENT' }, 
   { name: 'Housing', value: 'HOUSING' },  
   { name: 'Social issues electronic or politics', value: 'SOCIAL ISSUES ELECTRONIC OR POLITICS' }
]

const Campaign = () => {

  const dispatch = useDispatch();
  const response = useSelector(res=>res)


  const [selectedButton, setSelectedButton] = useState("Awareness");
  const [hoverItem, setHoverItem] = useState( {

    name : "Awareness",
    detail : "Show your ads to people who are most likely to remember them",
    goodFor : ["Reach","Brand-awareness","Video view","Store-location-awareness"],
    imageUrl : "https://lh3.googleusercontent.com/gRGWeE8Duv3A2Ybz9acFkD7Ba56ZZ7xEFG35KRiuYBtnCp_J56isUObMnDUorLcAZ5iMfziHs4dC-plGnLQDm0Te7rrlzTDnxXRJclQm"
  });

  const [categoryName, setCategoryName] = useState([]);
  const [showOptions, setShowOptions] = useState(true);

  const [limitCheckbox, setLimitCheckbox] = useState(false);

  const [checked, setChecked] = useState(false);

  const [checkedOptimization, setCheckedOptimization] = useState(false);

  const handleSwitchChangeOptimization = (event) => {
    setCheckedOptimization(event.target.checked);
  };

  const handleSwitchChange = (event) => {
    setChecked(event.target.checked);
  };


  const handleChangeLimitCheckBox = (event) => {
    setLimitCheckbox(event.target.checked);
  };

  const handleToggleOptions = () => {
    setShowOptions(!showOptions);
    if(!showOptions){
      setLimitCheckbox(false); 
    }
  };


  const handleChangeCategory = (event) => {
    const {
      target: { value },
    } = event;
    setCategoryName(
      // On autofill we get a stringified value.
      typeof value === 'string' ? value.split(',') : value,
    );
  };


  const classes = useStyles();

  const handleClick = (item) => {
    setSelectedButton(item.name);
    setHoverItem(item);
  }

  const arr = [
    {

      name : "Awareness",
      detail : "Show your ads to people who are most likely to remember them",
      goodFor : ["Reach","Brand-awareness","Video view","Store-location-awareness"],
      imageUrl : "https://lh3.googleusercontent.com/gRGWeE8Duv3A2Ybz9acFkD7Ba56ZZ7xEFG35KRiuYBtnCp_J56isUObMnDUorLcAZ5iMfziHs4dC-plGnLQDm0Te7rrlzTDnxXRJclQm"
    },
    {
      name : "Traffic",
    
      detail : "Send people to a destination, like your website, app or Facebook event",
      goodFor : ["Link-clicks","Landing-page-views","Messenger-and-WhatsApp","Calls"],
      imageUrl : "https://lh3.googleusercontent.com/gRGWeE8Duv3A2Ybz9acFkD7Ba56ZZ7xEFG35KRiuYBtnCp_J56isUObMnDUorLcAZ5iMfziHs4dC-plGnLQDm0Te7rrlzTDnxXRJclQm"
    },
    {
      name : "Engagement",
    
      detail : "Get more messages, video views, post engagement, Page likes or event responses.",
      goodFor : ["Messenger, Instagram and WhatsApp","Video views",
      "Post engagement","Conversions"],
      imageUrl : "https://lh3.googleusercontent.com/gRGWeE8Duv3A2Ybz9acFkD7Ba56ZZ7xEFG35KRiuYBtnCp_J56isUObMnDUorLcAZ5iMfziHs4dC-plGnLQDm0Te7rrlzTDnxXRJclQm"
    },
    {
      name : "Leads",
      detail : "Collect leads for your business or brand.",
      goodFor : ["Instant forms","Messenger and Instagram","Conversions","Calls"],
      imageUrl : "https://lh3.googleusercontent.com/gRGWeE8Duv3A2Ybz9acFkD7Ba56ZZ7xEFG35KRiuYBtnCp_J56isUObMnDUorLcAZ5iMfziHs4dC-plGnLQDm0Te7rrlzTDnxXRJclQm"
    },
    {
      name : "App Promotion",
      detail : "Find new people to install your app and continue using it",
      goodFor : ["App installs","App events"],
      imageUrl : "https://lh3.googleusercontent.com/gRGWeE8Duv3A2Ybz9acFkD7Ba56ZZ7xEFG35KRiuYBtnCp_J56isUObMnDUorLcAZ5iMfziHs4dC-plGnLQDm0Te7rrlzTDnxXRJclQm"
    },
    {
      name : "Sales",
      detail : "Find people likely to purchase your product or service.",
      goodFor : ["Conversions","Catalog sales",
      "Messenger, Instagram and WhatsApp","Calls"],
      imageUrl : "https://lh3.googleusercontent.com/gRGWeE8Duv3A2Ybz9acFkD7Ba56ZZ7xEFG35KRiuYBtnCp_J56isUObMnDUorLcAZ5iMfziHs4dC-plGnLQDm0Te7rrlzTDnxXRJclQm"
    }
  ];


  const handleMouseEnter = (item) => {
    setHoverItem(item);
  };
  
  const handleMouseLeave = () => {
    const selectedItem = arr.find((item) => item.name === selectedButton);
    setHoverItem(selectedItem);
  };

  

  const validationSchema = yup.object({
    campaign_name: yup.string().required("Required"),
    campaign_objective: yup
      .string()
      //   .oneOf(["male", "female"], "Required")
      .required("Required"),
    budget: yup.number().positive().required("Required").min(1),
  });

  const formik = useFormik({
    initialValues: {
      campaign_name: "",
      campaign_objective: "",
      budget: "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      console.log(values);
      dispatch(getCurrentTab(2))
    },
  });

  const [value, setValue] = useState("");
  const handleRadioChange = (event) => {
    setValue(event.target.value);
    // setHelperText(" ");
    // setError(false);
  };


  let activeStep = 0;
  let headingName = "Compaign";

  //Condition Rendering to Handle Current Tab

  if(fbCurrentTabSlices.currentTab === 2){
    headingName = "Ad sets";
    activeStep = 1
  }
  if(fbCurrentTabSlices.currentTab === 3){
    headingName = "Ads";
    activeStep = 2
    
  }

  if(fbCurrentTabSlices.currentTab === 4){
    headingName = "Split Test";
    activeStep = 3
    
  }
  
  return (
    <>
      <CampaignStyled>


      {/* <Box sx={{
              width: {
               // md :splitTestSplice.split ? '70%' : '50%',
                sm : "100%"
              },
              my: 2
              
            }}
          >
    <Stepper nonLinear activeStep={activeStep}>
        {steps.map((label, index) => (
          <Step key={label}>
            <StepLabel color="inherit">
               <Typography sx={{fontSize:"15px"}}>{label}</Typography>
            </StepLabel>
          </Step>
        ))}
      </Stepper>
    </Box> */}


        <Box>
          <Heading heading="Ad Accout" />
          <Box
            className="primary_color"
            sx={{ py: 1, px: 2, borderRadius: "5px", width: "fit-content" }}
          >
            <Typography variant="body">hwozT9rS85fldCu</Typography>
          </Box>
          <Box>
            <form onSubmit={formik.handleSubmit}>
              <Heading heading="Campaign Name" />
              <ValidationTextField
                formik={formik}
                placeholder="Enter Camapign Name"
                name="campaign_name"
              />
              <Box>
                <Heading heading="Choose a campaign objective" />
                {/* <Box>
                  <Grid container spacing={3}>
                    <Grid item md={4}>
                      <Typography
                        variant="caption"
                        component="div"
                        sx={{ fontWeight: "bold", color: "var(--main-color)" }}
                      >
                        Awareness
                      </Typography>
                      <RadioButon
                        formik={formik}
                        name="campaign_objective"
                        data={awareness}
                      />
                    </Grid>
                    <Grid item md={4}>
                      <Typography
                        variant="caption"
                        component="div"
                        sx={{ fontWeight: "bold", color: "var(--main-color)" }}
                      >
                        Consideration
                      </Typography>
                      <RadioButon
                        formik={formik}
                        name="campaign_objective"
                        data={consideration}
                      />
                    </Grid>
                    <Grid item md={4}>
                      <Typography
                        variant="caption"
                        component="div"
                        sx={{ fontWeight: "bold", color: "var(--main-color)" }}
                      >
                        Conversions
                      </Typography>
                      <RadioButon
                        formik={formik}
                        name="campaign_objective"
                        data={conversions}
                      />
                    </Grid>
                  </Grid>
                  <FormHelperText sx={{ color: "var(--error-color)" }}>
                    {formik.touched.campaign_objective &&
                      formik.errors.campaign_objective}
                  </FormHelperText>
                </Box> */}
                <Box>
   
        

                <Grid container spacing={2}>
      {/* Rows */}
      <Grid item xs={12}>
        {/* Columns */}
        <Grid container spacing={4}>
          <Grid item xs={6}>
            <div style={{ display: "flex", flexDirection: "column", gap: "10px", }}>

            {arr.map((item, index) => (
                <div key={index}>
     
                  <Button
                    className={selectedButton === item.name ? classes.selected : ""}
                    onClick={() => handleClick(item)}
                    onMouseEnter={() => handleMouseEnter(item)}
                     onMouseLeave={handleMouseLeave}
                  >
                    {item.name}
                  </Button>
                </div>
              ))}
     
   

            </div>
          </Grid>
          <Grid item xs={6}>
          <Box mt={2}>
      
        {hoverItem && (
        <Box className={classes.detailsContainer}>
         {/* <div className={classes.column}>
           <img src={hoverItem.imageUrl} />
          </div> */}
          <div className={classes.column}>
            {/* <Typography variant="h6">Name</Typography> */}
            <Typography sx={{
                        fontSize: "15px",
                       fontWeight : 'bold', // Apply margin bottom to create space between items
      // Add padding for better readability
                      }}>{hoverItem.name} : </Typography>
          </div>
          <div className={classes.column}>
            {/* <Typography variant="h6">Detail</Typography> */}
            <Typography  variant="body"
                  className="text"
                  sx={{
                    fontSize: "12px",
                    svg: {
                      width: "1rem",
                    },
                  }}>{hoverItem.detail}</Typography>
          </div>
          <div className={classes.column}>
            <Typography sx={{
                        fontSize: "15px",
                       fontWeight : 'bold',
                       
      marginBottom: "7px", // Apply margin bottom to create space between items
 // Add padding for better readability
                      }}>Good For : </Typography>
            {hoverItem.goodFor.map((good, index) => (
              <Typography key={index}  variant="body"
                  className="text"
                  sx={{
                        fontSize: "12px",
                        display: "block",
                        backgroundColor: "white",
                        width: "fit-content",
      marginBottom: "7px", // Apply margin bottom to create space between items
      padding: "5px", // Add padding for better readability
                      }}>
                  {good}
                  </Typography>
            ))}
          </div>
        </Box>
      )}
     
      </Box>
          </Grid>
        </Grid>
      </Grid>
      {/* Repeat the above pattern for 5 more rows */}
    </Grid>

   
   
                </Box>
              </Box>



              {/* specail ad category   */}
              <Box
      sx={{
        py: 2,
        p:3,
        boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.25)", // Apply box shadow styling
        borderRadius: "8px", // Optional: Add border radius for rounded corners
      }}
    >
      
      
        
      <Heading heading="Special Ad Categories" />
      <Typography
        variant="body"
        className="text"
        sx={{
          fontSize: "14px",
        }}
      >
        Declare if your ads are related to credit, employment or housing, or about social issues, elections or politics. Requirements differ by country.
      </Typography>

   <Box sx={{mt:2}}>
   <Typography
        variant="h5"
        className="text"
        sx={{
          fontSize: "15px",
          fontWeight: "bold",
          mb:1
        }}
      >
       Categories
      </Typography>


      <Box>
      <FormControl sx={{ width: "100%" }}>
        <Select
          multiple
          value={categoryName}
          onChange={handleChangeCategory}
          displayEmpty 
          renderValue={(selected) => {
            if (selected.length === 0) {
              return (
                <em
                  sx={{
                    fontSize: "9px",
                    color: "rgba(0, 0, 0, 0.54)",
                  fontStyle: "italic" 
                  }}
                >
                  No Categories Declared
                </em>
              );
            }
            return selected.join(", ");
          }}
          sx={{
            "& .MuiSelect-outlined": {
              paddingTop: "8px",
              paddingBottom: "8px"
            }
          }}
      
        >
          {names.map((name) => (
              <MenuItem key={name.value} value={name.value}>
                <Checkbox checked={categoryName.indexOf(name.value) > -1} />
                <ListItemText primary={name.name} />
              </MenuItem>
            ))}

        </Select>
      </FormControl>
    </Box>
   </Box>

{/* COUNTRIES AND REGION */}
{
  categoryName.length > 0 && 
  <Box>
  <Box sx={{mt:2}}>
    <Typography
        variant="h5"
        className="text"
        sx={{
          fontSize: "15px",
          fontWeight: "bold",
          
        }}
      >
       Countries
      </Typography>
    <Typography
        variant="body"
        className="text"
        sx={{
          fontSize: "12px",
        }}
      >
        Select where you want to run this campaign. If there are additional requirements to run your ads in those locations, your advertising options will be adjusted.
      </Typography>

     

    </Box>

{/* REGION */}
    <Box sx={{mt:2}}>
    <Typography
        variant="h5"
        className="text"
        sx={{
          fontSize: "15px",
          fontWeight: "bold",
          
        }}
      >
       Region
      </Typography>
    

    
    </Box>
{/* REGION */}

  </Box>
}


{/* COUNTRIES AND REGION */}

              </Box>

           {/* specail ad category   */}


           {/* Campaign details */}

           <Box
      sx={{
        mt:3,
        py: 1,
        p:2,
        boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.25)", // Apply box shadow styling
        borderRadius: "8px", // Optional: Add border radius for rounded corners
      }}
    >
      
      <Heading heading="Campaign details" />

      <Box>
      <Typography
        variant="h5"
        className="text"
        sx={{
          fontSize: "15px",
          fontWeight: "bold",
          mb:1
        }}
      >
       Buying type
      </Typography>
      </Box>


      <Box>
      <Typography
        variant="h5"
        className="text"
        sx={{
          fontSize: "15px",
          fontWeight: "bold",
          mb:1
        }}
      >
       Campaign objective
      </Typography>
      </Box>

      

      
      <Box onClick={handleToggleOptions}>
      <Typography
        variant="h5"
        className="text"
        sx={{
          fontSize: "15px",
          fontWeight: "bold",
          mb: 1,
          color: "#0000FF",
          cursor: "pointer",
        
          "&:hover": {
            textDecoration: "underline"
          }
        }}
      >
        {showOptions ? "Show more options" : "Hide options"}
      </Typography>
    </Box>

    {
      !showOptions && <Box>
      <Typography
        variant="h5"
        className="text"
        sx={{
          fontSize: "15px",
          fontWeight: "bold",
          mb:1
        }}
      >


<Checkbox
  checked={limitCheckbox}
 onChange={handleChangeLimitCheckBox}
  size="small"
  sx={{
    padding: 0,
    margin: 0,
    mr:1
  }}
  inputProps={{ 'aria-label': 'controlled' }}
/>


       Campaign spending limit
      </Typography>
      </Box>

    }


  {
    limitCheckbox &&   <Box>
      <TextField  variant="outlined" />

    </Box>
  }



      
  </Box>


           {/* Campaign details */}


           {/* AB TEST */}

           <Box
      sx={{
        mt:3,
        py: 1,
        p:2,
        boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.25)", // Apply box shadow styling
        borderRadius: "8px", // Optional: Add border radius for rounded corners
      }}
    >
      
      <Box sx={{ 
        display: "flex",
    justifyContent: "space-between",
    alignItems: "center" 
    }}
    >
  <Box>
    <Typography
      variant="h5"
      className="text"
      sx={{
        fontSize: "15px",
        fontWeight: "bold",
        mb: 1,
        display : "flex",
        alignItems : "center"
      }}
    >
   {
    checked &&  <CheckCircleIcon   sx={{
        color: '#66BB6A', // Light green color
        fontSize: '18px', // Adjust the size to small
       // Add padding
        marginRight: '5px', // Add margin right for spacing
      }}/>
   }
     <Heading heading="A/B Test" />
    </Typography>
  </Box>
  <Box>
    <Typography
      variant="h5"
      className="text"
      sx={{
        fontSize: "15px",
        mb: 1
      }}
    >
      Create A/B Test
      <Switch {...label} 
      defaultChecked 
      checked={checked}
      onChange={handleSwitchChange}
       />
    </Typography>
  </Box>
     </Box>


     <Typography
        variant="body"
        className="text"
        sx={{
          fontSize: "12px",
        }}
      >
        To help improve ad performance, test versions with different images, text, audiences or placements. For accuracy, each one will be shown to separate groups of your audience.
      </Typography>

      {
     checked &&   <Box sx={{background:"white",py:1,px:1,mt:2}}>
      <Typography
        variant="body"
        className="text"
        sx={{
          fontSize: "12px",
          display:"flex"
        }}
      >
      
      <EmojiObjectsIcon />
       After you publish this campaign, we’ll take you to the A/B test setup where you can finish creating your test.
      </Typography>

     </Box>
   }

   
     

    

      

      
  </Box>

           {/* AB TEST */}



              {/* Advantage campaign budget   */}

              
           <Box
      sx={{
        mt:3,
        py: 1,
        p:2,
        boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.25)", // Apply box shadow styling
        borderRadius: "8px", // Optional: Add border radius for rounded corners
      }}
    >

    <Box sx={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>

    <Box sx={{display:"flex",alignItems:"center"}}>
    {
      checkedOptimization &&  <CheckCircleIcon   sx={{
        color: '#66BB6A', // Light green color
        fontSize: '18px', // Adjust the size to small
       // Add padding
        marginRight: '5px', // Add margin right for spacing
      }}/>
   }

      <Heading heading="Advantage campaign budget" />
    </Box>
    
  
       <Box>
      
      <Typography
        variant="body"
        className="text"
        sx={{
          fontSize: "12px",
        }}
      >
      {
        checkedOptimization ? "ON" : "OFF"
      }
      </Typography>

       <Switch {...label} 
      defaultChecked 
      checked={checkedOptimization}
      onChange={handleSwitchChangeOptimization}
       />
       </Box>
    </Box>
     


      <Typography
        variant="body"
        className="text"
        sx={{
          fontSize: "12px",
        }}
      >
       Advantage campaign budget will distribute your budget across currently delivering ad sets to get more results depending on your performance goal choices and bid strategy. You can control spending on each ad set.
      </Typography>

      <Box>
                <Heading heading="campaign budget" />
                <Box sx={{ display: "flex", width: "100%" }}>
                  <ValidationTextField
                    formik={formik}
                    name="budget"
                    placeholder="Enter Camapign Budget"
                    type="number"
                    start={<AttachMoney />}
                  />
                  <Box sx={{ width: "100%", maxWidth: "145px" }}>
                    <SelectMenu data={campaignBudget} placeholder="Daily" />
                  </Box>
                </Box>
                <Typography variant="caption" className="text">
                  Actual amount spent per day may vary
                </Typography>
              </Box>

              <Box>
                <Heading heading="Campaign bid strategy" />
                <SelectMenu
                  data={campaignBudget}
                  placeholder="Hightest value or lowest cost"
                />
              </Box>
    
  </Box>



              {/* <Box sx={{ py: 2 }}>
                <Box sx={{ display: "flex", alignItems: "center" }}>
                  <SwitchButton />
                  <Box sx={{ pl: 2, display: "flex", alignItems: "center" }}>
                    <Heading heading="Advantage campaign budget" />
                  </Box>
                </Box>
                <Typography
                  variant="body"
                  className="text"
                  sx={{
                    fontSize: "14px",
                    svg: {
                      width: "1rem",
                    },
                  }}
                >
                  Campaign budget optimization will distribute you budget across
                  ad sets to get more results depending on your optimization
                  choices and bid strategy. You can control spending on each ad
                  set.
                  <Link
                    underline="hover"
                    sx={{
                      color: "var(--main-color)",
                      ml: 1,
                      display: "inline-flex",
                      // alignItems: "center",
                      cursor: "pointer",
                    }}
                  >
                    Learn More <Launch sx={{ ml: 0.5 }} />
                  </Link>
                </Typography>
              </Box> */}
              {/* Campaign budget */}
            
             
              <Button className="btn" type="submit" sx={{ my: 2 }}>
                Submit
              </Button>

              {/* <TextField
                type="number"
                inputProps={{
                  endAdornment: <SelectMenu />,
                  // classes: {
                  //   adornedEnd: classes.adornedEnd,
                  // },
                }}
              /> */}
            </form>
          </Box>
        </Box>
        
      </CampaignStyled>
    </>
  );
};

export default Campaign;

const CampaignStyled = styled.section`
  max-width: 35rem;
`;
