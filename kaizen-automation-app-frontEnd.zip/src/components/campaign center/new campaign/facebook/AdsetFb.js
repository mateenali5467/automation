
import { useState,useEffect } from "react";
import { TextField } from '@mui/material';
import { FormControl, Select, MenuItem ,Radio, RadioGroup, FormControlLabel } from '@mui/material';


const AdsetFb = ()=>{

    const [inputValue, setInputValue] = useState('');
    const [selectedValue, setSelectedValue] = useState('');
    const [selectedValueR, setSelectedValueR] = useState('advantage');

    

    const handleInputChange = (event) => {
        setInputValue(event.target.value);
      };

      
      const handleSelectChange = (event) => {
        setSelectedValue(event.target.value);
      };
    
     

      const handleRadioChange = (event) => {
        setSelectedValueR(event.target.value);
      };


    return (
        <>
                <TextField
                    label="Input"
                    value={inputValue}
                    onChange={handleInputChange}
                    />


<FormControl>
      <Select
        value={selectedValue}
        onChange={handleSelectChange}
        displayEmpty
      >
        <MenuItem value="" disabled>
          Select an option
        </MenuItem>
        <MenuItem value="option1">Option 1</MenuItem>
        <MenuItem value="option2">Option 2</MenuItem>
        <MenuItem value="option3">Option 3</MenuItem>
      </Select>
    </FormControl>


<h1>
Dynamic creative
</h1>

<h1>Budget & schedule
</h1>

<h1>Audience
</h1>

<h1>Placements
</h1>


<FormControl component="fieldset">
      <RadioGroup value={selectedValue} onChange={handleRadioChange}>
        <FormControlLabel
          value="advantage"
          control={<Radio />}
          label="Advantage+ placements (recommended)"
        />
        <FormControlLabel
          value="manual"
          control={<Radio />}
          label="Manual placements"
        />
      </RadioGroup>
    </FormControl>

        </>
    )
}

export default AdsetFb;