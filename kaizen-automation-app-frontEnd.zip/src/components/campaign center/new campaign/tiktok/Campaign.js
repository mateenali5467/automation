import React, { useState, useEffect } from "react";
import styled from "styled-components";
import "animate.css";
import Heading from "components/common/Heading";
import swal from "sweetalert";

import {
  Box,
  Typography,
  Button,
  FormHelperText,
  Grid,
  Link,
  Switch,
  Alert,
  AlertTitle,
  TextField,
} from "@mui/material";

import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select, { SelectChangeEvent } from "@mui/material/Select";

import Radio, { RadioProps } from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";

import { LoadingButton } from "@mui/lab";
import SaveIcon from "@mui/icons-material/Save";

import RadioButon from "components/common/RadioButon";
import { useFormik } from "formik";
import * as yup from "yup";
import ValidationTextField from "components/common/ValidationTextField";
import SelectMenu from "components/common/SelectMenu";

import { TimePicker } from '@mui/x-date-pickers/TimePicker';

import FullScreenLoader from "../../../../components/common/FullScreenLoader";

import {
  Info,
  Launch,
  AttachMoney,
  Euro,
  Satellite,
} from "@mui/icons-material";

import { awareness, consideration, conversions, campaignBudget } from "./Data";
import { useDispatch, useSelector } from "react-redux";
import currentTabSlices, { getCurrentTab } from "slices/currentTabSlices";
import { Toast } from "../../../../components/common/Toast";
import { getCampaignAPi } from "slices/campaignSlices";
import { INSTANCE } from "../../../../config/axiosInstance";
import { baseURL } from "config/endpoint";

import TreeView from "@mui/lab/TreeView";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import TreeItem from "@mui/lab/TreeItem";

import { getCurrentSplitStatus } from "slices/splitTest.splice";

import ConnectAccount from "components/ConnectAccount/ConnectAccount";


const StyledRadio = styled(Radio)({
  "& .MuiSvgIcon-root": {
    display: "none",
  },
  "& .MuiIconButton-root": {
    border: "1px solid grey",
    borderRadius: "50%",
    padding: "5px",
    "&:hover": {
      backgroundColor: "transparent",
    },
  },
  "&.Mui-checked .MuiIconButton-root": {
    borderRight: "10px solid red",
  },
});

const Campaign = () => {
  
  const dispatch = useDispatch();

  const [selectedValue, setSelectedValue] = useState("");

  const { campaignSlices, splitTestSpliceP } = useSelector((res) => res);

  const [value, setValue] = useState("");

  const [split, setSplit] = useState(false);

  console.log("campaignSlices",campaignSlices)

  const [state, setState] = React.useState({
    budget: false,
    campaign: true,
  });
  const [campaignObject, setCampaignObject] = useState({});

  const [objectiveRender, setObjectiveRender] = useState("");

  const [appType, setAppType] = useState("APP_INSTALL");

  const [modeCampaign, setModeCampaign] = React.useState("BUDGET_MODE_DAY");

  const [textFieldErrorCampaign, setTextFeildErrorCampaign] = useState(false);

  const [CampaignBudget, setCampaignBudget] =
    React.useState("BUDGET_MODE_DAY");

  const [textFieldErrorBudget, setTextFeildErrorBudget] = useState(false);

  const [budget, setBudget] = useState(""); // Initialize the state

  const [campaign, setCampaign] = React.useState(""); // Initialize the state

  const handleChangeCampaign = (event) => {
    setCampaign(event.target.value); // Update the state when the input's value changes
  };

  const handleChangeBudget = (event) => {
    setBudget(event.target.value); // Update the state when the input's value changes
  };

  const handleChangeModeCampaign = (event) => {
    console.log(event.target.value)
    setModeCampaign(event.target.value);
  };

  const validationSchema = yup.object({
    campaign_name: yup.string().required("Required"),
  });

  const formik = useFormik({
    initialValues: {
      campaign_name: "",
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      
      if (selectedValue === "APP_PROMOTION") {
        campaignObject.app_promotion_type = appType;
      } else {
        delete campaignObject.app_promotion_type;
      }

      if (budget !== "") {
        campaignObject["budget"] = budget;
      } else {
        delete campaignObject["budget"];
      }

      if (campaign !== "") {
        campaignObject["budget"] = campaign;
      } else {
        delete campaignObject["budget"];
      }

      if (state.budget) {
        if (budget > 50) {
          campaignObject.budget = budget;
          campaignObject.budget_mode = modeCampaign;

          console.log(campaignObject);
         dispatch(getCampaignAPi(campaignObject));
        } else {
          console.log("Please fill in the budget");
        }
      } else {
        if (state.campaign) {
          if (campaign > 50) {
            console.log(campaignObject);
            campaignObject.budget = campaign;
            campaignObject.budget_mode = modeCampaign;
           dispatch(getCampaignAPi(campaignObject));
          } else {
            console.log("Please fill in the campaign");
          }
        } else {
          delete campaignObject.budget;
          delete campaignObject.budget_mode;
          console.log(campaignObject);
          dispatch(getCampaignAPi(campaignObject));
         
        }
      }

      //REDUX API CALLING
      // dispatch(getCampaignAPi(campaignObject));
    },
  });

  const handleChangeSplitTest = (e) => {
    setSplit(e.target.checked);
    dispatch(getCurrentSplitStatus(e.target.checked));
  };

  const handleRadioChange = (event) => {
    // setValue(event.target.value);
    // setHelperText(" ");
    // setError(false);
  };

  const checkCurrentValue = () => {
    if (state.budget) {
      campaignObject["budget_optimize_on"] = true;
    } else {
      campaignObject["budget_optimize_on"] = false;
    }

    campaignObject["campaign_name"] = formik.values.campaign_name;
    campaignObject["objective_type"] = selectedValue;
    campaignObject["campaign_type"] = "REGULAR_CAMPAIGN";

    if (split) {
      campaignObject["operation_status"] = "ENABLE";
    } else {
      campaignObject["operation_status"] = "DISABLE";
    }
  };

  const handleChange = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
    formik.values.value = "";
  };

  const getC = () => {
    // console.log("done")
  };

  useEffect(() => {
    sessionStorage.removeItem("compaignObjBudget");
    sessionStorage.removeItem("compaignObjCompaign");
  }, [state]);

  const showAlert = ({ type, message }) => {
    if (type === "success") {
      setTimeout(() => {
        dispatch(getCurrentTab(2));
      }, 100);
      return false;
    }

    return (
      <Alert variant="filled" severity={type}>
        <AlertTitle>{message}</AlertTitle>
      </Alert>
    );
  };

  const RadioButtonContainer = ({
    title,
    radioValue,
    setRadioValue,
    value,
    label,
  }) => {
    return (
      <>
        <Box
          height={60}
          border={
            radioValue === value
              ? "2px solid var(--main-color)"
              : "1px solid  grey"
          }
          p={1}
          m={1}
          borderRadius={1}
        >
          <FormControl component="fieldset" sx={{ width: "100%" }}>
            <RadioGroup
              value={radioValue}
              onChange={(e) => setRadioValue(e.target.value)}
            >
              <FormControlLabel
                value={value}
                control={<StyledRadio />}
                label={label}
              />
            </RadioGroup>
          </FormControl>
        </Box>
      </>
    );
  };



  return (
    <>
      <Heading heading="Campaign Objective" />
      <Grid container spacing={3}>
        <Grid item xs={12} sm={12} md={4}>
          <Heading heading="Awareness" variant="h6" />
          <RadioButtonContainer
            title="Reach"
            radioValue={selectedValue}
            setRadioValue={setSelectedValue}
            value="REACH"
            label="Reach"
          />
        </Grid>

        <Grid item xs={12} sm={12} md={4}>
          <Heading heading="Consideration" variant="h6" />
          <RadioButtonContainer
            title="Video Views"
            radioValue={selectedValue}
            setRadioValue={setSelectedValue}
            value="VIDEO_VIEWS"
            label="Video Views"
          />
          <RadioButtonContainer
            title="Traffic"
            radioValue={selectedValue}
            setRadioValue={setSelectedValue}
            value="TRAFFIC"
            label="Traffic"
          />
          <RadioButtonContainer
            title="Community Interactions"
            radioValue={selectedValue}
            setRadioValue={setSelectedValue}
            value="ENGAGEMENT"
            label="Community Interactions"
          />
        </Grid>

        <Grid item xs={12} sm={12} md={4}>
          <Heading heading="Conversion" variant="h6" />
          <RadioButtonContainer
            title="App Promotion"
            radioValue={selectedValue}
            setRadioValue={setSelectedValue}
            value="APP_PROMOTION"
            label="App Promotion"
          />
          <RadioButtonContainer
            title="Lead Generation"
            radioValue={selectedValue}
            setRadioValue={setSelectedValue}
            value="LEAD_GENERATION"
            label="Lead Generation"
          />
          <RadioButtonContainer
            title="Website Conversions"
            radioValue={selectedValue}
            setRadioValue={setSelectedValue}
            value="WEB_CONVERSIONS"
            label="Website Conversions"
          />
        </Grid>
      </Grid>

      <CampaignStyled>
        <Box>
   
          {selectedValue != "" && (
            <Box>
              <form onSubmit={formik.handleSubmit}>

                <Box>
                  <Heading heading="Campaign Name" />
                  <ValidationTextField
                    formik={formik}
                    placeholder="Enter Camapign Name"
                    name="campaign_name"
                  />
                </Box>

                {selectedValue === "APP_PROMOTION" ? (
                  <Box sx={{ py: 2 }}>
                    <Heading heading="App Promotion Type" />

                    <FormControl>
                      <RadioGroup
                        aria-labelledby="demo-radio-buttons-group-label"
                        defaultValue="APP_INSTALL"
                        name="radio-buttons-group"
                        onChange={(event) => {
                          console.log(event.target.value);
                          setAppType(event.target.value); // log the selected value
                        }}
                      >
                        <FormControlLabel
                          value="APP_INSTALL"
                          control={<Radio />}
                          label="App Install"
                        />
                        <FormControlLabel
                          value="APP_RETARGETING"
                          control={<Radio />}
                          label="App Retargeting"
                        />
                      </RadioGroup>
                    </FormControl>
                  </Box>
                ) : null}

                {/* Create split test    */}

                {selectedValue === "VIDEO_VIEWS" ? null : (
                  <Box sx={{ py: 2 }}>
                    <Box sx={{ display: "flex", alignItems: "center" }}>
                      <Switch
                        onChange={handleChangeSplitTest}
                        sx={{
                          width: "50px",
                          height: "24px",
                          padding: "0px",
                          "& .MuiSwitch-switchBase": {
                            color: "#818181",
                            padding: "1px",
                            "&.Mui-checked + .MuiSwitch-track": {
                              backgroundColor: "var(--main-color)",
                            },
                          },
                          "& .MuiSwitch-thumb": {
                            color: "white",
                            width: "20px",
                            height: "20px",
                            margin: "1px",
                          },
                          "& .MuiSwitch-track": {
                            borderRadius: "20px",
                            backgroundColor: "#818181",
                            opacity: "1 !important",
                            "&:after, &:before": {
                              color: "white",
                              fontSize: "11px",
                              position: "absolute",
                              top: "6px",
                            },
                            "&:after": {
                              content: "'On'",
                              left: "8px",
                            },
                            "&:before": {
                              content: "'Off'",
                              right: "7px",
                            },
                          },
                          "& .Mui-checked": {
                            color: "#23bf58 ",
                            transform: "translateX(26px) !important",
                          },
                        }}
                        checked={split}
                        inputProps={{ "aria-label": "secondary checkbox" }}
                      />
                      <Box
                        sx={{ pl: 2, display: "flex", alignItems: "center" }}
                      >
                        <Heading heading=" Create split test " />
                      </Box>
                    </Box>

                    <Typography
                      variant="caption"
                      className="text"
                      sx={{
                        svg: {
                          width: "1rem",
                        },
                      }}
                    >
                      Get more insights into your ads by split testing your
                      strategy.
                      <Link
                        underline="hover"
                        sx={{
                          color: "var(--main-color)",
                          ml: 1,
                          display: "inline-flex",
                          cursor: "pointer",
                        }}
                      >
                      
                      </Link>
                    </Typography>

{
      split &&   <Box sx={{ml:1}}>
                     
                     <Typography
                        variant="caption"
                        className="text"
                        sx={{
                       
                          svg: {
                            width: "1rem",
                            
                          },
                        }}
                      >
                      
                       We'll show your split test to 2 separate audiences to give you data-driven results.
  
                       <Box>
                          <Box>
                          1. Complete the ad group and ad settings for your control
                          </Box>
                          <Box>
                          2. Select a variable and create your test ad group
                          </Box>
                          <Box>
                          3. View results for insights into your strategy
                          </Box>
                          
                         
                       </Box>
                       
                      </Typography>
                     </Box>
}

                 
                  </Box>
                )}

                {/* campaign budget optimization   */}
                <Box sx={{ py: 2 }}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    {/* <SwitchButton name="budget" /> */}
                    <Switch
                      sx={{
                        width: "50px",
                        height: "24px",
                        padding: "0px",
                        "& .MuiSwitch-switchBase": {
                          color: "#818181",
                          padding: "1px",
                          "&.Mui-checked + .MuiSwitch-track": {
                            backgroundColor: "var(--main-color)",
                          },
                        },
                        "& .MuiSwitch-thumb": {
                          color: "white",
                          width: "20px",
                          height: "20px",
                          margin: "1px",
                        },
                        "& .MuiSwitch-track": {
                          borderRadius: "20px",
                          backgroundColor: "#818181",
                          opacity: "1 !important",
                          "&:after, &:before": {
                            color: "white",
                            fontSize: "11px",
                            position: "absolute",
                            top: "6px",
                          },
                          "&:after": {
                            content: "'On'",
                            left: "8px",
                          },
                          "&:before": {
                            content: "'Off'",
                            right: "7px",
                          },
                        },
                        "& .Mui-checked": {
                          color: "#23bf58 ",
                          transform: "translateX(26px) !important",
                        },
                      }}
                      checked={state.budget}
                      onChange={handleChange}
                      name="budget"
                      disabled={state.campaign}
                      inputProps={{ "aria-label": "secondary checkbox" }}
                    />
                    <Box sx={{ pl: 2, display: "flex", alignItems: "center" }}>
                      <Heading heading="Campaign budget optimization" />
                    </Box>
                  </Box>

                  <Typography
                    variant="body"
                    className="text"
                    sx={{
                      fontSize: "14px",
                      svg: {
                        width: "1rem",
                      },
                    }}
                  >
                    Automatically optimize your budget allocation. You'll have
                    some limitations on your bid strategy and optimization goal.
                    <Link
                      underline="hover"
                      sx={{
                        color: "var(--main-color)",
                        ml: 1,
                        display: "inline-flex",
                        // alignItems: "center",
                        cursor: "pointer",
                      }}
                    >
                      Learn More <Launch sx={{ ml: 0.5 }} />
                    </Link>
                  </Typography>

                  {state.budget && (
                    <Box sx={{ display: "flex", width: "100%", mt: 3 }}>
                      <Box sx={{ position: "relative" }}>
      
                        <TextField
                          error={budget < 50} // Show error if budget is less than 50
                          id="outlined-error"
                          label="Budget"
                          helperText="At Least 50"
                          value={budget} // Set the value of the input to the budget state
                          onChange={handleChangeBudget} // Call handleChange when the input's value
                        />

                        <Typography
                          sx={{
                            position: "absolute",
                            top: "14px",
                            right: "7px",
                          }}
                          variant="caption"
                          className="text"
                        >
                          EUR
                        </Typography>
                      </Box>

                      <Box sx={{ width: "100%", maxWidth: "145px", ml: 1 }}>
                       

                        <Select
                          labelId="demo-simple-select-label"
                          id="demo-simple-select"
                          value={modeCampaign}
                          onChange={handleChangeModeCampaign}
                        >
                          <MenuItem value="BUDGET_MODE_DAY">Daily</MenuItem>
                          <MenuItem value="BUDGET_MODE_TOTAL">
                            Life Time
                          </MenuItem>
                        </Select>
                      </Box>
                    </Box>
                  )}
                </Box>

                {/* set Campaign budget */}

                {!state.budget && (
                  <Box sx={{ py: 2 }}>
                    <Box sx={{ display: "flex", alignItems: "center" }}>
                      {/* <SwitchButton /> */}
                      <Switch
                        sx={{
                          width: "50px",
                          height: "24px",
                          padding: "0px",
                          "& .MuiSwitch-switchBase": {
                            color: "#818181",
                            padding: "1px",
                            "&.Mui-checked + .MuiSwitch-track": {
                              backgroundColor: "var(--main-color)",
                            },
                          },
                          "& .MuiSwitch-thumb": {
                            color: "white",
                            width: "20px",
                            height: "20px",
                            margin: "1px",
                          },
                          "& .MuiSwitch-track": {
                            borderRadius: "20px",
                            backgroundColor: "#818181",
                            opacity: "1 !important",
                            "&:after, &:before": {
                              color: "white",
                              fontSize: "11px",
                              position: "absolute",
                              top: "6px",
                            },
                            "&:after": {
                              content: "'On'",
                              left: "8px",
                            },
                            "&:before": {
                              content: "'Off'",
                              right: "7px",
                            },
                          },
                          "& .Mui-checked": {
                            color: "#23bf58 ",
                            transform: "translateX(26px) !important",
                          },
                        }}
                        checked={state.campaign}
                        onChange={handleChange}
                        name="campaign"
                        disabled={state.budget}
                        inputProps={{ "aria-label": "secondary checkbox" }}
                      />
                      <Box
                        sx={{ pl: 2, display: "flex", alignItems: "center" }}
                      >
                        <Heading heading="Set campaign budget" />
                        <Info sx={{ ml: 2 }} className="text" />
                      </Box>
                    </Box>

                    {state.campaign && (
                      <Box sx={{ display: "flex", width: "100%" }}>
                        <Box sx={{ position: "relative" }}>
       
                          <TextField
                            error={campaign < 50} // Show error if budget is less than 50
                            id="outlined-error"
                            label="Budget"
                            helperText="At Least 50"
                            value={campaign} // Set the value of the input to the budget state
                            onChange={handleChangeCampaign} // Call handleChange when the input's value
                          />

                          <Typography
                            sx={{
                              position: "absolute",
                              top: "14px",
                              right: "7px",
                            }}
                            variant="caption"
                            className="text"
                          >
                            EUR
                          </Typography>
                        </Box>

                        <Box sx={{ml:2, width: "100%", maxWidth: "145px" }}>
                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={modeCampaign}
                            onChange={handleChangeModeCampaign}
                          >
                            <MenuItem value="BUDGET_MODE_DAY">Daily</MenuItem>
                            <MenuItem value="BUDGET_MODE_TOTAL">
                              Life Time
                            </MenuItem>
                          </Select>

       
                        </Box>
                      </Box>
                    )}
                  </Box>
                )}

                {campaignSlices.data.length === 0 ? (
                  <Button
                    className="btn"
                    type="submit"
                    onClick={checkCurrentValue}
                    sx={{ my: 2 }}
                  >
                    Continue
                  </Button>
                ) : null}

                {campaignSlices.loader && <FullScreenLoader />}

                {campaignSlices.data.length
                  ? showAlert({ type: "success", message: "created" })
                  : null}

                {campaignSlices.error.length
                  ? showAlert({
                      type: "error",
                      message: campaignSlices.error[0].data.message,
                    })
                  : null}

 
              </form>
            </Box>
          )}
        </Box>
      </CampaignStyled>
    </>
  );
};

export default Campaign;

const CampaignStyled = styled.section`
  max-width: 27rem;
`;
