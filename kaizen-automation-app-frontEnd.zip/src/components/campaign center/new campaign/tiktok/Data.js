export const awareness = [
  {
    value: "REACH",
    label: "Reach",
  },
];
export const consideration = [
  {
    value: "TRAFFIC",
    label: "Traffic",
  },
  {
    value: "VIDEO_VIEWS",
    label: "Video Views",
  } ,
  
];

export const conversions = [
  {
    value: "APP_PROMOTION",
    label: "App Promotion",
  },
  {
    value: "LEAD_GENERATION",
    label: "Lead Generation",
  },
  {
    value: "WEB_CONVERSIONS",
    label: "Website Conversions",
  },

];
export const campaignBudget = [
  {
    value: "BUDGET_MODE_DAY",
    name: "Daily",
  },
  {
    value: "BUDGET_MODE_TOTAL",
    name: "Life time",
  },
];
