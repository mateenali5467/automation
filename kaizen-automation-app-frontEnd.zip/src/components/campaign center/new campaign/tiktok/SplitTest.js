import { useState, useEffect, useRef, useReducer } from "react";
import styled from "styled-components";

import Heading from "components/common/Heading";

import Grid from "@mui/material/Grid";
import { INSTANCE } from "../../../../config/axiosInstance";

import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";

import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";

import DatePicker from "@mui/lab/DatePicker";

import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import { format } from "date-fns";

import NavigateNextIcon from "@mui/icons-material/NavigateNext";

import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";

import { useSelector, useDispatch } from "react-redux";

import SweetAlert from "react-bootstrap-sweetalert";

import FullScreenLoader from "../../../../components/common/FullScreenLoader";

const options = {
  CONVERT_RATE: "Conversion rate",
  CLICK_THROUGH_RATE: "Click through rate",
  CLICK: "Click",
  REACH: "Reach",
  SHOW: "Impression",
  CONVERT: "Conversion",
  COST_PER_SHOW: "Cost per impression",
  COST: "Cost",
  COST_PER_CONVERT: "Cost per conversion",
  COST_PER_REACH: "Cost per reach",
  COST_PER_CLICK: "Cost per click",
};

const SplitTest = () => {
  const { adSetGroup } = useSelector((res) => res);

  const givenMatric = adSetGroup.data[0].data.customObj.value;

  const newObject = givenMatric.reduce(
    (acc, key) => ({ ...acc, [key]: options[key] }),
    {}
  );

  const currentDateAdd = new Date();
  currentDateAdd.setDate(currentDateAdd.getDate() + 5);

  // Initial state
  const initialState = {
    keyMatric: Object.keys(newObject)[0],
    testVariable: "TARGETING",
    startDate: new Date(),
    endDate: currentDateAdd,
    appId: "",
    idResponse: "",
    pageNumber: 1,
    currentPage: 1,
    totalPage: 0,
    appIdTwo: "",
    idResponseTwo: "",
    pageNumberTwo: 1,
    currentPageTwo: 1,
    totalPageTwo: 0,
    sweetLoader: false,
    sweetLoaderError: false,
    loaderFull: false,
    budget: "",
  };

  // Action types
  const actionTypes = {
    SET_APP_ID: "SET_APP_ID",
    SET_APP_ID_TWO: "SET_APP_ID_TWO",
    SET_KEY_MATRIC: "SET_KEY_MATRIC",
    SET_TEST_VARIABLE: "SET_TEST_VARIABLE",
    // Add other action types as required...
    SET_BUDGET: "SET_BUDGET",
    SET_SWEET_LOADER: "SET_SWEET_LOADER",
    SET_SWEET_LOADER_ERROR: "SET_SWEET_LOADER_ERROR",
    SET_LOADER_FULL: "SET_LOADER_FULL",
    SET_PAGE_NUMBER: "SET_PAGE_NUMBER",
    SET_CURRENT_PAGE: "SET_CURRENT_PAGE",
    SET_TOTAL_PAGE: "SET_TOTAL_PAGE",
    SET_ID_RESPONSE: "SET_ID_RESPONSE",
    SET_PAGE_NUMBER_TWO: "SET_PAGE_NUMBER_TWO",
    SET_CURRENT_PAGE_TWO: "SET_CURRENT_PAGE_TWO",
    SET_TOTAL_PAGE_TWO: "SET_TOTAL_PAGE_TWO",
    SET_ID_RESPONSE_TWO: "SET_ID_RESPONSE_TWO",
  };

  // Reducer
  const reducer = (state, action) => {
    switch (action.type) {
      case actionTypes.SET_APP_ID:
        return { ...state, appId: action.payload };
      case actionTypes.SET_APP_ID_TWO:
        return { ...state, appIdTwo: action.payload };
      case actionTypes.SET_KEY_MATRIC:
        return { ...state, keyMatric: action.payload };
      case actionTypes.SET_TEST_VARIABLE:
        return { ...state, testVariable: action.payload };
      // Add other cases as required...
      case actionTypes.SET_BUDGET:
        return { ...state, budget: action.payload };
      case actionTypes.SET_SWEET_LOADER:
        return { ...state, sweetLoader: action.payload };
      case actionTypes.SET_SWEET_LOADER_ERROR:
        return { ...state, sweetLoaderError: action.payload };
      case actionTypes.SET_LOADER_FULL:
        return { ...state, loaderFull: action.payload };
      case actionTypes.SET_PAGE_NUMBER:
        return { ...state, pageNumber: action.payload };
      case actionTypes.SET_CURRENT_PAGE:
        return { ...state, currentPage: action.payload };
      case actionTypes.SET_TOTAL_PAGE:
        return { ...state, totalPage: action.payload };
      case actionTypes.SET_ID_RESPONSE:
        return { ...state, idResponse: action.payload };
      case actionTypes.SET_PAGE_NUMBER_TWO:
        return { ...state, pageNumberTwo: action.payload };
      case actionTypes.SET_CURRENT_PAGE_TWO:
        return { ...state, currentPageTwo: action.payload };
      case actionTypes.SET_TOTAL_PAGE_TWO:
        return { ...state, totalPageTwo: action.payload };
      case actionTypes.SET_ID_RESPONSE_TWO:
        return { ...state, idResponseTwo: action.payload };
      default:
        return state;
    }
  };

  // const [keyMatric, setKeyMatric] = useState(Object.keys(newObject)[0]);
  // const [testVariable,setTextVariable] = useState('TARGETING');

  // const [startDate, setStartDate] = useState(new Date());

  // const [endDate, setEndDate] = useState(currentDateAdd);

  // const [appId, setAppId] = useState('');

  // const [idResponse,setIdResponse] = useState('');

  // const [pageNumber, setPageNumber] = useState(1);

  // const [currentPage, setCurrentPage] = useState(1);
  // const [totalPage, setTotalPage] = useState(0);

  // const [appIdTwo, setAppIdTwo] = useState('');

  // const [idResponseTwo, setIdResponseTwo] = useState('');
  // const [pageNumberTwo, setPageNumberTwo] = useState(1);
  // const [currentPageTwo, setCurrentPageTwo] = useState(1);
  // const [totalPageTwo, setTotalPageTwo] = useState(0);

  // const [sweetLoader,setShowSweetAlert] = useState(false);
  // const [sweetLoaderError,setSweetLoaderError] = useState(false);

  // const [loaderFull,setFullLoader] = useState(false)

  //   const handleChangeAppIdTwo = (event) => {
  //     setAppIdTwo(event.target.value);
  //   };

  // const handleChangeAppId = (event) => {
  //   setAppId(event.target.value);
  // };

  // const handleChangeMatric = (event) => {
  //     setKeyMatric(event.target.value);
  // };

  // const handleChangeTestVariable = (event)=>{
  //     setTextVariable(event.target.value)
  // }

  
  // Hook that manages state and dispatch function using the reducer and initial state
  const [state, dispatch] = useReducer(reducer, initialState);

  // Function to handle changes to the first App ID
  const handleChangeAppId = (event) => {
    dispatch({ type: actionTypes.SET_APP_ID, payload: event.target.value });
  };

  // Function to handle changes to the second App ID
  const handleChangeAppIdTwo = (event) => {
    dispatch({ type: actionTypes.SET_APP_ID_TWO, payload: event.target.value });
  };

  // Function to handle changes to the Matric Key
  const handleChangeMatric = (event) => {
    dispatch({ type: actionTypes.SET_KEY_MATRIC, payload: event.target.value });
  };

  // Function to handle changes to the Test Variable
  const handleChangeTestVariable = (event) => {
    dispatch({
      type: actionTypes.SET_TEST_VARIABLE,
      payload: event.target.value,
    });
  };

  const validationSchema = Yup.object().shape({
    budget: Yup.number()
      .required("Required")
      .typeError("Budget must be a number"),
  });

  const initialValues = {
    budget: "",
  };

  const submitForm = async (values) => {
    // Simulate a API call

    //     let startDated = new Date(startDate);

    //     let formattedDateStart = format(startDated, 'yyyy-MM-dd HH:mm:ss');

    //     let endDated = new Date(endDate);

    //     let formattedDateEnd = format(endDated, 'yyyy-MM-dd HH:mm:ss');

    //  //    const splitData = {};

    //     // splitData['budget'] = values.budget;
    //     // splitData['key_metric'] = keyMatric;
    //     // splitData['test_variable'] = testVariable;
    //     // splitData['start_time'] = formattedDateStart;
    //     // splitData['end_time'] = formattedDateEnd;
    //     // splitData['object_ids'] = [appId,appIdTwo];

    //     const splitData = {
    //       budget: values.budget,
    //       key_metric: keyMatric,
    //       test_variable: testVariable,
    //       start_time: formattedDateStart,
    //       end_time: formattedDateEnd,
    //       object_ids: [appId, appIdTwo],
    //   };

    //     console.log(splitData);

    //      try{
    //        setFullLoader(true)
    //         const res = await INSTANCE.post("/split-test/create-split-test", splitData);
    //         setFullLoader(false)

    //         setShowSweetAlert(true)
    //         console.log(res);

    //     }
    //     catch(error){
    //       console.log(error.response.data)
    //       setFullLoader(false)
    //       setSweetLoaderError(true)
    //     }

    let startDated = new Date(state.startDate);
    let formattedDateStart = format(startDated, "yyyy-MM-dd HH:mm:ss");
    let endDated = new Date(state.endDate);
    let formattedDateEnd = format(endDated, "yyyy-MM-dd HH:mm:ss");

    // Prepare the data to be sent in the API request
    const splitData = {
      budget: values.budget,
      key_metric: state.keyMatric,
      test_variable: state.testVariable,
      start_time: formattedDateStart,
      end_time: formattedDateEnd,
      object_ids: [state.appId, state.appIdTwo],
    };

    console.log(splitData);

    try {
      
      // Set the loader to indicate that the API call is in progress
      dispatch({ type: actionTypes.SET_LOADER_FULL, payload: true });

      // Make the API request to create the split test
      const res = await INSTANCE.post(
        "/split-test/create-split-test",
        splitData
      );

      // Reset the loader and show success message
      dispatch({ type: actionTypes.SET_LOADER_FULL, payload: false });
      dispatch({ type: actionTypes.SET_SWEET_LOADER, payload: true });
      console.log(res);
    } catch (error) {
      // Handle API request error, reset loader and show error message
      console.log(error.response.data);
      dispatch({ type: actionTypes.SET_LOADER_FULL, payload: false });
      dispatch({ type: actionTypes.SET_SWEET_LOADER_ERROR, payload: true });
    }
  };

  // This function fetches data and updates the state for the first set of results
  const getData = async () => {
    try {
      // dispatch an action to set 'SET_ID_RESPONSE' as an empty string
      dispatch({ type: actionTypes.SET_ID_RESPONSE, payload: "" });

      // perform your async operation here, and then..
      const res = await INSTANCE.get(
        `/campaign/view-adgroups/10/${state.pageNumber}`
      );
      dispatch({
        type: actionTypes.SET_CURRENT_PAGE,
        payload: res.data.data.pagination.page,
      });
      dispatch({
        type: actionTypes.SET_TOTAL_PAGE,
        payload: res.data.data.pagination.total_page,
      });
      dispatch({
        type: actionTypes.SET_ID_RESPONSE,
        payload: res.data.data.adGroups,
      });
    } catch (e) {
      // handle error
    }
  };

  // This function fetches data and updates the state for the second set of results
  const getDataTwo = async () => {
    try {
      dispatch({ type: actionTypes.SET_ID_RESPONSE_TWO, payload: "" });

      // perform your async operation here, and then...
      const res = await INSTANCE.get(
        `/campaign/view-adgroups/10/${state.pageNumberTwo}`
      );
      dispatch({
        type: actionTypes.SET_CURRENT_PAGE_TWO,
        payload: res.data.data.pagination.page,
      });
      dispatch({
        type: actionTypes.SET_TOTAL_PAGE_TWO,
        payload: res.data.data.pagination.total_page,
      });
      dispatch({
        type: actionTypes.SET_ID_RESPONSE_TWO,
        payload: res.data.data.adGroups,
      });
    } catch (e) {
      // handle error
    }
  };

  // Function to handle the next page for the first set of results
  const handleNextPage = () => {
    dispatch({
      type: actionTypes.SET_PAGE_NUMBER,
      payload: state.pageNumber + 1,
    });
  };

  // Function to handle the previous page for the first set of results
  const handlePrevPage = () => {
    if (state.pageNumber > 1) {
      dispatch({
        type: actionTypes.SET_PAGE_NUMBER,
        payload: state.pageNumber - 1,
      });
    }
  };

  // Function to handle the next page for the second set of results
  const handleNextPageTwo = () => {
    dispatch({
      type: actionTypes.SET_PAGE_NUMBER_TWO,
      payload: state.pageNumberTwo + 1,
    });
  };

  // Function to handle the previous page for the second set of results
  const handlePrevPageTwo = () => {
    if (state.pageNumberTwo > 1) {
      dispatch({
        type: actionTypes.SET_PAGE_NUMBER_TWO,
        payload: state.pageNumberTwo - 1,
      });
    }
  };

  useEffect(() => {
    getData();
    getDataTwo();
  }, [state.pageNumber, state.pageNumberTwo]);

  // const handleConfirmAlertSuccess = ()=>{
  //  setShowSweetAlert(false)

  // }

  // const handleConfirmAlertError = ()=>{
  //   setSweetLoaderError(false);
  // }

  // Function to handle the confirmation of a success alert
  const handleConfirmAlertSuccess = () => {
    dispatch({ type: actionTypes.SET_SHOW_SWEET_ALERT, payload: false });
  };

  // Function to handle the confirmation of an error alert
  const handleConfirmAlertError = () => {
    dispatch({ type: actionTypes.SET_SWEET_LOADER_ERROR, payload: false });
  };

  // Function to display an alert with the specified message and icon
  const ShowAlert = ({ message, icon }) => {
    return (
      <SweetAlert icon={icon} title={icon}>
        {message}
      </SweetAlert>
    );
  };

  return (
    <>
      <CampaignStyled>
        {state.loaderFull && <FullScreenLoader />}

        {state.sweetLoader && (
          <Box>
            <SweetAlert success showConfirm={false} title="Success!">
              <div>Ads Create Successfully</div>
              <Button
                sx={{ mt: 3 }}
                variant="contained"
                color="success"
                onClick={handleConfirmAlertSuccess}
              >
                OK
              </Button>
            </SweetAlert>
          </Box>
        )}

        {state.sweetLoaderError && (
          <Box>
            <SweetAlert error showConfirm={false} title="Error !">
              <div>something is not right</div>
              <Button
                sx={{ mt: 3 }}
                variant="contained"
                color="warning"
                onClick={handleConfirmAlertError}
              >
                OK
              </Button>
            </SweetAlert>
          </Box>
        )}

        {/* APP ID SELECT */}
        <Box>
          <Heading heading="Add Group  Id " />
          <Box>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label"> Id</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={state.appId}
                label="id"
                onChange={handleChangeAppId}
                MenuProps={{
                  PaperProps: {
                    style: {
                      maxHeight: 350, // Adjust the height as needed
                    },
                  },
                }}
              >
                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <Button
                    disabled={state.currentPage === 1}
                    onClick={handlePrevPage}
                  >
                    <NavigateBeforeIcon />
                  </Button>
                  <div>
                    <span>
                      {state.currentPage} - {state.totalPage}
                    </span>
                  </div>
                  <Button
                    disabled={state.currentPage === state.totalPage}
                    onClick={handleNextPage}
                  >
                    <NavigateNextIcon />
                  </Button>
                </div>

                {state.idResponse === "" ? (
                  <MenuItem>Loading</MenuItem>
                ) : (
                  state.idResponse.map((item, index) => (
                    <MenuItem key={item.adgroup_id} value={item.adgroup_id}>
                      {item.adgroup_name}
                    </MenuItem>
                  ))
                )}
              </Select>
            </FormControl>
          </Box>
        </Box>

        <Box>
          {/* APP ID SELECT Two*/}
          <Heading heading="Add Group  Id Two " />
          <Box>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label"> Id</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={state.appIdTwo}
                label="id"
                onChange={handleChangeAppIdTwo}
                MenuProps={{
                  PaperProps: {
                    style: {
                      maxHeight: 350,
                    },
                  },
                }}
              >
                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <Button
                    disabled={state.currentPageTwo === 1}
                    onClick={handlePrevPageTwo}
                  >
                    <NavigateBeforeIcon />
                  </Button>
                  <div>
                    <span>
                      {state.currentPageTwo} - {state.totalPageTwo}
                    </span>
                  </div>
                  <Button
                    disabled={state.currentPageTwo === state.totalPageTwo}
                    onClick={handleNextPageTwo}
                  >
                    <NavigateNextIcon />
                  </Button>
                </div>

                {state.idResponseTwo === "" ? (
                  <MenuItem>Loading</MenuItem>
                ) : (
                  state.idResponseTwo.map((item, index) => (
                    <MenuItem key={item.adgroup_id} value={item.adgroup_id}>
                      {item.adgroup_name}
                    </MenuItem>
                  ))
                )}
              </Select>
            </FormControl>
          </Box>

          {/* KEY MATRIC START */}
          <Heading heading="Key Matrix" />
          <Box>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Key Matric</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={state.keyMatric}
                label="Key Matric"
                onChange={handleChangeMatric}
              >
                {Object.entries(newObject).map(([value, name]) => (
                  <MenuItem key={value} value={value}>
                    {name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>

          {/* TEST VARIABLE */}
          <Heading heading="Test Variable" />
          <Box>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Variable</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={state.testVariable}
                label="Key Matric"
                onChange={handleChangeTestVariable}
              >
                <MenuItem value="BIDDING_OPTIMIZATION">
                  Bidding Optimization
                </MenuItem>
                <MenuItem value="TARGETING">Targeting</MenuItem>
                <MenuItem value="CREATIVE">Creative</MenuItem>
              </Select>
            </FormControl>
          </Box>

          {/* DATE PICKERS */}
          <Grid container spacing={2} direction="row">
            <Grid item xs={12} md={6}>
              <Box>
                <Heading heading="Start Date" />
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="Start Date"
                    value={state.startDate}
                    minDate={new Date()}
                    onChange={(newValue) => {
                      if (newValue) {
                        // newValue might be null, so check for truthy value
                        dispatch({ type: "SET_START_DATE", payload: newValue });
                      }
                    }}
                    renderInput={(params) => <TextField {...params} />}
                  />
                </LocalizationProvider>
              </Box>
            </Grid>
            <Grid item xs={12} md={6}>
              <Box>
                <Heading heading="End Date" />
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="End Date"
                    value={state.endDate}
                    minDate={new Date()}
                    onChange={(newValue) => {
                      if (newValue) {
                        // newValue might be null, so check for truthy value
                        dispatch({ type: "SET_END_DATE", payload: newValue });
                      }
                    }}
                    renderInput={(params) => <TextField {...params} />}
                  />
                </LocalizationProvider>
              </Box>
            </Grid>
          </Grid>

          {/* BUDGET */}
          <Box>
            <Heading heading="Budget" />
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={submitForm}
            >
              {({ errors, touched }) => (
                <Form>
                  <Box sx={{ display: "flex", flexDirection: "column" }}>
                    <Field
                      name="budget"
                      as={TextField}
                      id="outlined-basic"
                      label="Budget"
                      variant="outlined"
                      helperText={touched.budget ? errors.budget : ""}
                      error={touched.budget && Boolean(errors.budget)}
                    />

                    <Button sx={{ mt: 2 }} type="submit" variant="contained">
                      Submit
                    </Button>
                  </Box>
                </Form>
              )}
            </Formik>
          </Box>
        </Box>
      </CampaignStyled>
    </>
  );
};
export default SplitTest;

const CampaignStyled = styled.section`
  max-width: 30rem;
`;
