import React, { useState,useEffect } from "react";
import {
  Box,
  Grid,
  FormControl,
  Select,
  MenuItem,
  OutlinedInput,
  Tooltip,
  Card,
  CardActions,
  CardContent,
  Button,
  Typography,
  Divider,
  InputAdornment,
} from "@mui/material";
import { nanoid } from "@reduxjs/toolkit";

import { useDispatch } from "react-redux";
import { getCurrentStatus } from "../../slices/statusSlice";


const SelectMenu = ({ placeholder, data, color, setChanged , name=null,disabled=true,paddingProps=false}) => {
  
  const dispatch = useDispatch();
  const [age, setAge] = useState("");

  useEffect(()=>{
    sessionStorage.setItem("budgetMode",JSON.stringify("BUDGET_MODE_DAY"));
  },[])

  return (
    <>
      {/* <start /> */}
      <FormControl sx={{ width: "100%" }}>
        <Select
          displayEmpty
          value={age}
          input={<OutlinedInput />}
          className="text primary_color"
          sx={{
            fieldset: {
              border: "1px solid",
              borderRadius: "5px",
              borderColor: "inherit !important",
            },
            "& .MuiSelect-select": {
               padding: paddingProps ? "5px" : "12px  10px",
               color: color && "#fff !important",
              // background: "var(--main-color)",
            },
            svg: {
              color: "inherit",
            },
            background: color && `${color} !important`,
            color: color && "#fff !important",
          }}
          placeholder="Age"
          onChange={(e) => {

          // const compaignObjBudget = {
          //   budget : ""
          // }
          // const compaignObjCompaign = {
          //   compaign : ""
          // }
          //   if(name === "budget" && (e.target.value === "monthly" || e.target.value === "daily")){
          //     compaignObjBudget.budget = e.target.value;
          //      sessionStorage.setItem("compaignObjBudget",JSON.stringify(compaignObjBudget));
          //   }

             
          //   if(name === "Compaign" && (e.target.value === "monthly" || e.target.value === "daily")){
          //     compaignObjCompaign.compaign = e.target.value;
          //     sessionStorage.setItem("compaignObjCompaign",JSON.stringify(compaignObjCompaign));
          //   }

            if(e.target.value === "BUDGET_MODE_DAY" ){
              
              sessionStorage.setItem("budgetMode",JSON.stringify("BUDGET_MODE_DAY"));
            }
            if(e.target.value === "BUDGET_MODE_TOTAL"){
              sessionStorage.setItem("budgetMode",JSON.stringify("BUDGET_MODE_TOTAL"));
            }

            sessionStorage.setItem("apv",JSON.stringify(e.target.value));
            dispatch(getCurrentStatus(e.target.value));

            setAge(e.target.value);
            if (setChanged) setChanged(e.target.value);

          }}
          inputProps={{
            "aria-label": "Without label",
            className: "border text ",
          }}
          InputProps={{
            className: "text ",
          }}
        >
          <MenuItem disabled={disabled} value="">
            <p>{placeholder}</p>
          </MenuItem>
          {data &&
            data.map((item, index) => (
              <MenuItem value={item.value} key={nanoid()}>
                {item.name}
              </MenuItem>
            ))}
        </Select>
      </FormControl>
    </>
  );
};

export default SelectMenu;
