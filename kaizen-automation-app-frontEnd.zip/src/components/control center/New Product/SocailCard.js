import React from "react";
import styled from "styled-components";
import { Box, Typography, Link } from "@mui/material";
const SocailCard = ({ icon, heading }) => {
  return (
    <>
      <SocailCardStyled>
        <Box
          className="primary_color"
          sx={{ borderRadius: "5px", py: 2, px: 2, height: "100%" }}
        >
          <Box className="icon">{icon}</Box>
          <Box sx={{ pt: 1 }}>
            <Typography variant="h6" component="div">
              {heading}
            </Typography>
            <Link underline="hover" sx={{ color: "var(--main-color)" }}>
              Connect
            </Link>
          </Box>
        </Box>
      </SocailCardStyled>
    </>
  );
};

export default SocailCard;

const SocailCardStyled = styled.section`
  cursor: pointer;
  height: 100%;
  &:hover {
    .primary_color {
      transition: 1s;
      background: var(--main-color) !important;
    }
    div,
    a,
    svg {
      color: #fff;
      fill: #fff !important;
      transition: 0.4s;
    }
  }
`;
