import React, { useState } from "react";
import { Box, Grid, Typography, Button, Tab, Divider } from "@mui/material";
import {
  Facebook,
  SignalCellularAlt,
  RadioButtonChecked,
} from "@mui/icons-material";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import styled from "styled-components";
import CardImage from "../../../assets/images/pexels-zukiman-mohamad-22185.jpg";
import Slider from "react-slick";

const card = [{}, {}, {}];
const settings = {
  dots: false,
  infinite: false,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
};

const SliderContent = () => {
  const [value, setValue] = useState("1");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <>
      <Box
        className="primary_color slilder_wrapper"
        sx={{ padding: "2rem 1rem", borderRadius: "5px" }}
      >
        <Box>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Typography variant="body" className="fw_bold" component="div">
              Campaign# 01
            </Typography>
            <Typography
              variant="body"
              className="fw_bold active_btn"
              component="div"
            >
              <RadioButtonChecked sx={{ mr: 1, fontSize: "14px" }} />
              Active
            </Typography>
          </Box>

          <Typography
            variant="body"
            className=""
            sx={{ fontSize: "14px", pt: 2 }}
            component="div"
          >
            Campaign Date
          </Typography>
          <Typography
            variant="body"
            className=""
            //   sx={{ fontSize: "14px", pt: 2 }}
            component="div"
          >
            08/06/202 <span className="fw_bold">to</span> 08/06/202
          </Typography>
        </Box>
        {/* tabs  */}
        <Box sx={{ py: 2 }}>
          <TabContext value={value}>
            <Box>
              <TabList
                onChange={handleChange}
                aria-label="lab API tabs example"
                variant="scrollable"
                allowScrollButtonsMobile
                scrollButtons
                sx={{
                  background: "#dcdcdc",
                  padding: "6px 8px",
                  borderRadius: "30px",
                  boxShadow: "inset 0 0 4px #b5b5b5",
                  "& .MuiTabScrollButton-root": {
                    display: {
                      xs: "flex !important",
                      lg: "none !important",
                    },
                  },
                  "& 	.tab_btn": {
                    width: "100%",
                    // height: "37px",
                    minHeight: "40px !important",
                    // borderRadius: "5px",
                    minWidth: "220px",
                    background: "transparent",
                    // marginRight: "15px",
                    color: "#707070",
                    maxWidth: "100%",
                    flexShrink: "inherit",
                    borderRadius: "30px",
                    fontWeight: "bold",
                  },
                  "& 	.MuiTabs-indicator": {
                    // background: "none",
                    height: "4px",
                    display: "none",
                    background: "var(--main-color)",
                  },
                  "& svg": {
                    height: "20px",
                    "& fill": {
                      color: "#707070",
                    },
                  },
                  "& 	.Mui-selected": {
                    background: "var(--main-color) !important",
                    // borderColor: "var(--main-color) !important",
                    color: "#ffff !important",
                  },
                  "& 	.Mui-selected svg": {
                    fill: "#fff !important",
                  },
                }}
              >
                <Tab
                  label="Creatives"
                  value="1"
                  className="tab_btn"
                  icon={<Facebook />}
                  iconPosition="start"
                />
                <Tab
                  label=" Reports"
                  value="2"
                  className="tab_btn"
                  icon={<SignalCellularAlt />}
                  iconPosition="start"
                />
              </TabList>
            </Box>
            <TabPanel value="1">
              <Box>
                <Grid container spacing={3}>
                  {card.map((data, index) => (
                    <>
                      <Grid
                        item
                        md={4}
                        sm={6}
                        xs={12}
                        sx={{ "& .no_wrap": { whiteSpace: "nowrap" } }}
                      >
                        <Box>
                          <img src={CardImage} alt="" className="card_image" />
                          <Typography
                            varient="h6"
                            className="text"
                            sx={{
                              whiteSpace: "nowrap",
                              textAlign: "center",
                              fontWeight: "bold",
                              py: 2,
                            }}
                          >
                            Subway Sufer.mp4
                          </Typography>
                          <Grid container spacing={3} sx={{}}>
                            <Grid item md={6}>
                              <Box
                                sx={{ display: "flex", alignItems: "center" }}
                              >
                                <Typography
                                  varient="h6"
                                  className="text"
                                  sx={{
                                    //   py: 1,
                                    fontSize: "14px",
                                  }}
                                >
                                  CPI:
                                </Typography>
                                <Typography
                                  varient="h6"
                                  // className="text"
                                  className="no_wrap"
                                  sx={{ pl: 2, color: "var(--main-color)" }}
                                >
                                  0.00 $
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item md={6}>
                              <Box
                                sx={{ display: "flex", alignItems: "center" }}
                              >
                                <Typography
                                  varient="h6"
                                  className="text"
                                  sx={{
                                    //   py: 1,
                                    fontSize: "14px",
                                  }}
                                >
                                  CPI:
                                </Typography>
                                <Typography
                                  varient="h6"
                                  className="no_wrap"
                                  sx={{ pl: 2, color: "var(--main-color)" }}
                                >
                                  0.00 $
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item md={6}>
                              <Box
                                sx={{ display: "flex", alignItems: "center" }}
                              >
                                <Typography
                                  varient="h6"
                                  className="text"
                                  sx={{
                                    //   py: 1,
                                    fontSize: "14px",
                                  }}
                                >
                                  CPI:
                                </Typography>
                                <Typography
                                  varient="h6"
                                  className="no_wrap"
                                  sx={{ pl: 2, color: "var(--main-color)" }}
                                >
                                  0.00 $
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item md={6}>
                              <Box
                                sx={{ display: "flex", alignItems: "center" }}
                              >
                                <Typography
                                  varient="h6"
                                  className="text"
                                  sx={{
                                    //   py: 1,
                                    fontSize: "14px",
                                  }}
                                >
                                  CPI:
                                </Typography>
                                <Typography
                                  varient="h6"
                                  className="no_wrap"
                                  sx={{ pl: 2, color: "var(--main-color)" }}
                                >
                                  0.00 $
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item md={6}>
                              <Box
                                sx={{ display: "flex", alignItems: "center" }}
                              >
                                <Typography
                                  varient="h6"
                                  className="text"
                                  sx={{
                                    //   py: 1,
                                    fontSize: "14px",
                                  }}
                                >
                                  CPI:
                                </Typography>
                                <Typography
                                  varient="h6"
                                  className="no_wrap"
                                  sx={{ pl: 2, color: "var(--main-color)" }}
                                >
                                  0.00 $
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item md={6}>
                              <Box
                                sx={{ display: "flex", alignItems: "center" }}
                              >
                                <Typography
                                  varient="h6"
                                  className="text"
                                  sx={{
                                    fontSize: "14px",
                                  }}
                                >
                                  CPI:
                                </Typography>
                                <Typography
                                  varient="h6"
                                  className="no_wrap"
                                  sx={{ pl: 2, color: "var(--main-color)" }}
                                >
                                  0.00 $
                                </Typography>
                              </Box>
                            </Grid>
                          </Grid>
                        </Box>
                      </Grid>
                    </>
                  ))}
                </Grid>
              </Box>
            </TabPanel>
            <TabPanel value="2">Item Two</TabPanel>
          </TabContext>
        </Box>
      </Box>
    </>
  );
};
const InnerTab = () => {
  return (
    <>
      <InnerTabStyled>
        <Box>
          <Slider {...settings}>
            <SliderContent />
            <SliderContent />
            <SliderContent />
          </Slider>
        </Box>
      </InnerTabStyled>
    </>
  );
};

export default InnerTab;

const InnerTabStyled = styled.section`
  .card_image {
    width: 100%;
    border-radius: 5px;
  }
  .slilder_wrapper {
    /* position: relative; */
  }
  .slick-prev {
    top: 2.8rem;
    left: 10rem;
  }

  .slick-next {
    top: 2.8rem;
    left: 12rem;
  }
  .slick-slider {
    button {
      z-index: 2;
    }
  }
  .slick-prev:before,
  .slick-next:before {
    color: var(--main-color);
  }

  .active_btn {
    background: var(--light-grey-color);
    color: var(--main-color);
    width: 94px;
    height: 38px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 32px;
  }

  @media (max-width: 400px) {
    .slick-prev {
      top: 1.2rem;
      left: 1rem;
    }

    .slick-next {
      top: 1.2rem;
      left: 3rem;
    }
  }
`;
