// export const baseURL = "http://192.168.100.20:3001/api/v1";
//export const baseURL = "https://automation.thecbt.cyou/api/v1";

 export const baseURL = "https://apiautomation.thecbt.live/api/v1";

 //export const baseURL = "http://192.168.2.150:3002/api/v1";


export const tiktokAccountURL =  "";
  // https://ads.tiktok.com/marketing_api/auth?app_id=7064602282607771649&state=your_custom_params&redirect_uri=http%3A%2F%2Fapp.automation.thecbt.cyou%2Fconfirmation&rid=a5wdmnfbrp4

