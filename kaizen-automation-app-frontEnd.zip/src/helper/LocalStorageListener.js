import { useEffect } from "react";

function LocalStorageListener({ onTokenChange }) {
    useEffect(() => {
        const handleStorageChange = (e) => {
            if (e.key !== 'token' || e.storageArea !== localStorage) return;
            onTokenChange && onTokenChange(e.newValue);
        };

        window.addEventListener('storage', handleStorageChange);
        return () => window.removeEventListener('storage', handleStorageChange);
    }, [onTokenChange]);

    return null;

}



export default LocalStorageListener;
