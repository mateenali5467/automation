import { Navigate, useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";

const LoginRoutes = () => {
  const [localToken, setLocalToken] = useState(localStorage.getItem("token"));
  const navigate = useNavigate();

  // Check and act on token changes
  useEffect(() => {
    // Initial redirect based on the token's presence
    if (localToken) {
      Navigate("/dashboard", { replace: true });
    } else {
      Navigate("/", { replace: true });
    }

    // Detect changes in token in localStorage
    const handleStorageChange = (e) => {
      if (e.key === 'token' && e.storageArea === localStorage) {
        // If token is deleted or changed, go to homepage
        if (!e.newValue || e.oldValue !== e.newValue) {
          Navigate("/", { replace: true });
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);

    // Cleanup on component unmount
    return () => window.removeEventListener('storage', handleStorageChange);

  }, [navigate, localToken]);

  return null;  // Render nothing as this component only contains logic
};

export default LoginRoutes;
