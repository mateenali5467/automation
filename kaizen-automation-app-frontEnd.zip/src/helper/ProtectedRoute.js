import { Navigate, Outlet } from "react-router-dom";
import React from "react";

const useAuth = () => {
  const token = localStorage.getItem("token");
  return token ? true : false;

};



const ProtectedRoute = () => {
  
  const isAuth = useAuth();
  return isAuth ? <Outlet /> : <Navigate to="/" />;

};

export default ProtectedRoute;




