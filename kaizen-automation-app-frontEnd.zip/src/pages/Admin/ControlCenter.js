import React from "react";
import ResponsiveDrawer from "../../components/Layout/Drawer/DesktopDrawer";
const ControlCenter = () => {
  return (
    <>
      <ResponsiveDrawer></ResponsiveDrawer>
    </>
  );
};

export default ControlCenter;
