
import {useState,useEffect}  from "react";

import { Box,FormGroup, FormControlLabel, Switch, Typography, Dialog, DialogActions, Button,DialogContent,DialogContentText,DialogTitle,Table, TableBody, TableCell, TableHead, TableRow, Paper,TextField,Select, MenuItem,CircularProgress,InputLabel  } from '@mui/material';

import NewTableMockup from "components/Google/NewTableMockup";

import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';


import { baseURL } from "config/endpoint";
import {INSTANCE} from "../../config/axiosInstance";

import ConfirmationDialog from "./ConfirmationDialog";

import AccountTable from "./AccountTable";


import { useDispatch,useSelector } from "react-redux";
import { getAllAccountAPi } from "slices/showAllAccountsSlices";

import TaskCondition from "./TaskCondition";

const AccountShow = ()=>{


  const dispatch = useDispatch();
  const { showAllAccountsSlices } = useSelector(res=>res);


    const [customerData, setCustomerData] = useState([]);

      const [openPopup, setOpenPopup] = useState(false);
      const [currentSwitch, setCurrentSwitch] = useState(null);


      const [searchTerm, setSearchTerm] = useState('');

      const [filter, setFilter] = useState('all');


      const handleSwitchChange = async (event, data) => {
        console.log(data.is_connected);
    
        if (!event.target.checked) {
            setCurrentSwitch(data); // Set the current item id
            setOpenPopup(true); // Open the confirmation dialog
        } else {
            // If it’s being toggled on, update the state immediately
            updateConnectionStatus(data, 1);
            postServerStatus(data.account_id, true);
        }
    };
    
    const updateConnectionStatus = (data, status) => {
        console.log("disconnect", data.id);
    
        setCustomerData(prevData =>
            prevData.map(item =>
                item.id === data.id
                    ? { ...item, is_connected: status }
                    : item
            )
        );
    
        postServerStatus(data.account_id, false);
    };
    


    const postServerStatus = async (accountId, isConnected) => {
        try {
            await INSTANCE.post(`/campaign/google/connect/adAccount/${accountId}`, {
                is_connected: isConnected
            });
        } catch (error) {
            console.error("Error updating server status:", error);
        }
    };



      const handleDisconnect = () => {
        updateConnectionStatus(currentSwitch, 0); // Disconnect the selected item
        setOpenPopup(false); // Close the confirmation dialog
      };
      
      const handleCancel = () => {
        setOpenPopup(false); // Simply close the dialog if action is canceled
      };
    

     // Filter the customer data based on search term

     const filteredData = customerData.filter(item => 
      item.descriptiveName.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (filter === 'all' || (filter === 'connected' && item.is_connected === 1) || (filter === 'notConnected' && item.is_connected === 0))
    );
  
 
  
   // First useEffect to dispatch the action on component mount
    useEffect(() => {
      dispatch(getAllAccountAPi());
    }, []); // Empty dependency array means this useEffect runs once when component mounts

    // Second useEffect to update customerData when showAllAccountsSlices changes
    useEffect(() => {
      if (showAllAccountsSlices.data.length > 0) {
        setCustomerData(showAllAccountsSlices.data[0].update_user); 
      }
    }, [showAllAccountsSlices]); // showAllAccountsSlices as dependenc


   return (
    <>
       
     {/* MODEL COMPONENT */}
      <ConfirmationDialog 
        open={openPopup} 
        onDisconnect={handleDisconnect} 
        onCancel={handleCancel}
      />
  {/*  MODEL COMPONENT */}



<Paper style={{ margin: 20 }}>
<div style={{ display: 'flex', alignItems: 'center', margin: '10px', paddingTop: '20px' }}>
      <TextField
        size="small"
        variant="outlined"
        value={searchTerm}
        placeholder="Search"
        onChange={e => setSearchTerm(e.target.value)}
        style={{ 
          marginRight: '10px',
          
        }} // Adjusted style
        InputProps={{
          style: { 
            fontSize: 12, 
            padding: '5px 10px', // Adjusted padding
          },
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon style={{ fontSize: '18px' }} /> {/* Adjust the icon size */}
            </InputAdornment>
          ),
        }}
      />
     
     
    <Select
        size="small"
        value={filter}
        onChange={e => setFilter(e.target.value)}
        variant="outlined"
        style={{
          padding: '5px 10px',  // Adjust the padding
          fontSize: '12px',     // Adjust the font size
          minWidth: '100px'     // Set a minimum width
        }}
        MenuProps={{ // Adding MenuProps to style the dropdown
          anchorOrigin: {
            vertical: 'bottom',
            horizontal: 'left',
          },
          transformOrigin: {
            vertical: 'top',
            horizontal: 'left',
          },
          getContentAnchorEl: null, // This prevents the menu from being positioned based on the content anchor
        }}
      >
        <MenuItem value="all">All Accounts</MenuItem>
        <MenuItem value="connected">Connected Accounts</MenuItem>
        <MenuItem value="notConnected">Not Connected Accounts</MenuItem>
      </Select>
    </div>


<div>
    {showAllAccountsSlices.loader ? (
      <Box
    display="flex"
    justifyContent="center"
   
    minHeight="100vh" // This assumes you want the loader to be centered on the entire viewport. Adjust as necessary.
  >
    <CircularProgress size={30} />
  </Box> // Replace this with your actual Loader component
    ) : (
      <AccountTable  
          filteredData={filteredData} 
          handleSwitchChange={handleSwitchChange} 
       />

    )}
  </div>



    </Paper>






    </>
   )
}
export default AccountShow;