import { useState,useEffect } from 'react';


import { baseURL } from "config/endpoint";
import { INSTANCE } from "../../config/axiosInstance";


import {
    Table,
    TableHead,
    TableRow,
    TableCell,
    TableBody,
    Switch,
  } from '@mui/material';



  // Data Table component
  const AccountTable = ({ filteredData, handleSwitchChange }) => {




    return (
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Spent Last 30 Days</TableCell>
            <TableCell>Ad Account ID</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {filteredData.length > 0 ? (
            filteredData.map(item => (
              <TableRow key={item.id}>
                <TableCell>
                  <Switch
                    checked={item.is_connected === 1}
                    onChange={event => handleSwitchChange(event, item)}
                    color="primary"
                  />
                  {item.descriptiveName}
                </TableCell>
                <TableCell>
                  <div
                    style={{
                      backgroundColor: 'lightgrey',
                      color: 'blue',
                      borderRadius: '4px',
                      display: 'inline-block',
                      padding: '4px',
                    }}
                  >
                    <span style={{ fontSize: '12px' }}>{item.status.toLowerCase()}</span>
                  </div>
                </TableCell>
                <TableCell>{item.spentLast30Days || '-'}</TableCell>
                <TableCell>{item.id}</TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={4} align="center">
                Nothing was found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    );
  };

  export default AccountTable;