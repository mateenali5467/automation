import React, { useState,useEffect } from 'react';
import {
    Box, Typography, TextField, Button, Popover, List, ListItem, InputAdornment, IconButton,Divider
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';

import { getAllAccountAPi } from 'slices/showAllAccountsSlices';
import { useSelector,useDispatch } from 'react-redux';

import FilterCampaign from './FilterCampaign';

import SideModel from 'components/SideModel';


import { baseURL } from "config/endpoint";
import { INSTANCE } from "../../config/axiosInstance";

import Heading from 'components/common/Heading';


const AddAccount = ()=>{


    const dispatch = useDispatch();
    const { showAllAccountsSlices } = useSelector(res=>res);
    
    const [data, setData] = useState([]);
    const [anchorEl, setAnchorEl] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedAccount, setSelectedAccount] = useState('');

    const [selectedCampaignType, setSelectedCampaignType] = useState('Display');

    const [anchorElCampaign, setAnchorElCampaign] = useState(null);
    const campaignTypes = ['Search', 'Display', 'Shopping', 'App', 'Performance Max'];


    const [isSidebarOpen, setSidebarOpen] = useState(false);

    const toggleSidebar = () => {
        setAnchorEl(null);
        setSidebarOpen(!isSidebarOpen);
    };


    
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
       
    };

    const handleAccountClick = (account) => {
        setSelectedAccount(account);
        handleClose();  
    };
    sessionStorage.setItem("selectedAccount", JSON.stringify(selectedAccount));

    const handleClickCampaign = (event) => {
        setAnchorElCampaign(event.currentTarget);
       
    };

    const handleCloseCampaign = () => {
        setAnchorElCampaign(null);
    };

    const handleCampaignTypeClick = (type) => {
        setSelectedCampaignType(type);
        handleCloseCampaign();  // Close the popover after selecting a type
    };
    


  const filteredAccounts = data.filter(account =>
    account.descriptiveName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await INSTANCE.get("/campaign/get/list/connected");
        console.log(response.data.update_user);
        setData(response.data.update_user);

        // Set the first account from the response as the selected account
             // Set the first account from the response as the selected account
             if (response.data.update_user && response.data.update_user.length > 0) {
                setSelectedAccount(response.data.update_user[0]);
              }

      
      } catch (error) {
        console.error("Error fetching data: ", error);
      }
    };
    // Fetch data immediately upon mounting
    fetchData();

  }, []);

      sessionStorage.setItem('campaignType',selectedCampaignType)
      

    return (
        <>

<Box>
  <Heading heading="Automation" />
</Box>

<Divider style={{ width: '100%',marginTop:'20px',marginBottom:'20px' }}  />

<SideModel isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />


       <Box sx={{  padding: 2 }}>
            {/* Ad Account */}
            <Box sx={{  }}>
            {/* Ad Account */}
            <Box mb={3}>
            <Heading heading="Ad Account" />
                <div>
      <Button
        variant="outlined"
        onClick={handleClick}
        style={{
            backgroundColor: "#f2f2f2", // light gray background
        color: "#666",              // slightly dark text color
        borderColor: "#d9d9d9",     // light gray border color
        padding: "5px 20px",        // padding for button size
        borderRadius: "5px"        // rounded corners
    }}
      >
        {selectedAccount ? selectedAccount.descriptiveName : 'Select an Account'}
      </Button>

      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
        sx={{ p: 3 }}
      >
        <TextField
          placeholder="Search ad account"
          variant="outlined"
          fullWidth
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          sx={{ marginBottom: 1 }}
        />
        <List>
          {filteredAccounts.map(account => (
            <ListItem button key={account.account_id} onClick={() => handleAccountClick(account)}>
              {account.descriptiveName}
            </ListItem>
          ))}
        </List>
        <Button fullWidth onClick={toggleSidebar}>Connect ad account</Button>
      </Popover>
      <Divider style={{ width: '100%',marginTop:'40px',marginBottom:'40px' }}  />
    </div>
            </Box>
        </Box>

            {/* Campaign Type */}
            <Box mb={3}>
           
            <Heading heading=" Campaign type" />
            <Button  style={{
        backgroundColor: "#f2f2f2", // light gray background
        color: "#666",              // slightly dark text color
        borderColor: "#d9d9d9",     // light gray border color
        padding: "5px 20px",        // padding for button size
        borderRadius: "8px"        // rounded corners
    }}
         variant="outlined" onClick={handleClickCampaign}>
                {selectedCampaignType}
            </Button>
            <Popover
                open={Boolean(anchorElCampaign)}
                anchorEl={anchorElCampaign}
                onClose={handleCloseCampaign}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'center',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                
            >
                <List>
                    {campaignTypes.map(type => (
                        <ListItem
                            button
                            key={type}
                            onClick={() => handleCampaignTypeClick(type)}
                        >
                            {type}
                        </ListItem>
                    ))}
                </List>
            </Popover>






            <Divider style={{ width: '100%',marginTop:'40px',marginBottom:'40px' }}  />
           </Box>

            {/* Filter */}
            <Box >

               <FilterCampaign />
               
            </Box>
        </Box>


        

        <Divider style={{ width: '100%',marginTop:'20px',marginBottom:'40px' }}  />
        </>
    )
}

export default AddAccount;