import React, { useState,useEffect } from 'react';
import { Select, MenuItem, InputLabel, FormControl, TextField,Box,FormControlLabel,Checkbox,Tooltip } from '@mui/material';

import { InfoOutlined } from '@mui/icons-material';
import { Typography } from 'antd';

function BidStrategy() {

  const [strategy, setStrategy] = useState('Maximize clicks');
  const [maxCPC, setMaxCPC] = useState('');

  const [adLocation, setAdLocation] = useState('Anywhere on results page');
  const [impressionShare, setImpressionShare] = useState('');
  const [targetCPA, setTargetCPA] = useState('');
  const [checked, setChecked] = useState(true); 
  const [targetROAS, setTargetROAS] = useState('');


  function getCurrentStrategyValues() {
    switch(strategy) {
      case "Maximize clicks":
        return {
          strategy: strategy,
          maxCPC: maxCPC
        };
      case "Manual CPC":
        return {
          strategy: strategy,
          enhancedCPC: checked
        };
      case "Maximize conversions":
        return {
          strategy: strategy,
          targetCPA: targetCPA
        };
      case "Maximize conversion value":
        return {
          strategy: strategy,
          targetROAS: targetROAS
        };
      case "Target impression share":
        return {
          strategy: strategy,
          adLocation: adLocation,
          impressionShare: impressionShare,
          maxCPC: maxCPC
        };
      default:
        return {
          strategy: strategy
        };
    }
  }

  const values = getCurrentStrategyValues();
  console.log(values);


  return (
    <div style={{ padding: '20px', maxWidth: '100%' }}>
      <FormControl fullWidth variant="outlined">
      <Typography>Bid strategy</Typography>
        <Select
          labelId="strategy-label"
          value={strategy}
          onChange={(e) => setStrategy(e.target.value)}
         
        >
          <MenuItem value="Maximize clicks">Maximize clicks</MenuItem>
          <MenuItem value="Maximize conversions">Maximize conversions</MenuItem>
          <MenuItem  value="Maximize conversion value">Maximize conversion value</MenuItem>
          <MenuItem value="Manual CPC">Manual CPC</MenuItem>
          <MenuItem value="Viewable CPM">Viewable CPM</MenuItem>
          <MenuItem value="Target impression share">Target impression share</MenuItem>
          
          {/* Add other options if needed */}
        </Select>
      </FormControl>
   

{
    strategy === "Maximize clicks" &&   <div style={{ marginTop: '20px' }}>
        <TextField
          fullWidth
          variant="outlined"
          label="Max CPC bid"
          placeholder="Enter Max CPC bid value"
          value={maxCPC}
          onChange={(e) => setMaxCPC(e.target.value)}
          InputProps={{
            startAdornment: <span>$</span>,
          }}
        />
      </div>
}


{
    strategy ===  "Manual CPC" && <FormControlLabel
      control={
        <Checkbox
          checked={checked}
          onChange={(e) => setChecked(e.target.checked)}
          color="primary"
        />
      }
      label={
        <span>
          Enhanced CPC 
          <Tooltip title="More info about Enhanced CPC">
            <InfoOutlined style={{ marginLeft: '5px', cursor: 'pointer', verticalAlign: 'middle' }} />
          </Tooltip>
        </span>
      }
    />
}


{
    strategy === "Maximize conversions" &&  <Box sx={{mt:3,maxWidth: '100%' }}>
      {/* Target CPA input */}
      <TextField
        fullWidth
        variant="outlined"
        label="Target CPA"
        placeholder="Enter Target CPA value"
        value={targetCPA}
        onChange={(e) => setTargetCPA(e.target.value)}
        InputProps={{
          startAdornment: <span>R$</span>,
        }}
      />
    </Box>
}


{
    strategy === "Maximize conversion value" && <Box sx={{mt:3,  maxWidth: '100%' }}>
      {/* Target ROAS input */}
      <Typography>Target ROAS</Typography>
      <TextField
        fullWidth
        variant="outlined"
        placeholder="Enter Target ROAS value"
        value={targetROAS}
        onChange={(e) => setTargetROAS(e.target.value)}
        InputProps={{
          startAdornment: <span>%</span>,
        }}
      />
    </Box>
}






{
    strategy === "Target impression share" &&  <Box sx={{ mt:3, maxWidth: '100%' }}>
      {/* Ad location dropdown */}
      <FormControl fullWidth variant="outlined" sx={{ marginBottom: '20px' }}>
    <InputLabel id="ad-location-label">Ad location</InputLabel>
    <Select
      labelId="ad-location-label"
      value={adLocation}
      onChange={(e) => setAdLocation(e.target.value)}
      label="Ad location"
    >
      <MenuItem value="Anywhere on results page">
        Anywhere on results page
       
      </MenuItem>
      <MenuItem value="Top of results page">
        Top of results page
     
      </MenuItem>
      <MenuItem value="Absolute top of results page">
        Absolute top of results page
     
      </MenuItem>
    </Select>
</FormControl>

      {/* Impression share input */}
      <TextField
        fullWidth
        variant="outlined"
        label="(%) impression share to target"
        placeholder="Enter value"
        type="number"
        value={impressionShare}
        onChange={(e) => setImpressionShare(e.target.value)}
        InputProps={{
          startAdornment: <span>%</span>,
        }}
        sx={{ marginBottom: '20px' }}
        required
      />

      {/* Max CPC bid input */}
      <TextField
        fullWidth
        variant="outlined"
        label="Max CPC bid"
        placeholder="Enter Max CPC bid value"
        value={maxCPC}
        onChange={(e) => setMaxCPC(e.target.value)}
        InputProps={{
          startAdornment: <span>$</span>,
        }}
        required
      />
    </Box>

 }


     

    </div>



  );
}

export default BidStrategy;
