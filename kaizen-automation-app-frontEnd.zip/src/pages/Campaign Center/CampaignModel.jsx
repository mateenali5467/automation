import React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';

function CampaignModel() {
  const [open, setOpen] = React.useState(true); // You can set this to false initially

  return (
    <Dialog open={open}>
      <DialogTitle>talha sub account</DialogTitle>
      <DialogContent>
        <div>
          <Checkbox />
          <TextField placeholder="Search campaigns" />
          <Select defaultValue="All campaigns">
            <MenuItem value="All campaigns">All campaigns</MenuItem>
            {/* Add more MenuItems if needed */}
          </Select>
        </div>
        <div>Nothing found</div>
        <div>No entities selected</div>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => setOpen(false)}>Cancel</Button>
        <Button onClick={() => setOpen(false)}>Done</Button>
      </DialogActions>
    </Dialog>
  );
}

export default CampaignModel;
