
import { Box,FormGroup, FormControlLabel, Switch, Typography, Dialog, DialogActions, Button,DialogContent,DialogContentText,DialogTitle,Table, TableBody, TableCell, TableHead, TableRow, Paper,TextField,Select, MenuItem } from '@mui/material';

const ConfirmationDialog = ( { open, onDisconnect, onCancel })=>{
    return (
        <>
            <Dialog
          open={open}
          onClose={onCancel}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Disconnect Confirmation"}</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              Are you sure you want to disconnect this account?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={onCancel} color="primary">
              Cancel
            </Button>
            <Button onClick={onDisconnect} color="primary" autoFocus>
              Disconnect
            </Button>
          </DialogActions>
        </Dialog>
        </>
       )
  }
  
  export default ConfirmationDialog
 

 