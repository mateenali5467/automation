import React, { useState,useEffect } from 'react';
import { Button, Menu, MenuItem, Popover, List, ListItem, ListItemText, Typography, IconButton,RadioGroup,Radio,FormControlLabel,Chip,Box,Divider,ListItemIcon } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

import ArrowBackIcon from '@mui/icons-material/ArrowBack';

import CloseIcon from '@mui/icons-material/Close';

import CampaignModel from './CampaignModel';

import {INSTANCE} from "../../config/axiosInstance";

import Heading from 'components/common/Heading';

import CampaignIcon from '@mui/icons-material/Campaign';

import GroupsIcon from '@mui/icons-material/Groups';

import BorderAllIcon from '@mui/icons-material/BorderAll';

import KeyboardIcon from '@mui/icons-material/Keyboard';


function FilterCampaign() {


  const getCampaignType = sessionStorage.getItem('campaignType');

  const allMenuItems = [
    { label: 'Ad account', icon: <AddIcon /> },
    { label: 'Campaigns', icon: <CampaignIcon /> },
    { label: 'Ad groups', icon: <GroupsIcon /> },
    { label: 'Ads', icon: <BorderAllIcon /> },
    { label: 'Keywords', icon: <KeyboardIcon /> }
  ];

  const filteredMenuItems = (getCampaignType === 'App' || getCampaignType === 'Performance Max') 
    ? allMenuItems.filter(item => item.label === 'Campaigns')
    : allMenuItems;



    const [anchorEl, setAnchorEl] = useState(null);
    const [popoverEl, setPopoverEl] = useState(null);
    const [selectedValue, setSelectedValue] = useState('Ad account'); 
    const [popoverItemValue, setPopoverItemValue] = useState(''); // For storing the value clicked within popover
    
    const [selectedFilter, setSelectedFilter] = useState('Contains');
 
    const [filters, setFilters] = useState([]);

    const [showLength,setShowLength] = useState(false);
    const [currentLength,setCurrentLength] = useState('')

  // Dropdown handlers
  const handleClickDropdown = (event) => {
    setAnchorEl(event.currentTarget);
    setPopoverItemValue('')
  };

  const handleDropdownClose = () => {
    setAnchorEl(null);
  };

  const handleMenuItemClick = (value) => {
    setSelectedValue(value); 
    setAnchorEl(null); 
  };

  // Popover handlers
  const handleClickPopover = (event) => {
    setPopoverEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setPopoverEl(null);
  };

  const handlePopoverItemClick = (value) => {
    setPopoverItemValue(value);
    console.log(value); // log the selected value to console
    // handlePopoverClose(); // You can close the popover after selectinged
  };

  const handleFilterChange = (event) => {
    setSelectedFilter(event.target.value);
  };
 

  const addFilter = () => {
      setFilters([...filters, `${popoverItemValue} ${selectedFilter} ${campaignName}`]);
      setPopoverItemValue('');  // Clear the input
      setPopoverEl(null);
    
  };


  const removeFilter = (filterToRemove) => {
    setFilters(filters.filter(filter => filter !== filterToRemove));
  };


  const [statusCondition, setStatusCondition] = useState('is');
  const [campaignStatus, setCampaignStatus] = useState('Active');

  const [campaignName, setCampaignName] = useState("");

  const handleCampaignNameChange = (event) => {
    setCampaignName(event.target.value);
  };


  const handleStatusConditionChange = (event) => {
    setStatusCondition(event.target.value);
  };

  const handleCampaignStatusChange = (event) => {
    setCampaignStatus(event.target.value);
  };

  const applyFilter = () => {
    console.log(`Campaign status ${statusCondition} ${campaignStatus}`);

  };

  const [condition, setCondition] = useState('is');
  const [status, setStatus] = useState('Active');
  const [appliedFilters, setAppliedFilters] = useState([]);

  const handleConditionChange = (event) => {
    setCondition(event.target.value);
  };

  const handleStatusChange = (event) => {
    setStatus(event.target.value);
  };

  const addFilterCon = () => {
    const filter = `${popoverItemValue} ${condition} ${status}`;
    if (!appliedFilters.includes(filter)) {
      setAppliedFilters(prevFilters => [...prevFilters, filter]);
    }
    setPopoverEl(null);
    setPopoverItemValue('')
  };


  const deleteFilter = (filterToRemove) => {
    setAppliedFilters(prevFilters => prevFilters.filter(filter => filter !== filterToRemove));
  };

  let accountIdFinal;
  const getSelectedAccount = sessionStorage.getItem('selectedAccount');
  const selectedAccoutCurrentParse = JSON.parse(getSelectedAccount);
  const accountId = selectedAccoutCurrentParse;
  
  if (typeof accountId.account_id === 'number') {
    accountIdFinal = accountId.account_id;
  }
  

  function setContainsStatus(str) {

    let result = {
       "currentFilter" : selectedValue,
      "status": "",
      "contains": true,
      "type": "search",
      "campaign_text": campaignName
  }
  
    if (str.includes('Contains')) {
      result.contains = true;
    } 
    else if (str.includes("Doesn't contain")) {
      result.contains = false;
    }
  
    return result;
}


  const results = filters.map(setContainsStatus);

  const getCurrentCampaign = results[results.length-1];

  console.log("outSide APIIIIII.............",getCurrentCampaign);

  const apiGetCampaign = async ()=>{

    console.log("insideAPII.............",getCurrentCampaign);

    try{
      
      const res = await INSTANCE.post("/campaign/fetch/revealbot/campaigns/" + 74, 
         getCurrentCampaign
      );
      console.log("getCampaign",getCurrentCampaign);
      setShowLength(true);
      setCurrentLength(res.data.length)
      console.log("getCampaign",res.data.length);
      
    }
    catch(error){
      console.log(error)
    }

  }


   // Use useEffect to call the API when filters change
   useEffect(() => {
    if (filters.length > 0) {
      apiGetCampaign();
    }
  }, [filters]);



  console.log(getCampaignType)


  return (
    <>
   
   <Heading heading="Filter" />
   
   <Heading heading="Apply rule to campaigns, ad groups, ads, or keywords" variant="p" className="text " />


      <div style={{ display: 'flex', alignItems: 'center' }}>
      <Button
    aria-controls="campaign-menu"
    aria-haspopup="true"
    variant="outlined"
    onClick={handleClickDropdown}
    style={{
        backgroundColor: "#f2f2f2", // light gray background
        color: "#666",              // slightly dark text color
        borderColor: "#d9d9d9",     // light gray border color
        padding: "5px 20px",        // padding for button size
        borderRadius: "8px"        // rounded corners
    }}
>
    {selectedValue}
</Button>


{
  selectedValue !== "Ad account" &&  <IconButton color="primary" onClick={handleClickPopover}>
          <AddIcon />
        </IconButton>
        
}
       
<Menu
      id="campaign-menu"
      anchorEl={anchorEl}
      open={Boolean(anchorEl)}
      onClose={handleDropdownClose}
    >
      {filteredMenuItems.map(({ label, icon }) => (
        <MenuItem key={label} onClick={() => handleMenuItemClick(label)}>
          <ListItemIcon>
            {icon}
          </ListItemIcon>
          <Typography variant="body1">{label}</Typography>
        </MenuItem>
      ))}
    </Menu>


        <Popover
          open={Boolean(popoverEl)}
          anchorEl={popoverEl}
          onClose={handlePopoverClose}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
          transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        >
         {
            popoverItemValue === '' && (
                <>
                <List style={{ maxHeight: '300px', overflow: 'auto' }}>

        <ListItem>
          <ListItemText primary={<Typography variant="body2">ITEMS</Typography>} />
        </ListItem>
        <ListItem button onClick={() => handlePopoverItemClick('Specific items')}>
          <ListItemText primary={<Typography variant="body2">Specific items</Typography>} />
        </ListItem>

        <ListItem>
          <ListItemText primary={<Typography variant="body2">NAME</Typography>} />
        </ListItem>
        <ListItem button onClick={() => handlePopoverItemClick('Campaign name')}>
          <ListItemText primary={<Typography variant="body2">Campaign name</Typography>} />
        </ListItem>
        {(selectedValue === 'Ad groups' || selectedValue === 'Ads' || selectedValue === "Keywords") && (
        <ListItem button onClick={() => handlePopoverItemClick('Ad group name')} >
        <ListItemText primary={<Typography variant="body2">Ad group name</Typography>} />
        </ListItem>
        )}

 <ListItem>
   <ListItemText primary={<Typography variant="body2">STATUS</Typography>} />
 </ListItem>
 <ListItem button onClick={() => handlePopoverItemClick('Campaign status')}> 
   <ListItemText primary={<Typography variant="body2">Campaign status</Typography>} />
 </ListItem>
 {(selectedValue === 'Ad groups' || selectedValue === 'Ads' || selectedValue === "Keywords") && (
   <ListItem button onClick={() => handlePopoverItemClick('Ad group status')}>
     <ListItemText primary={<Typography variant="body2">Ad group status</Typography>} />
   </ListItem>
 )}

 {selectedValue === 'Ads' && (
   <ListItem button onClick={() => handlePopoverItemClick('Ad status')}>
     <ListItemText primary={<Typography variant="body2">Ad status</Typography>} />
   </ListItem>
 )}

{
selectedValue === 'Keywords' && (
<>
<ListItem>
   <ListItemText primary={<Typography variant="body2">Text</Typography>} />
 </ListItem>


   <ListItem button>
     <ListItemText primary={<Typography variant="body2">Keywords</Typography>} />
   </ListItem>

</>
)
}


     </List>
                </>
            )
         }


{
  (popoverItemValue === 'Specific items') && <>
     {/* <CampaignModel /> */}
     <div>
      SAsa
     </div>
  </>
}

{
    (popoverItemValue === 'Campaign name' || popoverItemValue === 'Ad group name' ) && (
        <>

        <div style={{ padding: 15, width: 300, border: '1px solid #e0e0e0', borderRadius: 5 }}>
        

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center',marginBottom:'15px' }}>
      <IconButton 
       onClick={()=>setPopoverItemValue('')} 
        size="small" 
        style={{ position: 'absolute', left: 0 }}
      >
        <ArrowBackIcon />
      </IconButton>
      
      <Typography variant="p">{popoverItemValue}</Typography>
    </div>

     <Box my={2}> 
     <Divider />
     </Box>



      <Box>
        <RadioGroup
          aria-label="filter"
          name="filter"
          value={selectedFilter}
          onChange={handleFilterChange}
          style={{ marginBottom: 10 }}
        >
          <FormControlLabel value="Contains" control={<Radio />} label="Contains" />
          <FormControlLabel value="Doesn't contain" control={<Radio />} label="Doesn't contain" />
        </RadioGroup>
        <div>
        <input 
        type="text" 
        placeholder="Campaign name" 
        value={campaignName}
        onChange={handleCampaignNameChange}
        style={{ width: '100%', padding: 10, marginBottom: 10 }}  
      />
             <Button onClick={addFilter} variant="contained" color="primary" style={{ width: '100%',marginTop:"10px" }}>
            Add filter
          </Button>
        </div>
      </Box>

    </div>
</>
    )
}

{
    (popoverItemValue === 'Campaign status' || popoverItemValue === 'Ad group status' || popoverItemValue === "Ad status" ) && (
        <>
        <Box p={2} width="300px">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center',marginBottom:'15px' }}>
      <IconButton 
       onClick={()=>setPopoverItemValue('')} 
        size="small" 
        style={{ position: 'absolute', left: 0 }}
      >
        <ArrowBackIcon />
      </IconButton>
      
      <Typography variant="p">{popoverItemValue}</Typography>
    </div>

     <Divider />


     <Box mb={2} mt={2} display="flex" alignItems="center" justifyContent="center">
      <RadioGroup 
        value={condition} 
        onChange={handleConditionChange} 
        row 
        sx={{ fontSize: 'small' }} // Adjusts the size of the content
      >

        <FormControlLabel 
          value="is" 
          control={<Radio size="small" />} // Small radio button
          label="is" // Lowercase label
          labelPlacement="start"
        />
        
        <FormControlLabel 
          value="is not" 
          control={<Radio size="small" />} // Small radio button
          label="is not" // Lowercase label
          labelPlacement="start"
        />

      </RadioGroup>

    </Box>

  <Divider />    

     <Box my={2}>
      <RadioGroup  value={status} onChange={handleStatusChange}>
          <FormControlLabel value="Active" control={<Radio />} label="Active" />
          <FormControlLabel value="Paused" control={<Radio />} label="Paused" />
        </RadioGroup>
     </Box>

      <Button variant="contained" color="primary" fullWidth onClick={addFilterCon}>
        Add filter
      </Button>

   
    </Box>
          

        </>
    )
}
  
          
        </Popover>

        
      </div>


      
      {/* SHOW SELECRED FILTER */}
      <Box display="flex" flexWrap="wrap" width={600}>

      {filters.map(filter => (
        <Chip
          label={filter}
          onDelete={() => removeFilter(filter)}
          deleteIcon={<CloseIcon />}
          style={{ margin: 5 }}
        />
      ))}

      {appliedFilters.map(filter => (
          <Chip
            key={filter}
            label={filter}
            onDelete={() => deleteFilter(filter)}
            deleteIcon={<CloseIcon />}
            style={{ margin: 5 }}
          />
        ))}


        <br />
        <br />
     


      </Box>
      {/* SHOW SELECRED FILTER */}


      {
     (showLength && filters.length > 0 )&& 
       <p style={{marginTop: '5px', fontSize: '12px', whiteSpace: 'pre-line'}}>
        Estimated match: {currentLength} {selectedValue}
       </p>
     }



    </>
  );
}

export default FilterCampaign;
