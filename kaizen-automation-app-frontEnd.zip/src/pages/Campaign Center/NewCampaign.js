import React, { useState, useEffect } from "react";
import DesktopDrawer from "../../components/Layout/Drawer/DesktopDrawer";
import BreadCrums from "../../components/common/BreadCrums";
import Heading from "components/common/Heading";
import { useSelector } from "react-redux";
import CircularProgress from '@mui/material/CircularProgress';
import ConnectAccount from "../../components/ConnectAccount/ConnectAccount";
import GoogleAdManager from "components/Google/GoogleAds";
import { INSTANCE } from "../../config/axiosInstance";
import { Box } from '@mui/material';

const NewCampaign = () => {

  const { currentTabSlices, campaignSlices, splitTestSplice } = useSelector(res => res);
  
  const [isConnected, setIsConnected] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000); 

    return () => clearTimeout(timer);
  }, []);



  useEffect(() => {
    const fetchData = async () => {
        try {
            const response = await INSTANCE.get("/user/connected-accounts");
            localStorage.setItem("connectedAccounts", JSON.stringify(response.data.data));
            setIsConnected(response.data.data?.connected_accounts?.google_connected);
        } catch (error) {
            // handle error
        }
    }

    fetchData();
}, []);

useEffect(() => {
  console.log("NewCampaign has re-rendered. isConnected:", isConnected);
});

  return (
    <>
      <DesktopDrawer>
        {isLoading ? (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress />
            </div>
        ) : (
            <>
                <BreadCrums heading="Campaign Center" />
                {isConnected === 0 ? (
                    <>
                        <Heading heading={`Select your Ad Network`} />
                        <ConnectAccount />
                    </>
                ) : isConnected === 1 ? (
                    <Box sx={{
                        boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
                        backgroundColor: 'white',
                        borderRadius: '8px',
                        padding: '16px'
                    }}>
                        <GoogleAdManager />
                    </Box>
                ) : null}
            </>
        )}
    </DesktopDrawer>
    </>
  );
};

export default NewCampaign;
