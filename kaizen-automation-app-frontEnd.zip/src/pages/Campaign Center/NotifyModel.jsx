

import { useEffect, useState } from 'react';
import {
  List, ListItem, ListItemText, ListItemIcon, Box,
  Typography, Button,Menu,MenuItem,
  Checkbox,
  FormControl,
  FormControlLabel,
  InputLabel,
  InputAdornment,
  OutlinedInput,
  Select,
  Grid,
  Tooltip, IconButton,
  TextField

} from '@mui/material';

import PlayArrowIcon from '@mui/icons-material/PlayArrow'; 
import PauseIcon from '@mui/icons-material/Pause'; 
import NotificationsIcon from '@mui/icons-material/Notifications';
import SettingsIcon from '@mui/icons-material/Settings';
import ArrowOutwardIcon from '@mui/icons-material/ArrowOutward';
import CallReceivedIcon from '@mui/icons-material/CallReceived';
import VerticalAlignTopIcon from '@mui/icons-material/VerticalAlignTop';
import InfoIcon from '@mui/icons-material/Info';

import BidStrategy from './BidStrategy';


import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';


const strategies = [
    "Maximize clicks",
    "Maximize conversions",
    "Maximize conversion value",
    "Manual CPC",
    "Viewable CPM",
    "Target impression share",
  ];

function NotifyModel ({ open, onClose }) {


  const [openModel,setOpenModel] = useState(open)

  const [selected, setSelected] = useState('start');

  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedValue, setSelectedValue] = useState('Once a day');

  const [amount, setAmount] = useState(10);
  const [unit, setUnit] = useState('%');
  const [isActive, setIsActive] = useState(true);

  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');

  const [text, setText] = useState('#reveal');
  
  const getDetailsBySelection = (selection) => {
    switch (selection) {
        case 'start': return { icon: <PlayArrowIcon color="primary" />, heading: 'Start' };
        case 'pause': return { icon: <PauseIcon color="primary" />, heading: 'Pause' };
        case 'notify': return { icon: <NotificationsIcon color="primary" />, heading: 'Notify' };
        case 'increase': return { icon: <ArrowOutwardIcon color="primary" />, heading: 'Increase budget' };
        case 'decrease': return { icon: <CallReceivedIcon color="primary" />, heading: 'Decrease budget' };
        case 'set': return { icon: <VerticalAlignTopIcon color="primary" />, heading: 'Set budget' };
        case 'bid': return { icon: <SettingsIcon color="primary" />, heading: 'Set bid strategy' }; // Added this line for bid selection
        // ... add other cases as needed  case 'bid': return { icon: <SettingsIcon color="primary" />, heading: 'Set bid strategy' };
        case 'add': return { icon: <VerticalAlignTopIcon color="primary" />, heading: 'Add to name' };
        case 'remove': return { icon: <VerticalAlignTopIcon color="primary" />, heading: 'Remove from name' };
        case 'replace': return { icon: <VerticalAlignTopIcon color="primary" />, heading: 'Replace text in name' };
        default: return { icon: null, heading: '' };

        
    }
}

const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (value) => {
    if (value) {
      setSelectedValue(value);
    }
    setAnchorEl(null);
  };


  const handleSave = () => {

    let logObject = {
      SelectedTab: selected,
      SelectedValue: selectedValue,
      Amount: amount,
      Unit: unit,
      IsActive: isActive,
      textField: text,
      findText: findText, // Assuming you have a state named findText for this
       replaceText: replaceText // Assuming you have a state named replaceText 
    };
  
    // switch (selected) {
    //   case "add":
    //   case "remove":
    //     logObject = {
    //       textField: text // Assuming you have a state named textFieldValue for this
    //     };
    //     break;
  
    //   case "replace":
    //     logObject = {
    //       findText: findText, // Assuming you have a state named findText for this
    //       replaceText: replaceText // Assuming you have a state named replaceText for this
    //     };
    //     break;
  
    //   case "bid":
    //   case "start":
    //   case "pause":
    //   case "notify":
    //     delete logObject.Amount;
    //     delete logObject.Unit;
    //     delete logObject.IsActive;
    //     break;
  
    //   default:
    //     break;
    // }
  
    console.log(logObject);

    localStorage.setItem('settingModel',JSON.stringify(logObject));
    setOpenModel(false)
    onClose()
  };
  

  const { icon, heading } = getDetailsBySelection(selected);


  const handleCloseF = () => {
    setOpenModel(false);
  };
  
  useEffect(()=>{
    setOpenModel(open);
  },[open])

  

  const listItemStyle = {
    padding: '8px 16px'  // Adjust these values as needed
  };
  
  const iconStyle = {
    marginRight: '8px'  // Adjust this value as needed
  };

  return (

    <>


    

     <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
            <DialogTitle>Notification Settings</DialogTitle>
            <DialogContent>
            <Box display="flex" mb={15} >
    <Box width={240} borderRight="1px solid lightgray">

        <Box>
            <input type="search" placeholder="Search" style={{ width: '80%', padding: '6px', borderRadius: '4px' }} />
        </Box>

     <Box>
     
     </Box>

        <List component="nav" style={{ padding: 0 }}>

          <ListItem button disabled>
                 <ListItemText primary="General" />
            </ListItem>


            <ListItem button selected={selected === 'start'} onClick={() => setSelected('start')}>
    <ListItemIcon><PlayArrowIcon /></ListItemIcon>
    <ListItemText primary="Start" />
  </ListItem>
  
            <ListItem button selected={selected === 'pause'} onClick={() => setSelected('pause')}>
                <ListItemIcon><PauseIcon /></ListItemIcon>
                <ListItemText primary="Pause" />
            </ListItem>
            <ListItem button selected={selected === 'notify'} onClick={() => setSelected('notify')}>
                <ListItemIcon><NotificationsIcon /></ListItemIcon>
                <ListItemText primary="Notify" />
            </ListItem>
          
            <ListItem button disabled>
                <ListItemText primary="Budget" />
            </ListItem>
            <ListItem button selected={selected === 'increase'} onClick={() => setSelected('increase')}>
                <ListItemIcon><ArrowOutwardIcon /></ListItemIcon>
                <ListItemText primary="Increase budget" />
            </ListItem>
            <ListItem button selected={selected === 'decrease'} onClick={() => setSelected('decrease')}>
                <ListItemIcon><CallReceivedIcon /></ListItemIcon>
                <ListItemText primary="Decrease budget" />
            </ListItem>
            <ListItem button selected={selected === 'set'} onClick={() => setSelected('set')}>
                <ListItemIcon><VerticalAlignTopIcon /></ListItemIcon>
                <ListItemText primary="Set budget" />
            </ListItem>
            
            <ListItem button disabled>
                 <ListItemText primary="Bid" />
            </ListItem>

            <ListItem button selected={selected === 'bid'} onClick={() => setSelected('bid')}>
            <ListItemIcon><VerticalAlignTopIcon /></ListItemIcon>
                <ListItemText primary="Set bid strategy" />
            </ListItem>
          
            <ListItem button disabled>
                <ListItemText primary="Name/Text" />
            </ListItem>
            <ListItem button selected={selected === 'add'}  onClick={() => setSelected('add')}>
            <ListItemIcon><VerticalAlignTopIcon /></ListItemIcon>
            <ListItemText primary="Add to name" />
          </ListItem>
          <ListItem button selected={selected === 'remove'} onClick={() => setSelected('remove')}>
            <ListItemIcon><VerticalAlignTopIcon /></ListItemIcon>
            <ListItemText primary="Remove from name" />
          </ListItem>
          <ListItem button selected={selected === 'replace'} onClick={() => setSelected('replace')}>
            <ListItemIcon><VerticalAlignTopIcon /></ListItemIcon>
            <ListItemText primary="Replace text in name" />
          </ListItem>
            {/* Add more list items as required */}
        </List>
    </Box>

    

    <Box flexGrow={1} p={2}  display="flex" flexDirection="column">
  {/* Header: Icon and Heading */}
  <Box display="flex" alignItems="center" mb={2}>
    {icon}
    <Typography variant="h5" style={{ marginLeft: 10 }}>
      {heading}
    </Typography>
  </Box>

  <Box mb={2}>
  {
    ( selected === 'notify' || selected === 'increase' || selected === 'decrease' || selected === 'set' ) &&    <div>
      <Button variant="outlined" onClick={handleClick}>
        {selectedValue}
      </Button>
      <Menu
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={() => handleClose()}
      >
        <MenuItem onClick={() => handleClose('Every 15 minutes')}>Every 15 minutes</MenuItem>
        <MenuItem onClick={() => handleClose('Every 30 minutes')}>Every 30 minutes</MenuItem>
        <MenuItem onClick={() => handleClose('Every 1 hour')}>Every 1 hour</MenuItem>
        <MenuItem onClick={() => handleClose('Every 2 hours')}>Every 2 hours</MenuItem>
        <MenuItem onClick={() => handleClose('Every 3 hours')}>Every 3 hours</MenuItem>
        <MenuItem onClick={() => handleClose('Every 4 hours')}>Every 4 hours</MenuItem>
      </Menu>
    </div>
}


  </Box>
 

  
 
  {/* Content Wrapper */}

  {
    (selected === 'increase' || selected === 'decrease' )  && <Box width={300} padding={2}>
      <Typography variant="subtitle1" gutterBottom>
       {selected} By
      </Typography>
      <Grid container spacing={1} alignItems="center">
        <Grid item xs>
          <FormControl variant="outlined" size="small" fullWidth>
            <OutlinedInput
              id="increase-by-input"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </FormControl>
        </Grid>
        <Grid item>
          <FormControl variant="outlined" size="small">
            <Select
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
            >
              <MenuItem value={'Rs'}>Rs</MenuItem>
              <MenuItem value={'%'}>%</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>
      <Box mt={2} display="flex" alignItems="center">
        <Checkbox
          checked={isActive}
          onChange={(e) => setIsActive(e.target.checked)}
          color="primary"
        />
        <Typography variant="body2" display="flex" alignItems="center">
          For active campaigns only
           <InfoIcon fontSize="small" style={{ marginLeft: 4}} />
        </Typography>
      </Box>
    </Box>
  }

  {
    (selected === 'set'  )  && <Box width={300} padding={2}>
      <Typography variant="subtitle1" gutterBottom>
      Set to value
      </Typography>
      <Grid container spacing={1} alignItems="center">
        <Grid item xs>
          <FormControl variant="outlined" size="small" fullWidth>
            <OutlinedInput
              id="increase-by-input"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </FormControl>
        </Grid>
     
      </Grid>
      <Box mt={2} display="flex" alignItems="center">
        <Checkbox
          checked={isActive}
          onChange={(e) => setIsActive(e.target.checked)}
          color="primary"
        />
        <Typography variant="body2" display="flex" alignItems="center">
          For active campaigns only
           <InfoIcon fontSize="small" style={{ marginLeft: 4}} />
        </Typography>
      </Box>
    </Box>
  }

    {
        (selected === 'bid'  )  &&  <BidStrategy />
    }


{
  selected === 'add' && 
  <Box >
  <Box sx={{  padding: '20px' }}>
            <Typography variant="h6" gutterBottom>
                Text
            </Typography>
            <TextField
                fullWidth
                variant="outlined"
                value={text}
                onChange={(e) => setText(e.target.value)}
            />
        </Box>
  </Box>
}

{
  selected === 'remove' && 
  <Box width={300} >
  <Box sx={{ width: '300px', padding: '20px' }}>
            <Typography variant="h6" gutterBottom>
                Text
            </Typography>
            <TextField
                fullWidth
                variant="outlined"
                value={text}
                onChange={(e) => setText(e.target.value)}
            />
        </Box>
  </Box>
}


{
  selected === 'replace' && 
  <Box >
  <Box sx={{  padding: '20px' }}>
            <Typography variant="h6" gutterBottom>
                Find
            </Typography>
            <TextField
                fullWidth
                variant="outlined"
                value={findText}
                onChange={(e) => setFindText(e.target.value)}
                placeholder="#reveal"
            />
            <Typography variant="h6" gutterBottom style={{ marginTop: '20px' }}>
                Replace with
            </Typography>
            <TextField
                fullWidth
                variant="outlined"
                value={replaceText}
                onChange={(e) => setReplaceText(e.target.value)}
                placeholder="#bot"
            />
        </Box>
  </Box>
}


  <Box flex="1" display="flex" flexDirection="column" justifyContent="center" alignItems="center">

    {selected === 'pause' && <Typography variant="body1">The action has no settings.</Typography>}
    {selected === 'start' && <Typography variant="body1">The action has no settings.</Typography>}
    {selected === 'notify' && <Typography variant="body1">The action has no settings.</Typography>}

  </Box>

  {/* "Cancel" and "Save" buttons */}
  {/* <Box display="flex" justifyContent="flex-end" mt={2}>
      <Button color="inherit" style={{ marginRight: 10 }}>Cancel</Button>
      <Button color="primary" variant="contained" onClick={handleSave}>Save</Button>
    </Box> */}

</Box>

</Box>

            </DialogContent>
            <DialogActions>
                <Button color="inherit" onClick={onClose}>Cancel</Button>
                <Button color="primary" variant="contained" onClick={handleSave}>Save</Button>
            </DialogActions>
        </Dialog>

    

    </>

  

  );
}

export default NotifyModel;