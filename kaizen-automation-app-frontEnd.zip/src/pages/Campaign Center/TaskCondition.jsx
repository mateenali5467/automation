import "./Task.css";

import React, { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Select,
  MenuItem,
  Box,
  Grid,
  Card,
  CardContent,
  IconButton,
  InputAdornment,
  FormControlLabel,
  Checkbox,
  FormControl,
  InputLabel,
  ListItemText,
  Divider
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import SettingsIcon from "@mui/icons-material/Settings";
import ContentCopyIcon from '@mui/icons-material/ContentCopy';

import NotifyModel from "./NotifyModel";

import { TreeSelect } from 'antd';

import PlayArrowIcon from '@mui/icons-material/PlayArrow'; 
import PauseIcon from '@mui/icons-material/Pause'; 
import NotificationsIcon from '@mui/icons-material/Notifications';
import ArrowOutwardIcon from '@mui/icons-material/ArrowOutward';
import CallReceivedIcon from '@mui/icons-material/CallReceived';
import VerticalAlignTopIcon from '@mui/icons-material/VerticalAlignTop';
import InfoIcon from '@mui/icons-material/Info';

import treeData from './treeData.json';

import Heading from "components/common/Heading";

const treeDataCompare = [
  {
    title: 'GREATER THAN',
    value: '>',
  },
  {
    title: 'Node2',
    value: '0-1',
  },
];


const ConditionForm = () => {

  const initialCondition = {
    type: "General",
    time: "Today",
    comparator: ">",
    value: "Rs0",
  };

  const timeOptions = [
    "Today",
    "Yesterday",
    "Today and yesterday",
    "Last 3 days",
    "Last 3 days (Incl. today)",
    "Last 7 days",
    "Last 7 days (Incl. today)",
    "Last 14 days",
    "Last 14 days (Incl. today)",
    "Last 30 days",
    "Last 30 days (Incl. today)",
    "This week (Sun to Today)",
    "This week (Mon to Today)",
    "Last week (Sun to Sat)",
    "Last week (Mon to Sun)",
    "Last business week",
    "This month",
    "Last month",
    "All time",
  ];

  const comparatorOptions = {
    "GREATER THAN": ">",
    "SMALLER THAN": "<",
    "LARGEST": "≥",
    "SMALL": "≤",
    "EQUALS": "=",
    "DOES NOT EQUAL": "≠",
  };
  
  const timeZones = [
    "GMT (-12:00) International Date Line West",
    "GMT (-11:00) American Samoa",
    "GMT (-11:00) Midway Island",
    "GMT (-10:00) Hawaii",
    "GMT (-08:00) Alaska",
    "GMT (-07:00) Pacific Time (US & Canada)",
    "GMT (-07:00) Tijuana",
    "GMT (-07:00) Arizona",
    "GMT (-07:00) Mazatlan",
    "GMT (-06:00) Mountain Time (US & Canada)",
    "GMT (-06:00) Central America",
    "GMT (-05:00) Central Time (US & Canada)",
    "GMT (-06:00) Chihuahua",
    "GMT (-06:00) Mexico City",
    "GMT (-06:00) Monterrey",
    "GMT (-06:00) Saskatchewan",
    "GMT (-05:00) Bogota",
    "GMT (-04:00) Eastern Time (US & Canada)",
    "GMT (-04:00) Indiana (East)",
    "GMT (-05:00) Quito",
    "GMT (-03:00) Atlantic Time (Canada)",
    "GMT (-04:00) Caracas",
    "GMT (-04:00) Georgetown",
    "GMT (-04:00) La Paz",
    "GMT (-04:00) Puerto Rico",
    "GMT (-03:00) Santiago",
    "GMT (-02:30) Newfoundland",
    "GMT (-03:00) Brasilia",
    "GMT (-03:00) Buenos Aires",
    "GMT (-03:00) Greenland",
    "GMT (-03:00) Montevideo",
    "GMT (-02:00) Mid-Atlantic",
    "GMT (-01:00) Azores",
    "GMT (-01:00) Cape Verde Is.",
    "GMT (+00:00) London",
    "GMT (+00:00) Lisbon",
    "GMT (+00:00) Monrovia",
    "GMT (+00:00) UTC",
    "GMT (+01:00) Amsterdam",
    "GMT (+01:00) Belgrade",
    "GMT (+01:00) Berlin",
    "GMT (+01:00) Zurich",
    "GMT (+01:00) Bratislava",
    "GMT (+01:00) Brussels",
    "GMT (+01:00) Budapest",
    "GMT (+01:00) Casablanca",
    "GMT (+01:00) Copenhagen",
    "GMT (+00:00) Dublin"
  ];
  
  const treeDataCountryZone = timeZones.map(zone => ({
    title: zone,
    value: zone
  }));
  


  const treeDataTimeZone = timeOptions.map(option => ({
    title: option,
    value: option,
  }));


  const [conditions, setConditions] = useState([initialCondition]);
  const [operator, setOperator] = useState("OR");
  const [hoverIndex, setHoverIndex] = useState(null);

  const [isModalOpen, setIsModalOpen] = useState(false);

  const [value, setValue] = useState();
  const [valueTimeTwo,setValueTimeTwo] = useState()
  
  const [valueTimeZone, setValueTimeZone] = useState();

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  // State to hold the selected days
  const [selectedDays, setSelectedDays] = useState(daysOfWeek);

  const handleDayChange = (event) => {
    setSelectedDays(event.target.value);
  };

  const [checked, setChecked] = useState({
    Sunday: true,
    Monday: true,
    Tuesday: true,
    Wednesday: true,
    Thursday: true,
    Friday: true,
    Saturday: true
  });
  
   // Handle change event
   const handleChange = (event) => {
    console.log("sdad",event.target.checked)
    console.log("sdad",event.target.name)
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };
  
  const [isHovered, setIsHovered] = useState(false);

  const onChange = (newValue, conditionIndex) => {
    setConditions(prevConditions => {
      const newConditions = [...prevConditions];
      newConditions[conditionIndex] = { ...newConditions[conditionIndex], 
        selectedType: newValue };
      return newConditions;
    });

    console.log("onChange",newValue)
  };
  
  const onChangeTimeTwo = (newValue, conditionIndex) => {
    setConditions(prevConditions => {
      const newConditions = [...prevConditions];
      newConditions[conditionIndex] = { ...newConditions[conditionIndex], selectedTimeZone: newValue };
      return newConditions;
    });

    console.log("onChangeTimeTwo",newValue)
  };


  const  onChangeTimeCountryZone = (newValue, conditionIndex) => {
    setConditions(prevConditions => {
      const newConditions = [...prevConditions];
      newConditions[conditionIndex] = { ...newConditions[conditionIndex], selectedCountryZone: newValue };
      return newConditions;
    });

    console.log("onChangeTimeCountryZone",newValue)
  };




  const onChangeTimeZone = (newValue, conditionIndex) => {
    setConditions(prevConditions => {
      const newConditions = [...prevConditions];
      newConditions[conditionIndex] = { ...newConditions[conditionIndex], selectedTimeZone: newValue };
      return newConditions;
    });

    console.log("onCHnageTuimeXOze",newValue)
  };
  


  const getComparatorsForType = (type) => {
    switch (type) {
      case "General":
        return ["GREATER THAN", "SMALLER THAN", "LARGEST", "SMALL"];
      default:
        return [">"];
    }
  };

  const addCondition = () => {
    const newCondition = { ...initialCondition };
    setConditions(prevConditions => [...prevConditions, newCondition]);
  };



  const toggleOperator = () => {
    setOperator(operator === "OR" ? "AND" : "OR");
  };

  const deleteCondition = (conditionIndex) => {
    if (conditions.length > 1) {
      // Ensure there are more than one condition before deleting
      const newConditions = [...conditions];
      newConditions.splice(conditionIndex, 1);
      setConditions(newConditions);
    }
  };
  // const handleTypeChange = (event, conditionIndex) => {
  //   const newConditions = [...conditions];
  //   newConditions[conditionIndex].type = event.target.value;
  //   newConditions[conditionIndex].comparator = getComparatorsForType(
  //     event.target.value
  //   )[0];
  //   setConditions(newConditions);
  // };

const handleComparatorChange = (event, conditionIndex) => {
  setConditions(prevConditions => {
    // Clone the array and the object to avoid direct mutation
    const newConditions = [...prevConditions];
    newConditions[conditionIndex] = { ...newConditions[conditionIndex], comparator: event.target.value };
    return newConditions;
  });
};

  const handleModalOpen = () => {
    setIsModalOpen(true);
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
  };


  // const handleTimeChange = (event, conditionIndex) => {
  //   const newConditions = [...conditions];
  //   newConditions[conditionIndex].time = event.target.value;
  //   setConditions(newConditions);
  // };
  


  const generateTimeOptions = () => {
    const options = [];
    for (let i = 0; i < 24; i++) {
      const hour = i === 0 ? 12 : (i > 12 ? i - 12 : i);
      const suffix = i >= 12 ? 'PM' : 'AM';
      const label = `${hour}:00 ${suffix}`;
      options.push({ title: label, value: label });
    }
    return options;
  };
  
  const treeDataTime = generateTimeOptions();


  const getCheckedDays = (days) => {
    return Object.keys(days).filter(day => days[day]);
  }
  

  useEffect(() => {
    const timer = setTimeout(() => {
      
      if (conditions.length > 0) {
        // Log the first condition as a separate object
        console.log({
          Condition: 'Condition 1',
          Type: conditions[0].selectedType,
          TimeDays: conditions[0].selectedTimeZone ,
          TimeZone: conditions[0].selectedCountryZone ,
          Comparator: conditions[0].comparator,
          Value: conditions[0].value,
          days: getCheckedDays(checked), 
        });
  
        // If there are more than one conditions, log the rest as an array
        if (conditions.length > 1) {
          const loggedConditions = conditions.slice(1).map((condition, index) => {
            return {
              Condition: 'Condition 1',
          Type: conditions[0].selectedType,
          TimeDays:  conditions[0].selectedTimeZone ,
                 TimeZone:  conditions[0].selectedCountryZone ,
          Comparator: conditions[0].comparator,
          Value: conditions[0].value,
          days: getCheckedDays(checked), 
              Data: [
                { Type: condition.selectedType ,
                
                 TimeDays: condition.selectedTimeZone ,
                 TimeZone: condition.selectedCountryZone ,
                 Comparator: condition.comparator ,
                 Value: condition.value ,
                 days: getCheckedDays(checked), 
                },
              ],
            };
          });
  
          console.log(loggedConditions);
          console.log(`Operator between conditions: ${operator}`);
        }
      }
    }, 3000);
  
    // Cleanup function to clear the timeout if the component is unmounted
    return () => clearTimeout(timer);
  }, [conditions, operator, value, valueTimeTwo, valueTimeZone,checked]);



  const getDetailsBySelection = (selection) => {
    switch (selection) {
        case 'start': return { icon: <PlayArrowIcon color="primary" />, heading: 'Start' };
        case 'pause': return { icon: <PauseIcon color="primary" />, heading: 'Pause' };
        case 'notify': return { icon: <NotificationsIcon color="primary" />, heading: 'Notify' };
        case 'increase': return { icon: <ArrowOutwardIcon color="primary" />, heading: 'Increase budget' };
        case 'decrease': return { icon: <CallReceivedIcon color="primary" />, heading: 'Decrease budget' };
        case 'set': return { icon: <VerticalAlignTopIcon color="primary" />, heading: 'Set budget' };
        case 'bid': return { icon: <SettingsIcon color="primary" />, heading: 'Set bid strategy' }; // Added this line for bid selection
        // ... add other cases as needed  case 'bid': return { icon: <SettingsIcon color="primary" />, heading: 'Set bid strategy' };
        case 'add': return { icon: <VerticalAlignTopIcon color="primary" />, heading: 'Add to name' };
        case 'remove': return { icon: <VerticalAlignTopIcon color="primary" />, heading: 'Remove from name' };
        case 'replace': return { icon: <VerticalAlignTopIcon color="primary" />, heading: 'Replace text in name' };
        default: return { icon: null, heading: '' };   
    }
}

let icon = '';
let heading = '';
let selectedValueParse = '';

  if (localStorage.getItem('settingModel')) {
      const settingGet = localStorage.getItem('settingModel');
      const parseSettings = JSON.parse(settingGet);
      selectedValueParse = parseSettings.SelectedValue

      if (parseSettings && parseSettings.SelectedTab) {
          const result = getDetailsBySelection(parseSettings.SelectedTab);
          if (result && result.icon && result.heading) {
              icon = result.icon;
              heading = result.heading;
          }
      }
  } else {
      console.log("No 'settingModel' found in localStorage");
      heading = 'Start'
  }
 // This effect runs once when the component mounts

 const [hover, setHover] = useState(false);

    const defaultStyle = {
        padding: '10px',
        backgroundColor: '#fff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center'
    };

    const hoverStyle = {
        ...defaultStyle,
        backgroundColor: '#f2f2f2'
    };
 
  return (
   <>

   <Box px={2}>
   <Heading  heading="Task"/>
   </Box>
  
     <Card   style={{ 
        width: "97%",
        boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.15)",
        marginLeft: "auto", 
        marginRight: "auto",
    }}>
      <CardContent>

        <Box marginBottom={2}>


        <Box sx={{ mb: 2,}}>
    <Button
        onClick={handleModalOpen}
        style={hover ? hoverStyle : defaultStyle}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
    >
        <div
            style={{
                flex: "0 0 auto", // Do not grow, do not shrink, auto width
                backgroundColor: "#f2f2f2",
                padding: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                height: '40px',
                width: '40px' // Fixed width for the icon container
            }}
        >
            {icon}
        </div>

        <div style={{ marginLeft: '15px', flex: "1 1 auto" }}> {/* grow and shrink freely */}
            <h2 style={{
                margin: '0',
                padding: '0',
                marginBottom: '2px',
                fontSize: '25px',
                lineHeight: '30px'
            }}>
                {heading}
            </h2>

            <p style={{
                display: 'block',
                margin: '0',
                fontSize: '12px',
                color: '#555',
                lineHeight: '14px',
                padding: '0',
                textAlign: 'left'
            }}>
                {(heading === "Start" || heading === "Pause") ? "Campaign" : selectedValueParse}
            </p>
        </div>
    </Button>
</Box>


        <NotifyModel open={isModalOpen} onClose={handleModalClose} />
        
          <Grid container spacing={2} style={{ overflowY: 'auto', maxHeight: '100vh' }}>
            {conditions.length > 1 && (
              <Grid
                item
                xs={1}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                <Button
                  variant="contained"
                  onClick={toggleOperator}
                  style={{
                    width: "70px",
                    height: `${conditions.length * (56 + 8)}px`,
                    backgroundColor: operator === "AND" ? "blue" : "orange",
                    color: "white",
                  }}
                >
                  {operator}
                </Button>
              </Grid>
            )}

            <Grid item xs={conditions.length > 1 ? 11 : 12}>
              {conditions.map((condition, index) => (
                <Box
                  key={index}
                  display="flex"
                  alignItems="center"
                  style={{
                    marginBottom: "8px",
                    position: "relative",
                    width: "100%",
                  }}
                >

                  {conditions.length > 1 && (
                    <div
                      style={{
                        position: "absolute",
                        left: "-17px",
                        top: "50%",
                        width: "19px",
                        height: "1px",
                        backgroundColor: "#888",
                      }}
                    />
                  )}

                 
<div style={{ flex: 2,marginRight:'8px' }}>
<TreeSelect
  style={{ width: '100%', borderRadius: 'none' }}
  value={condition.selectedType}
  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
  treeData={treeData}
  placeholder="Please select"
  onChange={(newValue) => onChange(newValue, index)}
/>
</div>

{ (condition.selectedType  === "Time greater than" || condition.selectedType  === "Time less than") && (
  <>
    <div style={{ flex: 1, marginRight: '8px' }}>
      <TreeSelect
        style={{ width: '100%', borderRadius: 'none' }}
        value={condition.selectedTime}
        dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
        treeData={treeDataTime}
        placeholder="Please select"
        onChange={(newValue) => onChangeTimeTwo(newValue, index)}
      />
    </div>

    <div style={{ flex: 2, marginRight: '8px' }}>
      <TreeSelect
        style={{ width: '100%', borderRadius: 'none' }}
        value={condition.selectedCountryZone}
        dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
        treeData={treeDataCountryZone}
        placeholder="Please select"
        onChange={(newValue) => onChangeTimeCountryZone(newValue, index)}
      />
    </div>
  </>
)}


{ (condition.selectedType !== "Time greater than" && condition.selectedType !== "Time less than") && (
  <>
  {/* WEEK DAYS */}
    { condition.selectedType !== "CurrentBid" && (
      <div style={{ flex: 1, marginRight: '8px' }}>
        <TreeSelect
          style={{ width: '100%' }}
          value={condition.selectedTimeZone}
          dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
          treeData={treeDataTimeZone}
          placeholder="Please select"
          onChange={(newValue) => onChangeTimeZone(newValue, index)}
        />
      </div>
    )}

    {/* GREATER THAN SELECT */}
    <Select 
      style={{ flex: 1,marginRight:'8px' }} 
      value={condition.comparator}
      onChange={(event) => handleComparatorChange(event, index)}
      displayEmpty
      renderValue={(selected) => selected}
    >
      {Object.entries(comparatorOptions).map(([text, symbol]) => (
        <MenuItem key={symbol} value={symbol}>
          {text} ({symbol})
        </MenuItem>
      ))}
    </Select>
  </>
)}

{/* MULTI DAYS */}
{ (condition.selectedType  === "Time greater than" || condition.selectedType  === "Time less than") && (
  <>
  <Box sx={{ flex:1,maxWidth:'200px'}}>
      <FormControl fullWidth>
        <Select
          labelId="weekdays-dropdown-label"
          id="weekdays-dropdown"
          multiple
          value={selectedDays}
          onChange={handleDayChange}
          renderValue={(selected) => selected.join(', ')}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          endAdornment={
            isHovered && (
              <InputAdornment position="end">
                <IconButton size="small">
                  <ContentCopyIcon fontSize="inherit" />
                </IconButton>
                <IconButton size="small"  onClick={() => deleteCondition(index)} >
                  <DeleteIcon fontSize="inherit" />
                </IconButton>
              </InputAdornment>
            )
          }
        >
          {daysOfWeek.map((day) => (
  <MenuItem key={day} value={day}>
    <Checkbox
      checked={checked[day]}
      onChange={handleChange}
      name={day}
    />
    <ListItemText primary={day} />
  </MenuItem>
))}
        </Select>
      </FormControl>
    </Box>
  </>
)}


{
  (condition.selectedType !== "Time greater than" && condition.selectedType !== "Time less than") && <>
       {/* TEXT FIELD */}
       <TextField
                    style={{ flex: 2,maxWidth:'200px' }}
                    defaultValue={
                      hoverIndex === index
                        ? "₹" + condition.value.substr(2)
                        : condition.value
                    }
                    onMouseEnter={() => setHoverIndex(index)}
                    onMouseLeave={() => setHoverIndex(null)}
                    InputProps={{
                      endAdornment: hoverIndex === index && (
                        <InputAdornment position="end" mr={2}>
                          <IconButton size="small">
                             <ContentCopyIcon  fontSize="inherit" />
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={() => deleteCondition(index)}
                          >
                            <DeleteIcon fontSize="inherit" />
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                  />
  </>
}

  



                </Box>
              ))}

              <Button onClick={addCondition}>+ Condition</Button>
            </Grid>
          </Grid>

        </Box>
      </CardContent>
    </Card>

    <Divider style={{ width: '100%',marginTop:'50px',marginBottom:'40px' }}  />

   </>
  );
};

export default ConditionForm;
