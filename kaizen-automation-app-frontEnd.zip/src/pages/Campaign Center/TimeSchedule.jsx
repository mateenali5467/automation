import React, { useState } from 'react';
import { Radio, RadioGroup, FormControlLabel, FormControl, FormLabel, TextField, Checkbox, FormGroup,Typography } from '@mui/material';

import Heading from 'components/common/Heading';

function TimeSchedule() {
    const [selectedValue, setSelectedValue] = useState('every60');
    const [dateRange, setDateRange] = useState(false);
    const [showMoreOptions, setShowMoreOptions] = useState(false);

    const handleRadioChange = (event) => {
        setSelectedValue(event.target.value);
    };

    return (
        <div style={{ width: '300px', padding: '20px' }}>
           <Heading heading="Schedule" />
            
            <FormControl component="fieldset">
                <FormLabel component="legend">How frequently to run the rule.</FormLabel>
                <RadioGroup value={selectedValue} onChange={handleRadioChange}>
                    <FormControlLabel value="every60" control={<Radio />} label="Run every 60 minutes" />
                </RadioGroup>
            </FormControl>

            {showMoreOptions && (
                <FormGroup>
                    <FormControlLabel 
                        control={<Checkbox checked={dateRange} onChange={() => setDateRange(!dateRange)} />}
                        label="Run within a date range"
                    />
                    {dateRange && (
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <TextField
                                label="Start Date"
                                type="date"
                                InputLabelProps={{ shrink: true }}
                            />
                            <TextField
                                label="End Date"
                                type="date"
                                InputLabelProps={{ shrink: true }}
                            />
                        </div>
                    )}
                </FormGroup>
            )}

            

            <a href="#" style={{fontSize:"13px",marginTop:"5px"}} onClick={(e) => {e.preventDefault(); setShowMoreOptions(!showMoreOptions)}}>{showMoreOptions ? 'Show less options' : 'Show more options'}</a>
       

        </div>
    );
}

export default TimeSchedule;
