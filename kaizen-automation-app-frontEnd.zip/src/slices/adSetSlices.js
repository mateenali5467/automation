import { createSlice } from "@reduxjs/toolkit";

import { baseURL } from "config/endpoint";

import { INSTANCE } from "../config/axiosInstance";

const initialState = {
  loader: false,
  data: [],
  error: false,
};

const adSetGroup = createSlice({
  name: "currentTabSlice",
  initialState,
  reducers: {
    setLoaderAdSet: (state, action) => {
      state.loader = action.payload;
    },
    setDataAdSet: (state, action) => {
      state.data = action.payload;
    },
    setErrorAdSet: (state, action) => {
      state.error = action.payload;
    },
  },
});

export const { setLoaderAdSet, setDataAdSet, setErrorAdSet } =
  adSetGroup.actions;
export default adSetGroup.reducer;

export const getAdSetApi = (data) => async (dispatch) => {

  try {
    
    dispatch(setLoaderAdSet(true));
    dispatch(setDataAdSet([]));
    dispatch(setErrorAdSet([]));

    const res = await INSTANCE.post("/campaign/tiktok/adgroup/create", {
      data: data,
    });

    dispatch(setLoaderAdSet(false));
    dispatch(setDataAdSet([res.data]));
    dispatch(setErrorAdSet([]));
  } catch (error) {
    dispatch(setDataAdSet([]));
    dispatch(setLoaderAdSet(false));
    dispatch(setErrorAdSet([error.response]));
  }
};
