import { createSlice } from "@reduxjs/toolkit";

import { baseURL } from "config/endpoint";
import { INSTANCE } from "../config/axiosInstance";

const initialState = {
  loader: false,
  data: [],
  error: false,
};

const adSlices = createSlice({
  name: "AdSlice",
  initialState,
  reducer: {
    setLoaderAd: (state, payload) => {
      state.loader = payload.loader;
    },
    setDataAd: (state, payload) => {
      state.data = payload.data;
    },
    setErrorAd: (state, payload) => {
      state.error = payload.data;
    },
  },
});

export const { setLoaderAd, setDataAd, setErrorAd } = adSlices.actions;
export default adSlices.reducer;


export const getAdApi = (data) => async (dispatch) => {
  try {

    dispatch(setLoaderAd(true));
    dispatch(setDataAd([]));
    dispatch(setErrorAd([]));

    const res = await INSTANCE.post("/campaign/tiktok/ad/create", {
      data: data,
    });

    dispatch(setLoaderAd(false));
    dispatch(setDataAd([res.data]));
    dispatch(setErrorAd([]));

  } 
  catch (error) {
    
    dispatch(setLoaderAd(false));
    dispatch(setDataAd([]));
    dispatch(setErrorAd([error.response]));

  }
};

