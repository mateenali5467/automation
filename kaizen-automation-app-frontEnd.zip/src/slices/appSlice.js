import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { INSTANCE } from "../config/axiosInstance";

// Define async actions with createAsyncThunk
export const fetchTreeDataAPI = createAsyncThunk("app/fetchTreeData", async () => {
    const response = await INSTANCE.get("/campaign/location-from-DB");
    // Modify and return response.data as necessary
    return response.data;
});

export const fetchLanguageListAPI = createAsyncThunk("app/fetchLanguageList", async () => {
    const response = await INSTANCE.get("/campaign/language");
    // Modify and return response.data as necessary
    return response.data;
});

export const fetchOSDataAPI = createAsyncThunk("app/fetchOSData", async () => {
    const response = await INSTANCE.get("/campaign/get_OSVersion", {
        params: { os_type : "ALL" }
    });
    // Modify and return response.data as necessary
    return response.data;
});

export const fetchCarriersDataAPI = createAsyncThunk("app/fetchCarriersData", async () => {
    const response = await INSTANCE.get("/campaign/get_device_models_DB");
    // Modify and return response.data as necessary
    return response.data;
});

// Slice
const appSlice = createSlice({
  name: 'app',
  initialState: {
    treeData: [],
    languageList: [],
    osData: [],
    carriersData: [],
    isLoading: false,
    error: null
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Handle fetchTreeDataAPI
      .addCase(fetchTreeDataAPI.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchTreeDataAPI.fulfilled, (state, action) => {
        state.isLoading = false;
        state.treeData = action.payload;
      })
      .addCase(fetchTreeDataAPI.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error;
      })
      .addCase(fetchLanguageListAPI.fulfilled, (state, action) => {
        state.languageList = action.payload;
      })
      .addCase(fetchOSDataAPI.fulfilled, (state, action) => {
        state.osData = action.payload;
      })
      .addCase(fetchCarriersDataAPI.fulfilled, (state, action) => {
        state.carriersData = action.payload;
      })
      // Handle fetchLanguageListAPI
      // Repeat the .addCase() calls for other async thunks
  }
});



export default appSlice.reducer;