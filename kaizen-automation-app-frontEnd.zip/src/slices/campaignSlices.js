import { createSlice } from "@reduxjs/toolkit";

import { baseURL } from "config/endpoint";
import { INSTANCE } from "../config/axiosInstance";


const initialState = {
   loader : false,
   data : [],
   error : false,
   errorToast : false
}


const campaignSlices = createSlice({
    name : "currentTabSlice",
    initialState,
    reducers : {
      setLoaderCampaign : (state,action)=>{
        state.loader = action.payload
      
      },
      setDataCampaign : (state,action)=>{
      state.data = action.payload;
    
      },
      setErrorCampaign : (state,action)=>{
        state.error = action.payload
      }
    }
});

export const { setLoaderCampaign, setDataCampaign, setErrorCampaign } = campaignSlices.actions;
export default campaignSlices.reducer;


export const getCampaignAPi = (data)=> async (dispatch)=>{

  // console.log("dswaDAS",data);

    try{
          dispatch(setLoaderCampaign(true));
          const res = await INSTANCE.post("/campaign/tiktok/campaign/create",{data:data});
          setTimeout(()=>{
            dispatch(setLoaderCampaign(false));
            dispatch(setDataCampaign([res.data]))
         },3000)
         
    }
    catch(error){
        dispatch(setLoaderCampaign(false));
        dispatch(setErrorCampaign(error));
        setTimeout(()=>{
          dispatch(setLoaderCampaign(false));
          dispatch(setErrorCampaign(false));
        },2000)
    }
}


    //  API CALLING START //
      //   try {
      //     setApiGet("waiting...");
      //     setIsLoading(true);
      //     const res = await INSTANCE.post("/campaign/tiktok/automation/create" ,{data:data})

      //     if(res){
      //       console.log("ressss",res);
      //       Toast("success", "Automated Rule Successfully Created");
      //     }
      //     setIsLoading(false);

      //   }
      //   catch(err){
      //     setIsLoading(false);
      //       console.log(err);
      //     Toast("error", "Automation Not Created Internal Server");
      //  }

      // API CALLING END //