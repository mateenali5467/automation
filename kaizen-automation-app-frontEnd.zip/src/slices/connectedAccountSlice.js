import { createSlice } from "@reduxjs/toolkit";

import { baseURL } from "config/endpoint";
import { INSTANCE } from "../config/axiosInstance";


const initialState = {
   loader : false,
   data : [],
   error : false
}


const connectedAccountSlice = createSlice({
    name : "connectedAccountSlice",
    initialState,
    reducers : {
      setLoaderconnectAccount : (state,action)=>{
        state.loader = action.payload
      
      },
      setDataconnectAccount : (state,action)=>{
      state.data = action.payload;
    
      },
      setErrorconnectAccount : (state,action)=>{
        state.error = action.payload
      }
    }
});

export const { setLoaderconnectAccount, setDataconnectAccount, setErrorconnectAccount } = connectedAccountSlice.actions;
export default connectedAccountSlice.reducer;




export const getConnectAPi = (data)=> async (dispatch)=>{

    console.log(data);
    
    try{
          dispatch( setLoaderconnectAccount(true));
          await INSTANCE.post(`/campaign/google/connect/adAccount/${accountId}`, {
            is_connected: data.isConnected
        });
         
            dispatch( setLoaderconnectAccount(false));
            dispatch(setDataconnectAccount([res.data]))
       
         
    }
    catch(error){
        dispatch( setLoaderconnectAccount(false));
        dispatch(setErrorconnectAccount(error));
        setTimeout(()=>{
          dispatch( setLoaderconnectAccount(false));
          dispatch(setErrorconnectAccount(false));
        },2000)
    }
}


   