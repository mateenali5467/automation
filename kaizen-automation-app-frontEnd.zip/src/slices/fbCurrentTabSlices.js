import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   currentTab : 1
}

const fbCurrentTabSlice = createSlice({
    name : "fbCurrentTabSlice",
    initialState,
    reducers : {
        fbGetCurrentTab : (state,action)=>{
            state.currentTab = action.payload;
        }
    }
});

export const { fbGetCurrentTab } = fbCurrentTabSlice.actions;
export default fbCurrentTabSlice.reducer;