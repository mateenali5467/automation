import { createSlice } from "@reduxjs/toolkit";


const initialState = {
   split : false
}

const splitSplice = createSlice({
    name : "splitSplice",
    initialState,
    reducers : {
       getCurrentSplitStatus : (state,action)=>{
            state.split = action.payload;
       }
    }
});

export const {  getCurrentSplitStatus } = splitSplice.actions;
export default splitSplice.reducer;