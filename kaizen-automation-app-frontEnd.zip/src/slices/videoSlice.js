import { createSlice } from "@reduxjs/toolkit";

import { baseURL } from "config/endpoint";
import { INSTANCE } from "../config/axiosInstance";


const initialState = {
  loader: false,
  data: [],
  error: [],
};

const videoSlice = createSlice({
  name: "videoSlice",
  initialState,
  reducer: {
    setVideoLoader: (state, payload) => {
      state.loader = payload.loader;
    },
    setVideoData: (state, payload) => {
      state.data = payload.data;
    },
    setVideoError: (state, payload) => {
      state.error = payload.data;
    },
  },
});

export const { setVideoLoader, setVideoData, setVideoError } = videoSlice.actions;
export default videoSlice.reducer;


export const getVideoApi = (data) => async (dispatch) => {
 
  try {

    dispatch(setVideoLoader(true))
    dispatch(setVideoData([]));
    dispatch(setVideoError([]));
 

    const res = await INSTANCE.post("/creative/upload-video",data, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      

   dispatch(setVideoLoader(false));
   dispatch(setVideoData([res.data]));
   dispatch(setVideoError([]));


  } 
  catch(error) {

    // dispatch(setVideoLoader(false));
    // dispatch(setVideoData([]));
    // dispatch(setVideoError([error.response]));


  }
};

