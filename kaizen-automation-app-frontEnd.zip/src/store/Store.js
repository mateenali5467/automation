import { configureStore } from "@reduxjs/toolkit";
import ThemeReducer from "../feature/theme/ThemeSlice";
import authReducer from "../feature/auth/authSlice";
import newProductReducer from "../feature/Control Center/newProductSlice";
import existingProductReducer from "../feature/Control Center/existingProductSlice";
import profileReducer from "../feature/Profile/ProfileSlice";
import dateSlice from "../slices/dateSlices";
import statusSlice from "../slices/statusSlice";
import createAutomationSlices from "slices/createAutomationSlices";
import currentTabSlices from "slices/currentTabSlices";
import campaignSlices from "slices/campaignSlices";

import adSetGroup from "slices/adSetSlices";

import videoSlice from "slices/videoSlice";

import splitTestSplice from "slices/splitTest.splice";

import appSlice from "slices/appSlice";

import fbCurrentTabSlices from "slices/fbCurrentTabSlices";

import showAllAccountsSlices from "slices/showAllAccountsSlices";

export const store = configureStore({
  reducer: {
    theme: ThemeReducer,
    auth: authReducer,
    profile: profileReducer,
    newProduct: newProductReducer,
    existingProduct: existingProductReducer,
    dateSlice : dateSlice,
    statusSlice : statusSlice,
    createAutomationSlices,
    currentTabSlices,
    campaignSlices,
    adSetGroup,
    videoSlice,
    splitTestSplice,
    appSlice,
    facebookTab : fbCurrentTabSlices,
    showAllAccountsSlices 
  },
});
